/**
 * error.tsx — Global Error Boundary
 */

'use client';

import { useEffect } from 'react';
import { RefreshCw, Home } from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => {
    console.error('Application error:', error);
  }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-white dark:bg-[#0a0a0f]">
      <div className="text-center max-w-md">
        <div className="text-7xl mb-4">😵</div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-3">Terjadi Kesalahan</h1>
        <p className="text-slate-500 dark:text-slate-400 mb-8">
          Maaf, terjadi error yang tidak terduga. Tim kami sudah diberitahu.
        </p>
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={reset}
            className={cn(
              'flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl',
              'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
              'hover:from-amber-600 hover:to-amber-700',
              'shadow-lg shadow-amber-500/20 transition-all duration-200'
            )}
          >
            <RefreshCw className="w-4 h-4" />
            Coba Lagi
          </button>
          <Link
            href="/"
            className="flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 transition-all"
          >
            <Home className="w-4 h-4" />
            Beranda
          </Link>
        </div>
      </div>
    </div>
  );
}
