/**
 * Activity Page — /client/activity
 * Revamped with Aceternity-style animated tabs.
 * Tabs: Aktivitas, Deposit, Orders (Numbers), Login History.
 */

'use client';

import { useEffect, useState, useMemo } from 'react';
import {
  Activity as ActivityIcon, ArrowDownLeft, ArrowUpRight, Filter,
  Wallet, ShoppingCart, LogIn, Globe, Monitor, Smartphone,
  CheckCircle2, XCircle, Clock, RotateCcw, Loader2, Settings
} from 'lucide-react';
import { cn, formatRupiah, formatDateShort, getStatusColor } from '@/lib/utils';
import api from '@/lib/api';
import { AnimatedTabs, type Tab } from '@/components/ui/animated-tabs';

/* ── Types ─────────────────────────────────────── */
interface ActivityItem {
  id: string;
  type: string;
  description: string;
  amount: number;
  balance?: number;
  createdAt: string;
}

interface DepositItem {
  depositId: string;
  amount: number;
  fee?: number;
  method: string;
  status: string;
  createdAt: string;
  paidAt?: string;
}

interface OrderItem {
  orderId: string;
  serviceName: string;
  serviceImg?: string;
  phoneNumber?: string;
  price: number;
  status: string;
  otpCode?: string;
  createdAt: string;
}

interface SessionItem {
  id: string;
  userAgent?: string;
  ip?: string;
  lastActive: string;
  createdAt: string;
}

/* ── Helpers ───────────────────────────────────── */
function parseUserAgent(ua?: string) {
  if (!ua) return { browser: 'Unknown', os: 'Unknown', isMobile: false };
  const isMobile = /mobile|android|iphone|ipad/i.test(ua);
  let browser = 'Browser';
  if (/chrome/i.test(ua) && !/edg/i.test(ua)) browser = 'Chrome';
  else if (/firefox/i.test(ua)) browser = 'Firefox';
  else if (/safari/i.test(ua) && !/chrome/i.test(ua)) browser = 'Safari';
  else if (/edg/i.test(ua)) browser = 'Edge';
  let os = 'Unknown';
  if (/windows/i.test(ua)) os = 'Windows';
  else if (/mac/i.test(ua)) os = 'macOS';
  else if (/linux/i.test(ua)) os = 'Linux';
  else if (/android/i.test(ua)) os = 'Android';
  else if (/iphone|ipad/i.test(ua)) os = 'iOS';
  return { browser, os, isMobile };
}

/* ── Sub-Components ────────────────────────────── */

function EmptyState({ icon: Icon, text }: { icon: React.ComponentType<{ className?: string }>; text: string }) {
  return (
    <div className="text-center py-20">
      <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-white/5 flex items-center justify-center mx-auto mb-4">
        <Icon className="w-8 h-8 text-slate-300 dark:text-slate-600" />
      </div>
      <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{text}</p>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-3 p-4">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="h-16 rounded-xl bg-slate-100 dark:bg-white/5 animate-pulse" />
      ))}
    </div>
  );
}

/* ── Activity Tab Content ──────────────────────── */
function ActivityContent() {
  const [items, setItems] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/api/v1/user/activities');
        setItems(data.data || []);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  const getIcon = (type: string) =>
    (type === 'DEPOSIT' || type === 'REFUND' || type === 'BONUS') ? ArrowDownLeft : ArrowUpRight;
  const getColor = (type: string) =>
    (type === 'DEPOSIT' || type === 'REFUND' || type === 'BONUS')
      ? 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-500/10'
      : 'text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-500/10';

  if (loading) return <LoadingSkeleton />;
  if (items.length === 0) return <EmptyState icon={ActivityIcon} text="Belum ada aktivitas" />;

  return (
    <div className="bg-white dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-white/5">
      {items.map((act) => {
        const Icon = getIcon(act.type);
        const isPositive = act.amount > 0;
        return (
          <div key={act.id} className="flex items-center justify-between px-5 py-4 hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
            <div className="flex items-center gap-3 min-w-0">
              <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0', getColor(act.type))}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-800 dark:text-white truncate">{act.description}</p>
                <p className="text-[11px] text-slate-400 font-mono">{formatDateShort(act.createdAt)}</p>
              </div>
            </div>
            <div className="text-right flex-shrink-0 ml-4">
              <p className={cn('text-sm font-bold', isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-500 dark:text-red-400')}>
                {isPositive ? '+' : ''}{formatRupiah(act.amount)}
              </p>
              {act.balance !== undefined && (
                <p className="text-[10px] text-slate-400 font-mono">{formatRupiah(act.balance)}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ── Deposit Tab Content ───────────────────────── */
function DepositContent() {
  const [items, setItems] = useState<DepositItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/api/v1/deposit');
        setItems(data.data || []);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  const statusIcon = (s: string) => {
    if (s === 'COMPLETED') return <CheckCircle2 className="w-4 h-4 text-green-500" />;
    if (s === 'CANCELED' || s === 'FAILED') return <XCircle className="w-4 h-4 text-red-500" />;
    return <Clock className="w-4 h-4 text-amber-500" />;
  };
  const statusLabel = (s: string) => {
    const map: Record<string, string> = { COMPLETED: 'Berhasil', WAITING: 'Menunggu', CANCELED: 'Dibatalkan', FAILED: 'Gagal', EXPIRED: 'Expired' };
    return map[s] || s;
  };

  if (loading) return <LoadingSkeleton />;
  if (items.length === 0) return <EmptyState icon={Wallet} text="Belum ada deposit" />;

  return (
    <div className="bg-white dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-white/5">
      {items.map((dep) => (
        <div key={dep.depositId} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center flex-shrink-0">
            <ArrowDownLeft className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-slate-800 dark:text-white">TopUp Saldo {dep.method}</p>
              {statusIcon(dep.status)}
            </div>
            <p className="text-[11px] text-slate-400 font-mono">{dep.depositId} · {formatDateShort(dep.createdAt)}</p>
          </div>
          <div className="text-right flex-shrink-0">
            <p className={cn('text-sm font-bold', dep.status === 'COMPLETED' ? 'text-green-600 dark:text-green-400' : 'text-slate-600 dark:text-slate-300')}>
              +{formatRupiah(dep.amount)}
            </p>
            <span className={cn('inline-block text-[10px] font-bold px-2 py-0.5 rounded-md', getStatusColor(dep.status))}>
              {statusLabel(dep.status)}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ── Orders Tab Content ────────────────────────── */
function OrdersContent() {
  const [items, setItems] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/api/v1/orders');
        setItems(data.data || []);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  const statusLabel = (s: string) => {
    const map: Record<string, string> = { COMPLETED: 'Selesai', WAITING: 'Menunggu OTP', CANCELED: 'Dibatalkan', EXPIRED: 'Expired' };
    return map[s] || s;
  };

  if (loading) return <LoadingSkeleton />;
  if (items.length === 0) return <EmptyState icon={ShoppingCart} text="Belum ada pesanan" />;

  return (
    <div className="bg-white dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-white/5">
      {items.map((order) => (
        <div key={order.orderId} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
            {order.serviceImg ? (
              <img src={order.serviceImg} alt="" className="w-full h-full object-cover rounded-xl" />
            ) : (
              <ShoppingCart className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-slate-800 dark:text-white truncate">{order.serviceName}</p>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
              <span>{order.phoneNumber || order.orderId}</span>
              <span>·</span>
              <span>{formatDateShort(order.createdAt)}</span>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-sm font-bold text-red-500 dark:text-red-400">-{formatRupiah(order.price)}</p>
            <span className={cn('inline-block text-[10px] font-bold px-2 py-0.5 rounded-md', getStatusColor(order.status))}>
              {statusLabel(order.status)}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ── Login History Tab Content ─────────────────── */
function LoginHistoryContent() {
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/api/v1/user/sessions');
        setSessions(data.data || []);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading) return <LoadingSkeleton />;
  if (sessions.length === 0) return <EmptyState icon={LogIn} text="Belum ada riwayat login" />;

  return (
    <div className="bg-white dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-white/5">
      {sessions.map((session, idx) => {
        const { browser, os, isMobile } = parseUserAgent(session.userAgent);
        const isFirst = idx === 0;
        return (
          <div key={session.id} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
            <div className={cn(
              'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0',
              isFirst ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-400' : 'bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400'
            )}>
              {isMobile ? <Smartphone className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-slate-800 dark:text-white">
                  {browser} — {os}
                </p>
                {isFirst && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-green-100 text-green-700 dark:bg-green-500/20 dark:text-green-400 border border-green-200 dark:border-green-500/30">
                    Aktif
                  </span>
                )}
              </div>
              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                <span className="font-mono flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  {session.ip || 'Unknown IP'}
                </span>
                <span>·</span>
                <span>{formatDateShort(session.lastActive)}</span>
              </div>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-[11px] text-slate-400">Login</p>
              <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">{formatDateShort(session.createdAt)}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ── Main Page ─────────────────────────────────── */
export default function ActivityPage() {
  const tabs: Tab[] = useMemo(() => [
    {
      title: 'Aktivitas',
      value: 'activity',
      icon: <ActivityIcon className="w-4 h-4" />,
      content: <ActivityContent />,
    },
    {
      title: 'Deposit',
      value: 'deposit',
      icon: <Wallet className="w-4 h-4" />,
      content: <DepositContent />,
    },
    {
      title: 'Numbers',
      value: 'orders',
      icon: <ShoppingCart className="w-4 h-4" />,
      content: <OrdersContent />,
    },
    {
      title: 'Login',
      value: 'sessions',
      icon: <LogIn className="w-4 h-4" />,
      content: <LoginHistoryContent />,
    },
  ], []);

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-3">
            <Settings className="w-7 h-7 text-amber-500" />
            Laporan
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Semua transaksi, deposit, pesanan, dan riwayat login Anda</p>
        </div>
      </div>

      {/* Animated Tabs */}
      <AnimatedTabs tabs={tabs} />
    </div>
  );
}
