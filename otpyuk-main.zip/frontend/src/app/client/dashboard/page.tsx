/**
 * Dashboard Page — /client/dashboard
 * Premium dashboard with carousel, server status, services, testimonials, and terminal.
 */

'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Wallet, ShoppingCart, Clock, TrendingUp, ArrowRight, Copy, Check,
  Wifi, Zap, ShieldCheck, Globe, MessageSquare, ChevronLeft, ChevronRight
} from 'lucide-react';
import { cn, formatRupiah, getStatusColor, copyToClipboard } from '@/lib/utils';
import api from '@/lib/api';
import { SERVERS, TESTIMONIALS } from '@/lib/constants';
import { InfiniteMovingCards } from '@/components/ui/infinite-moving-cards';

interface DashboardData {
  balance: number;
  totalOrders: number;
  activeOrders: number;
  recentOrders: Array<{
    orderId: string;
    serviceName: string;
    phoneNumber: string;
    status: string;
    otpCode?: string;
    price: number;
    createdAt: string;
  }>;
}

interface RealtimeService {
  service_code: number;
  service_name: string;
  service_img: string;
}

// Server ping simulation
function usePingData() {
  const [pings, setPings] = useState<number[]>([]);
  useEffect(() => {
    const generate = () => SERVERS.map(() => Math.floor(Math.random() * 120) + 20);
    setPings(generate());
    const interval = setInterval(() => setPings(generate()), 5000);
    return () => clearInterval(interval);
  }, []);
  return pings;
}

function PromoBanner() {
  const [current, setCurrent] = useState(0);
  
  const slides = useMemo(() => [
    {
      title: 'Nomor Virtual Instan',
      desc: 'Beli OTP langsung aktif dari 1.700+ layanan',
      button: 'Beli OTP →',
      src: '/images/otpyuk-hero.webp',
      bg: 'from-amber-500 to-amber-600',
    },
    {
      title: 'API Developer Ready',
      desc: 'Integrasikan layanan OTP ke bot/aplikasi Anda',
      button: 'Lihat Docs →',
      src: '/images/otpyuk-mascot-happy.webp',
      bg: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Auto Refund Terjamin',
      desc: 'Saldo kembali otomatis jika OTP gagal masuk',
      button: 'Coba Sekarang →',
      src: '/images/otpyuk-mascot-404.webp',
      bg: 'from-green-500 to-emerald-600',
    },
  ], []);

  const next = useCallback(() => setCurrent(c => (c + 1) % slides.length), [slides.length]);
  const prev = useCallback(() => setCurrent(c => (c - 1 + slides.length) % slides.length), [slides.length]);

  useEffect(() => {
    const timer = setInterval(next, 4000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <div className="lg:col-span-3 relative overflow-hidden rounded-2xl h-[240px] group bg-neutral-900">
      <div className="absolute inset-0 bg-dot-pattern opacity-20 z-0" />
      
      {slides.map((slide, i) => (
        <div
          key={i}
          className={cn(
            "absolute inset-0 flex items-center p-6 sm:p-8 transition-all duration-700 ease-in-out bg-gradient-to-r",
            slide.bg,
            current === i ? "opacity-100 translate-x-0 z-10" : "opacity-0 translate-x-full z-0"
          )}
        >
          <div className="flex-1 text-white z-10 max-w-[60%]">
            <h2 className="text-2xl sm:text-3xl font-extrabold mb-2 leading-tight">{slide.title}</h2>
            <p className="text-sm sm:text-base text-white/90 mb-5">{slide.desc}</p>
            <Link 
              href="/client/virtual-number"
              className="inline-flex items-center px-4 py-2 bg-white text-slate-900 font-bold rounded-xl text-sm hover:scale-105 transition-transform"
            >
              {slide.button}
            </Link>
          </div>
          <div className="absolute right-0 bottom-0 h-full w-[50%] flex items-end justify-end pointer-events-none">
            <Image 
              src={slide.src} 
              alt={slide.title} 
              width={240} 
              height={240} 
              priority={i === 0}
              className={cn(
                "object-contain object-bottom h-[120%] w-auto transition-transform duration-1000",
                current === i ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
              )}
            />
          </div>
        </div>
      ))}

      {/* Controls */}
      <button onClick={prev} className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 backdrop-blur-sm">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button onClick={next} className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 backdrop-blur-sm">
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-20">
        {slides.map((_, i) => (
          <button 
            key={i} 
            onClick={() => setCurrent(i)}
            className={cn("w-2 h-2 rounded-full transition-all", current === i ? "bg-white w-4" : "bg-white/40")}
          />
        ))}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [services, setServices] = useState<RealtimeService[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState('');
  const [serviceSearch, setServiceSearch] = useState('');
  const pings = usePingData();

  useEffect(() => {
    async function fetchDashboard() {
      try {
        const [balanceRes, ordersRes, servicesRes] = await Promise.all([
          api.get('/api/v1/user/balance'),
          api.get('/api/v1/orders?limit=5'),
          api.get('/api/v1/services/public'),
        ]);
        setData({
          balance: balanceRes.data.data.balance,
          totalOrders: ordersRes.data.meta?.total || 0,
          activeOrders: (ordersRes.data.data || []).filter((o: { status: string }) => o.status === 'WAITING' || o.status === 'RECEIVED').length,
          recentOrders: ordersRes.data.data || [],
        });
        if (servicesRes.data.data) {
          setServices(servicesRes.data.data);
        }
      } catch {
        setData({ balance: 0, totalOrders: 0, activeOrders: 0, recentOrders: [] });
      } finally {
        setLoading(false);
      }
    }
    fetchDashboard();
  }, []);

  const handleCopy = async (text: string, id: string) => {
    await copyToClipboard(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(''), 2000);
  };

  // Filtered services
  const filteredServices = useMemo(() => {
    if (!serviceSearch) return services.slice(0, 18);
    return services.filter(s => s.service_name.toLowerCase().includes(serviceSearch.toLowerCase())).slice(0, 18);
  }, [serviceSearch, services]);

  // Testimonials for infinite cards
  const testimonialItems = useMemo(() =>
    TESTIMONIALS.map(t => ({
      quote: t.text,
      name: t.name,
      title: `⭐ ${t.rating}/5`,
    })), []);

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-32 rounded-2xl bg-slate-100 dark:bg-white/5 animate-pulse" />
        ))}
      </div>
    );
  }

  const onlineCount = SERVERS.length;

  return (
    <div className="space-y-8">

      {/* ═══ Section 1: Promo Banner + Quick Action ═══ */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Auto-sliding Promo Banner */}
        <PromoBanner />

        {/* Quick Action Card */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          {/* Buy OTP Card */}
          <Link
            href="/client/virtual-number"
            className="flex items-center gap-4 p-5 rounded-2xl bg-white dark:bg-white/[0.02] border border-slate-200/50 dark:border-white/5 card-hover group"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
              <ShoppingCart className="w-6 h-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-bold text-slate-800 dark:text-white">Nomor Virtual</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Beli Nomor Sementara!</p>
            </div>
            <span className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-white text-sm font-bold hover:bg-slate-200 dark:hover:bg-white/10 transition-colors flex-shrink-0">
              BELI
            </span>
          </Link>

          {/* Stats mini cards */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Saldo', value: formatRupiah(data?.balance || 0), icon: Wallet, color: 'text-amber-600 bg-amber-50 dark:text-amber-400 dark:bg-amber-500/10' },
              { label: 'Pesanan', value: String(data?.totalOrders || 0), icon: ShoppingCart, color: 'text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-500/10' },
            ].map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="p-3.5 rounded-xl bg-white dark:bg-white/[0.02] border border-slate-200/50 dark:border-white/5 flex flex-col justify-center">
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', stat.color)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wider">{stat.label}</span>
                  </div>
                  <p className="text-lg font-black text-slate-800 dark:text-white">{stat.value}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ═══ Section 2: Server Status ═══ */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            Server Status
          </h2>
          <span className="text-xs font-semibold text-green-600 dark:text-green-400">{onlineCount}/{onlineCount} Online</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {SERVERS.map((server, i) => {
            const ping = pings[i] || 50;
            const isGood = ping < 100;
            return (
              <div key={i} className="p-4 rounded-xl bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5 card-hover">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                    <img src={`https://flagcdn.com/w20/${server.country}.png`} alt={server.country} className="w-4 h-3 rounded-[2px]" />
                    {server.name}
                  </span>
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.5)]" />
                </div>
                <div className="flex items-center justify-between">
                  <span className={cn(
                    'text-xs font-mono font-bold flex items-center gap-1',
                    isGood ? 'text-green-600 dark:text-green-400' : 'text-red-500'
                  )}>
                    <Wifi className="w-3 h-3" />
                    {ping}ms
                  </span>
                  {/* Signal bars */}
                  <div className="flex items-end gap-0.5 h-4">
                    {[1, 2, 3, 4].map((bar) => (
                      <div
                        key={bar}
                        className={cn(
                          'w-1 rounded-full transition-all',
                          bar <= (isGood ? 4 : 2) ? 'bg-green-500' : 'bg-slate-200 dark:bg-white/10'
                        )}
                        style={{ height: `${bar * 25}%` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ═══ Section 3: Service Available ═══ */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-3">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-amber-500" />
            Service Available
          </h2>
          <input 
            type="text" 
            placeholder="Cari layanan..." 
            value={serviceSearch}
            onChange={(e) => setServiceSearch(e.target.value)}
            className="px-4 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-white dark:bg-[#111118] focus:outline-none focus:ring-2 focus:ring-amber-500/50 w-full sm:w-64"
          />
        </div>

        {/* Service grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {filteredServices.map((service, i) => (
            <Link
              key={i}
              href={`/client/virtual-number?service=${service.service_code}`}
              className="flex flex-col items-center gap-3 p-4 rounded-xl bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5 card-hover text-center"
            >
              <div className="w-10 h-10 rounded-xl overflow-hidden bg-slate-50 dark:bg-white/5 flex items-center justify-center p-1">
                <img src={service.service_img} alt={service.service_name} className="w-full h-full object-contain" />
              </div>
              <span className="text-sm font-semibold text-slate-800 dark:text-white truncate w-full">{service.service_name}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* ═══ Section 4: Recent Orders ═══ */}
      <div className="bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-amber-500" />
            Pesanan Terbaru
          </h3>
          <Link href="/client/virtual-number" className="text-xs text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1">
            Lihat Semua <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {(data?.recentOrders || []).length === 0 ? (
          <div className="text-center py-10 text-slate-400">
            <Image
              src="/images/otpyuk-mascot-404.webp"
              alt="No orders"
              width={120}
              height={120}
              className="mx-auto mb-4 opacity-80"
            />
            <p className="text-sm font-medium">Belum ada pesanan</p>
            <Link href="/client/virtual-number" className="text-xs text-amber-600 dark:text-amber-400 hover:underline mt-2 inline-block">
              Beli OTP pertama →
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {data?.recentOrders.map((order) => (
              <div
                key={order.orderId}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50/50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center text-lg flex-shrink-0">
                    📱
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-800 dark:text-white truncate">{order.serviceName}</p>
                    <p className="text-xs text-slate-400 font-mono">{order.phoneNumber}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  {order.otpCode && (
                    <button
                      onClick={() => handleCopy(order.otpCode!, order.orderId)}
                      className="flex items-center gap-1 px-2 py-1 rounded-lg bg-green-50 dark:bg-green-500/10 text-green-700 dark:text-green-400 text-xs font-mono font-bold"
                    >
                      {order.otpCode}
                      {copiedId === order.orderId ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                  <span className={cn('px-2 py-1 rounded-lg text-[10px] font-semibold uppercase', getStatusColor(order.status))}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ═══ Section 5: Testimonials (Infinite Moving Cards) ═══ */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-amber-500" />
          Kata Mereka
        </h2>
        <div className="rounded-2xl overflow-hidden">
          <InfiniteMovingCards
            items={testimonialItems}
            direction="right"
            speed="slow"
          />
        </div>
      </div>

    </div>
  );
}
