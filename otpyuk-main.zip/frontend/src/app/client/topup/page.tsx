/**
 * Top Up Page — /client/topup
 * Deposit form matching the highly professional design requested by the user.
 */

'use client';

import { useState, useEffect } from 'react';
import { Wallet, Copy, Check, Loader2, Info, X, Building2, ChevronDown, ChevronRight, Clock, RefreshCcw, ShieldCheck } from 'lucide-react';
import { cn, formatRupiah, copyToClipboard } from '@/lib/utils';
import api from '@/lib/api';
import Link from 'next/link';
import { PaymentHistory } from '@/components/common/PaymentHistory';
import { useAuthStore } from '@/store/useAuthStore';
import { toast } from 'sonner';

const AMOUNTS = [
  { value: 3000, label: 'Hemat', emoji: '✨' },
  { value: 20000, label: 'Populer', emoji: '💫' },
  { value: 50000, label: 'Rekomen', emoji: '😎' },
  { value: 70000, label: 'Juragan', emoji: '💸' },
  { value: 100000, label: 'Bosman', emoji: '☠️' },
  { value: 200000, label: 'VVIP', emoji: '👑' },
];

const METHODS = [
  { id: 'DANA', label: 'DANA', desc: 'Proses Otomatis', logo: 'https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_dana_blue.svg' },
  { id: 'OVO', label: 'OVO', desc: 'Proses Otomatis', logo: 'https://upload.wikimedia.org/wikipedia/commons/e/eb/Logo_ovo_purple.svg' },
  { id: 'GOPAY', label: 'GoPay', desc: 'Proses Otomatis', logo: 'https://upload.wikimedia.org/wikipedia/commons/8/86/Gopay_logo.svg' },
  { id: 'QRIS', label: 'QRIS All Payment', desc: 'Scan dari semua M-Banking', logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_QRIS.svg' },
  { id: 'BRI', label: 'Bank BRI', desc: 'Briva / Transfer Bank', logo: 'https://upload.wikimedia.org/wikipedia/commons/2/2e/BRI_2020.svg' },
];

interface DepositResult {
  depositId: string;
  amount: number;
  method: string;
  qrString?: string;
  qrImage?: string;
  expiredAt: string;
  status: string;
}

function CountdownTimer({ targetDate, onExpire }: { targetDate: string, onExpire: () => void }) {
  const [timeLeft, setTimeLeft] = useState({ minutes: 0, seconds: 0 });

  useEffect(() => {
    const target = new Date(targetDate).getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = target - now;

      if (distance < 0) {
        clearInterval(interval);
        onExpire();
        setTimeLeft({ minutes: 0, seconds: 0 });
      } else {
        setTimeLeft({
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000),
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate, onExpire]);

  return (
    <div className="flex items-center gap-2 justify-center mt-2 text-rose-500 font-mono text-lg bg-rose-50 dark:bg-rose-500/10 py-2 px-4 rounded-xl border border-rose-100 dark:border-rose-500/20 w-fit mx-auto shadow-sm">
      <Clock className="w-5 h-5 animate-pulse" />
      <span className="font-bold">{String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}</span>
    </div>
  );
}

const ACTIVE_DEPOSIT_KEY = 'otpyuk_active_deposit';

function saveActiveDeposit(deposit: DepositResult) {
  try { localStorage.setItem(ACTIVE_DEPOSIT_KEY, JSON.stringify(deposit)); } catch {}
}

function loadActiveDeposit(): DepositResult | null {
  try {
    const raw = localStorage.getItem(ACTIVE_DEPOSIT_KEY);
    if (!raw) return null;
    const deposit = JSON.parse(raw) as DepositResult;
    // If expired locally, don't resume
    if (new Date(deposit.expiredAt).getTime() < Date.now()) {
      localStorage.removeItem(ACTIVE_DEPOSIT_KEY);
      return null;
    }
    return deposit;
  } catch { return null; }
}

function clearActiveDeposit() {
  try { localStorage.removeItem(ACTIVE_DEPOSIT_KEY); } catch {}
}

export default function TopUpPage() {
  const [step, setStep] = useState(1);
  const [amount, setAmount] = useState<number | ''>(50000);
  const [method, setMethod] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DepositResult | null>(null);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [fee, setFee] = useState(0);
  const [checkingStatus, setCheckingStatus] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  
  const setUser = useAuthStore(state => state.setUser);

  const finalAmount = typeof amount === 'number' ? amount : parseInt(amount || '0', 10);
  const isValidAmount = finalAmount >= 3000 && finalAmount <= 1000000;

  // Approximate USD conversion for the UI (1 USD ~ 16,000 IDR)
  const usdAmount = (finalAmount / 16000).toFixed(2);

  // ── Resume active deposit on page load ──────────
  useEffect(() => {
    const saved = loadActiveDeposit();
    if (saved) {
      setResult(saved);
      setPaymentStatus('PENDING');
      // Immediately check status in case payment was made while user was away
      (async () => {
        try {
          const { data } = await api.get(`/api/v1/deposit/${saved.depositId}/status`);
          const newStatus = data.data.status;
          if (newStatus === 'SUCCESS') {
            setPaymentStatus('SUCCESS');
            clearActiveDeposit();
            toast.success('Pembayaran sebelumnya berhasil! Saldo telah ditambahkan.');
            try {
              const profileRes = await api.get('/api/v1/user/profile');
              setUser(profileRes.data.data);
            } catch {}
          } else if (newStatus === 'EXPIRED' || newStatus === 'CANCEL') {
            setPaymentStatus(newStatus);
            clearActiveDeposit();
          }
        } catch {}
      })();
    }
  }, []);

  const handleDeposit = async () => {
    if (!isValidAmount) { setError('Nominal tidak valid (Min 3.000, Max 1.000.000)'); return; }
    if (!method) { setError('Pilih metode pembayaran'); return; }
    
    setError('');
    setLoading(true);

    try {
      const { data } = await api.post('/api/v1/deposit/create', { amount: finalAmount + fee, method: method === 'QRIS' ? 'QRIS' : method });
      const depositData = data.data;
      setResult(depositData);
      setPaymentStatus('PENDING');
      saveActiveDeposit(depositData);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { message?: string } } };
      setError(axiosErr.response?.data?.message || 'Gagal membuat deposit');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckStatus = async (isAuto = false) => {
    if (!result || paymentStatus === 'SUCCESS' || paymentStatus === 'EXPIRED' || paymentStatus === 'CANCEL') return;
    
    if (!isAuto) setCheckingStatus(true);
    
    try {
      const { data } = await api.get(`/api/v1/deposit/${result.depositId}/status`);
      const newStatus = data.data.status;
      
      if (newStatus !== paymentStatus) {
        setPaymentStatus(newStatus);
        
        if (newStatus === 'SUCCESS') {
          clearActiveDeposit();
          toast.success('Pembayaran Berhasil! Saldo telah ditambahkan.');
          try {
            const profileRes = await api.get('/api/v1/user/profile');
            setUser(profileRes.data.data);
          } catch {}
        } else if (newStatus === 'EXPIRED' || newStatus === 'CANCEL') {
          clearActiveDeposit();
          if (!isAuto) toast.error('Pembayaran sudah Kadaluarsa/Dibatalkan.');
        } else {
          if (!isAuto) toast.info('Pembayaran masih pending, silakan tunggu.');
        }
      } else {
        // Auto-expire locally if timer has passed
        if (result.expiredAt && new Date(result.expiredAt).getTime() < Date.now()) {
          setPaymentStatus('EXPIRED');
          clearActiveDeposit();
          return;
        }
        if (!isAuto) toast.info('Pembayaran masih pending, silakan tunggu.');
      }
    } catch (err) {
      console.error(err);
      if (!isAuto) toast.error('Gagal mengecek status pembayaran');
    } finally {
      if (!isAuto) setTimeout(() => setCheckingStatus(false), 800);
    }
  };

  // Auto Polling for Status — every 5 seconds, persists across focus changes
  useEffect(() => {
    if (!result || paymentStatus === 'SUCCESS' || paymentStatus === 'EXPIRED' || paymentStatus === 'CANCEL') return;

    // Check immediately on mount/change
    handleCheckStatus(true);

    const intervalId = setInterval(() => {
      handleCheckStatus(true);
    }, 5000);

    return () => clearInterval(intervalId);
  }, [result, paymentStatus]);

  // Also check when tab becomes visible again (user returns)
  useEffect(() => {
    if (!result || paymentStatus === 'SUCCESS' || paymentStatus === 'EXPIRED' || paymentStatus === 'CANCEL') return;

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        handleCheckStatus(true);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [result, paymentStatus]);

  const handleCopy = async (text: string) => {
    await copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // SUCCESS / QRIS DISPLAY STATE
  if (result) {
    const isSuccess = paymentStatus === 'SUCCESS';
    const isExpired = paymentStatus === 'EXPIRED' || paymentStatus === 'CANCEL';

    return (
      <div className="grid lg:grid-cols-5 gap-6 items-start">
        <div className="lg:col-span-3 space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700 ease-out">
          <div className="bg-white dark:bg-[#15151c] rounded-3xl p-6 md:p-8 shadow-xl border border-slate-100 dark:border-white/5 relative overflow-hidden">
            {/* Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-blue-50/50 to-transparent dark:from-blue-900/10 pointer-events-none" />
            
            <div className="text-center mb-8 relative z-10">
              {isSuccess ? (
                <>
                  <div className="w-20 h-20 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-green-50 dark:border-green-500/10">
                    <Check className="w-10 h-10 text-green-500" />
                  </div>
                  <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2 tracking-tight">Pembayaran Berhasil!</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Saldo telah ditambahkan ke akun Anda.</p>
                </>
              ) : isExpired ? (
                 <>
                  <div className="w-20 h-20 bg-rose-100 dark:bg-rose-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-rose-50 dark:border-rose-500/10">
                    <X className="w-10 h-10 text-rose-500" />
                  </div>
                  <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2 tracking-tight">Pembayaran Kadaluarsa</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Silahkan buat permintaan deposit baru.</p>
                </>
              ) : (
                <>
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Selesaikan Pembayaran</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Bayar sebelum waktu habis untuk menghindari pembatalan otomatis.</p>
                  <CountdownTimer targetDate={result.expiredAt} onExpire={() => setPaymentStatus('EXPIRED')} />
                </>
              )}
            </div>

            {!isSuccess && !isExpired && (
              <>
                <div className="flex flex-col items-center justify-center mb-8 bg-slate-50 dark:bg-[#0a0a0f] py-6 rounded-2xl border border-slate-100 dark:border-white/5">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider flex items-center gap-1.5"><Wallet className="w-4 h-4"/> Total Pembayaran</span>
                  <span className="text-4xl sm:text-5xl font-black text-[#0066FF] dark:text-[#3385FF] tracking-tighter">{formatRupiah(result.amount)}</span>
                </div>

                {result.qrImage && (
                  <div className="flex justify-center w-full mb-6 relative">
                    <div className="bg-white p-4 rounded-[2rem] border-4 border-slate-100 dark:border-slate-800 shadow-2xl w-full max-w-[300px] relative overflow-hidden flex flex-col items-center justify-center group transition-all duration-300 hover:shadow-blue-500/10 hover:border-blue-500/20">
                      {/* Corner accents */}
                      <div className="absolute top-4 left-4 w-6 h-6 border-t-4 border-l-4 border-[#0066FF] rounded-tl-lg" />
                      <div className="absolute top-4 right-4 w-6 h-6 border-t-4 border-r-4 border-[#0066FF] rounded-tr-lg" />
                      <div className="absolute bottom-4 left-4 w-6 h-6 border-b-4 border-l-4 border-[#0066FF] rounded-bl-lg" />
                      <div className="absolute bottom-4 right-4 w-6 h-6 border-b-4 border-r-4 border-[#0066FF] rounded-br-lg" />
                      <img src={result.qrImage} alt="QRIS Code" className="w-[85%] h-auto object-contain relative z-10 py-4 transition-transform duration-500 group-hover:scale-105" />
                    </div>
                  </div>
                )}

                {result.qrString && (
                  <div className="flex flex-col gap-2 max-w-[320px] mx-auto mb-8">
                    <p className="text-center text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Atau salin kode QRIS</p>
                    <div className="flex items-center gap-2 p-2 pl-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 shadow-inner">
                      <code className="flex-1 text-xs text-slate-700 dark:text-slate-300 truncate font-mono">{result.qrString}</code>
                      <button
                        onClick={() => handleCopy(result.qrString!)}
                        className="flex-shrink-0 p-2.5 rounded-xl bg-[#0066FF] text-white hover:bg-[#0052cc] transition-colors shadow-md shadow-[#0066FF]/20"
                      >
                        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}

            <div className="grid grid-cols-2 gap-3 mt-8">
               <button 
                  onClick={() => { clearActiveDeposit(); setResult(null); setStep(1); setMethod(''); setAmount(50000); setPaymentStatus(null); }} 
                  className="w-full py-4 rounded-2xl font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
                >
                  {isSuccess || isExpired ? 'Kembali' : 'Batalkan'}
                </button>
                
               {!isSuccess && !isExpired && (
                <button 
                  onClick={() => handleCheckStatus(false)}
                  disabled={checkingStatus}
                  className="w-full py-4 rounded-2xl font-bold text-white bg-[#0066FF] hover:bg-[#0052cc] transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#0066FF]/25 disabled:opacity-70"
                >
                  {checkingStatus ? <Loader2 className="w-5 h-5 animate-spin" /> : <RefreshCcw className="w-5 h-5" />}
                  Cek Status
                </button>
               )}
            </div>

            <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex items-start gap-3">
               <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <ShieldCheck className="w-5 h-5 text-[#0066FF]" />
               </div>
               <div>
                 <p className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">Pembayaran Aman & Otomatis</p>
                 <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">Sistem akan secara otomatis memverifikasi pembayaran Anda dalam 1-3 menit. Jika ada kendala, hubungi support dengan menyertakan ID: <span className="font-mono text-slate-700 dark:text-slate-300">{result.depositId}</span></p>
               </div>
            </div>

          </div>
        </div>
        <div className="lg:col-span-2 hidden lg:block">
          <PaymentHistory />
        </div>
      </div>
    );
  }

  // WIZARD UI
  return (
    <div className="grid lg:grid-cols-5 gap-6 items-start">
      <div className="lg:col-span-3 max-w-[500px] w-full mx-auto lg:mx-0 lg:max-w-none bg-[#F8FAFC] dark:bg-[#0a0a0f] sm:bg-transparent">
      
      <div className="bg-white dark:bg-[#15151c] sm:rounded-3xl sm:border sm:border-slate-200/60 dark:sm:border-white/5 shadow-sm overflow-hidden flex flex-col h-full sm:h-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-white/5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-[#0066FF]" />
            </div>
            <h1 className="text-[17px] font-bold text-slate-900 dark:text-white tracking-tight">Payment Deposit</h1>
          </div>
          <Link href="/client/dashboard" className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-white/5 text-slate-500 transition-colors bg-slate-50 dark:bg-white/5">
            <X className="w-4 h-4" />
          </Link>
        </div>

        <div className="flex-1 bg-[#F8FAFC] dark:bg-[#0f0f13] px-4 py-8 md:px-8">
          
          <div className="text-center mb-8">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2 tracking-tight">Top Up Saldo</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs mx-auto">Pilih nominal deposit untuk mulai membeli layanan kami.</p>
          </div>

          {/* Stepper */}
          <div className="flex items-center justify-between mb-8 max-w-[320px] mx-auto relative">
            <div className="absolute top-5 left-[10%] right-[10%] h-[2px] bg-slate-200 dark:bg-slate-800 -z-10 rounded-full" />
            
            {/* Dynamic Progress Line */}
            <div 
              className="absolute top-5 left-[10%] h-[3px] bg-gradient-to-r from-[#0066FF] to-blue-400 -z-10 transition-all duration-500 ease-out rounded-full shadow-[0_0_10px_rgba(0,102,255,0.5)]"
              style={{ width: `${(step - 1) * 40}%` }}
            />

            {[
              { num: 1, label: 'Nominal' },
              { num: 2, label: 'Metode' },
              { num: 3, label: 'Bayar' }
            ].map((s) => {
              const isActive = step === s.num;
              const isPassed = step > s.num;
              
              return (
                <div key={s.num} className="flex flex-col items-center gap-2 bg-[#F8FAFC] dark:bg-[#0f0f13] px-2">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 border-2 shadow-sm",
                    isActive ? "bg-[#0066FF] border-[#0066FF] text-white ring-[6px] ring-[#0066FF]/20" : 
                    isPassed ? "bg-white dark:bg-[#1a1a24] border-[#0066FF] text-[#0066FF]" : 
                    "bg-white dark:bg-[#1a1a24] border-slate-200 dark:border-slate-700 text-slate-400"
                  )}>
                    {isPassed ? <Check className="w-5 h-5" /> : s.num}
                  </div>
                  <span className={cn(
                    "text-[11px] font-bold uppercase tracking-wider transition-colors",
                    isActive ? "text-[#0066FF]" : 
                    isPassed ? "text-slate-700 dark:text-slate-300" : 
                    "text-slate-400 dark:text-slate-500"
                  )}>{s.label}</span>
                </div>
              )
            })}
          </div>

          {error && (
            <div className="px-4 py-3 mb-6 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-sm font-medium text-red-600 dark:text-red-400 flex items-center gap-3 animate-in slide-in-from-top-2">
              <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-500/20 flex items-center justify-center flex-shrink-0">
                <Info className="w-4 h-4" />
              </div>
              {error}
            </div>
          )}

          {/* ── STEP 1: NOMINAL ── */}
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="grid grid-cols-2 gap-3 mb-6">
                {AMOUNTS.map((a) => {
                  const isSelected = amount === a.value;
                  return (
                    <button
                      key={a.value}
                      onClick={() => { setAmount(a.value); }}
                      className={cn(
                        'flex flex-col items-center justify-center py-5 rounded-2xl transition-all duration-200 border-2 relative overflow-hidden group',
                        isSelected
                          ? 'bg-[#EBF3FF] dark:bg-[#0066FF]/10 border-[#0066FF] shadow-md shadow-[#0066FF]/10'
                          : 'bg-white dark:bg-[#1a1a24] border-slate-100 dark:border-white/5 hover:border-slate-300 dark:hover:border-white/10 hover:shadow-sm'
                      )}
                    >
                      {isSelected && (
                         <div className="absolute top-0 left-0 w-full h-1 bg-[#0066FF]" />
                      )}
                      <span className={cn("text-lg font-black mb-1.5 transition-colors", isSelected ? "text-[#0066FF] dark:text-[#3385FF]" : "text-slate-700 dark:text-white group-hover:text-slate-900 dark:group-hover:text-white")}>
                        {formatRupiah(a.value)}
                      </span>
                      <span className={cn(
                        "text-[10px] px-2.5 py-1 rounded-full font-bold flex items-center gap-1.5 uppercase tracking-wider transition-colors",
                        isSelected ? "bg-[#0066FF] text-white" : "bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400 group-hover:bg-slate-200 dark:group-hover:bg-white/10"
                      )}>
                        {a.label} {a.emoji}
                      </span>
                    </button>
                  )
                })}
              </div>

              <div className="bg-white dark:bg-[#1a1a24] rounded-2xl p-5 border-2 border-slate-100 dark:border-white/5 shadow-sm mb-6 relative group">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    Nominal Lainnya
                  </label>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-white/5 px-2 py-1 rounded-md border border-slate-200 dark:border-white/5">MIN 3.000</span>
                </div>
                <div className="relative flex items-center border-2 border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden focus-within:border-[#0066FF] focus-within:ring-4 focus-within:ring-[#0066FF]/10 transition-all bg-slate-50 dark:bg-black/20">
                  <span className="px-4 text-sm font-black text-slate-400 border-r border-slate-200 dark:border-slate-700 py-3.5">Rp</span>
                  <input
                    type="number"
                    value={amount === '' ? '' : amount}
                    onChange={(e) => {
                      const val = e.target.value;
                      setAmount(val === '' ? '' : parseInt(val, 10));
                    }}
                    placeholder="Masukkan nominal..."
                    className="flex-1 w-full px-4 py-3.5 text-base font-bold bg-transparent focus:outline-none dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600"
                  />
                  {amount !== '' && (
                    <button onClick={() => setAmount('')} className="px-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              <button
                onClick={() => { if (isValidAmount) setStep(2); else setError('Nominal tidak valid') }}
                disabled={!isValidAmount}
                className={cn(
                  'w-full py-4 text-sm font-bold rounded-2xl transition-all duration-300 flex items-center justify-center gap-2',
                  isValidAmount 
                    ? 'bg-[#0066FF] hover:bg-[#0052cc] text-white shadow-xl shadow-[#0066FF]/25 hover:shadow-2xl hover:shadow-[#0066FF]/30 translate-y-0 hover:-translate-y-0.5' 
                    : 'bg-slate-100 dark:bg-white/5 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-white/5'
                )}
              >
                Pilih Metode Pembayaran
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ── STEP 2: METODE PEMBAYARAN ── */}
          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              
              <div className="bg-[#EBF3FF] dark:bg-[#0066FF]/10 border border-[#0066FF]/20 rounded-2xl p-4 mb-6 flex items-center justify-between">
                 <div className="flex flex-col">
                   <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider mb-1">Nominal Top Up</span>
                   <span className="text-xl font-black text-slate-900 dark:text-white">{formatRupiah(finalAmount)}</span>
                 </div>
                 <button onClick={() => setStep(1)} className="text-xs font-bold text-slate-500 hover:text-[#0066FF] bg-white dark:bg-black/20 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/5 transition-colors">
                   Ubah
                 </button>
              </div>

              <div className="grid gap-3 mb-8">
                {METHODS.map((m) => {
                  const isSelected = method === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setMethod(m.id)}
                      className={cn(
                        'flex items-center gap-4 p-4 rounded-2xl text-left transition-all duration-200 border-2 group bg-white dark:bg-[#1a1a24] relative overflow-hidden',
                        isSelected
                          ? 'border-[#0066FF] shadow-md shadow-[#0066FF]/10'
                          : 'border-slate-100 dark:border-white/5 hover:border-slate-300 dark:hover:border-white/10 hover:shadow-sm'
                      )}
                    >
                      {isSelected && <div className="absolute inset-0 bg-[#0066FF]/5 dark:bg-[#0066FF]/10 pointer-events-none" />}
                      <div className="w-16 h-12 rounded-xl bg-white p-2 border border-slate-100 shadow-sm flex items-center justify-center flex-shrink-0 relative z-10 group-hover:scale-105 transition-transform">
                        <img src={m.logo} alt={m.label} className="w-full h-full object-contain" />
                      </div>
                      <div className="flex-1 relative z-10">
                        <p className="text-sm font-bold text-slate-900 dark:text-white mb-0.5">{m.label}</p>
                        <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                           <ShieldCheck className="w-3 h-3 text-green-500" />
                           {m.desc}
                        </p>
                      </div>
                      <div className={cn(
                        "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all relative z-10 shadow-sm",
                        isSelected ? "border-[#0066FF] bg-[#0066FF] scale-110" : "border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-black/20"
                      )}>
                        {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                      </div>
                    </button>
                  )
                })}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  className="px-5 py-4 rounded-2xl font-bold text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1a1a24] border-2 border-slate-200 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/10 transition-colors"
                >
                  Kembali
                </button>
                <button
                  onClick={() => { 
                    if(method) { 
                      setFee(Math.floor(Math.random() * (800 - 100 + 1)) + 100);
                      setStep(3); 
                    } else { 
                      setError('Pilih metode pembayaran');
                    } 
                  }}
                  disabled={!method}
                  className={cn(
                    'flex-1 py-4 text-sm font-bold rounded-2xl transition-all duration-300 flex items-center justify-center gap-2',
                    method 
                      ? 'bg-[#0066FF] hover:bg-[#0052cc] text-white shadow-xl shadow-[#0066FF]/25 hover:-translate-y-0.5' 
                      : 'bg-slate-100 dark:bg-white/5 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-white/5'
                  )}
                >
                  Konfirmasi Pilihan
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ── STEP 3: KONFIRMASI ── */}
          {step === 3 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="bg-white dark:bg-[#1a1a24] rounded-3xl p-6 border border-slate-200 dark:border-white/5 shadow-xl shadow-slate-200/20 dark:shadow-black/40 mb-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-[#0066FF]" />
                
                <div className="flex items-center gap-4 pb-6 border-b border-dashed border-slate-200 dark:border-slate-700">
                  <div className="w-16 h-12 rounded-xl bg-white p-2 border border-slate-100 shadow-sm flex items-center justify-center flex-shrink-0">
                    <img src={METHODS.find(m => m.id === method)?.logo} alt="Metode" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Metode Terpilih</p>
                    <p className="text-base font-black text-slate-800 dark:text-white">{METHODS.find(m => m.id === method)?.label}</p>
                  </div>
                </div>

                <div className="py-6 space-y-4 border-b border-dashed border-slate-200 dark:border-slate-700">
                  <div className="flex justify-between items-center text-sm font-semibold text-slate-600 dark:text-slate-400">
                    <span>Nominal Deposit</span>
                    <span className="text-slate-900 dark:text-white">{formatRupiah(finalAmount)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm font-semibold text-slate-600 dark:text-slate-400">
                    <span>Biaya Layanan</span>
                    <span className="bg-green-100 text-green-700 dark:bg-green-500/20 dark:text-green-400 px-2 py-0.5 rounded text-xs font-bold uppercase">Gratis</span>
                  </div>
                  <div className="flex justify-between items-center text-sm font-semibold text-slate-600 dark:text-slate-400">
                    <span>Biaya Admin</span>
                    <span className="text-rose-500 dark:text-rose-400">+ {formatRupiah(fee)}</span>
                  </div>
                </div>

                <div className="pt-6 flex justify-between items-center">
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200">Total Pembayaran</span>
                  <span className="text-2xl font-black text-[#0066FF] tracking-tight">{formatRupiah(finalAmount + fee)}</span>
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-500/10 rounded-2xl p-4 mb-6 border border-blue-100 dark:border-blue-500/20 flex items-start gap-3">
                 <Info className="w-5 h-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                 <p className="text-xs text-blue-800 dark:text-blue-300 leading-relaxed font-medium">
                   Harap pastikan jumlah transfer sesuai dengan total pembayaran hingga 3 digit terakhir untuk mempercepat proses verifikasi otomatis.
                 </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  disabled={loading}
                  className="px-5 py-4 rounded-2xl font-bold text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1a1a24] border-2 border-slate-200 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/10 transition-colors disabled:opacity-50"
                >
                  Kembali
                </button>
                <button
                  onClick={handleDeposit}
                  disabled={loading}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-2 py-4 text-sm font-bold rounded-2xl',
                    'bg-[#0066FF] hover:bg-[#0052cc] text-white shadow-xl shadow-[#0066FF]/25 hover:-translate-y-0.5',
                    'disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-300 disabled:hover:translate-y-0'
                  )}
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                    <>
                      <Wallet className="w-5 h-5" />
                      Bayar Sekarang
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
      </div>
      <div className="lg:col-span-2 hidden lg:block">
        <PaymentHistory />
      </div>
    </div>
  );
}
