/**
 * Dashboard Layout — /client/*
 * Top navbar layout inspired by RumahOTP with horizontal navigation.
 */

'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import {
  Zap, Home, Wallet, ShoppingCart, Activity, User, Settings, LogOut,
  Menu, X, Bell, Sun, Moon, ChevronDown
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { cn, formatRupiah } from '@/lib/utils';
import api, { setAccessToken } from '@/lib/api';
import { useAuthStore } from '@/store/useAuthStore';
import { Footer } from '@/components/layout/Footer';

const NAV = [
  { label: 'Home', href: '/client/dashboard', icon: Home },
  { label: 'Deposit', href: '/client/topup', icon: Wallet },
  { label: 'Orders', href: '/client/virtual-number', icon: ShoppingCart },
  { label: 'Activity', href: '/client/activity', icon: Activity },
  { label: 'Profile', href: '/client/profile', icon: User },
];

interface UserData {
  userId: string;
  email: string;
  firstName?: string;
  lastName?: string;
  username?: string;
  balance: number;
  avatar?: string;
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    // Handle OAuth redirect: extract token from URL if present
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const oauthToken = params.get('token');
      if (oauthToken) {
        setAccessToken(oauthToken);
        // Clean the URL without reload
        window.history.replaceState({}, '', window.location.pathname);
      }
    }

    async function fetchUser() {
      try {
        const { data } = await api.get('/api/v1/user/profile');
        setUser(data.data);
      } catch {
        router.push('/login');
      } finally {
        setLoading(false);
      }
    }
    fetchUser();
  }, [router]);

  const handleLogout = async () => {
    try {
      await api.post('/api/v1/auth/logout');
    } catch { /* ignore */ }
    setAccessToken(null);
    useAuthStore.getState().logout();
    window.location.href = '/login';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-[#0a0a0f]">
        <div className="flex flex-col items-center gap-3">
          <Zap className="w-8 h-8 text-amber-500 animate-pulse" />
          <p className="text-sm text-slate-500">Loading...</p>
        </div>
      </div>
    );
  }

  const displayName = user?.firstName || user?.username || user?.email?.split('@')[0] || 'User';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0a0a0f]">
      {/* ── Top Navbar ──────────────────────────────── */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-[#111118]/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Left: Logo */}
            <Link href="/" className="flex items-center gap-2 group flex-shrink-0">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <Image 
                  src="/images/otpyuk-mascot-run.webp" 
                  alt="OtpYuk Logo" 
                  width={40} 
                  height={40} 
                  className="object-contain"
                />
              </div>
              <span className="text-lg font-bold hidden sm:block">
                <span className="text-amber-500">Otp</span>
                <span className="text-slate-800 dark:text-white">Yuk</span>
              </span>
            </Link>

            {/* Center: Nav Links (desktop) */}
            <nav className="hidden md:flex items-center gap-1">
              {NAV.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      'flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200',
                      active
                        ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    {active && <span className="w-1.5 h-1.5 rounded-full bg-amber-500 absolute -top-0.5 -right-0.5" />}
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            {/* Right: Actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Theme toggle */}
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-500 hover:text-slate-700 dark:hover:text-white transition-colors"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* Notification bell */}
              <button className="relative w-9 h-9 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-500 hover:text-slate-700 dark:hover:text-white transition-colors">
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              </button>

              {/* Balance pill */}
              <Link
                href="/client/topup"
                className="hidden sm:flex items-center gap-3 px-3 py-1.5 rounded-xl bg-white dark:bg-[#1a1a24] border border-slate-200 dark:border-white/10 shadow-sm hover:shadow-md transition-all"
              >
                <div className="flex flex-col items-end justify-center">
                  <span className="text-[13px] font-black text-slate-900 dark:text-white leading-none mb-1">
                    {user?.balance || 0} IDR
                  </span>
                  <span className="text-[10px] font-semibold text-green-600 dark:text-green-500 leading-none">
                    Balance amount
                  </span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0 shadow-sm">
                  <Wallet className="w-4 h-4 text-white" />
                </div>
              </Link>

              {/* User avatar + dropdown */}
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-white/5 flex items-center justify-center">
                    <img 
                      src={user?.avatar || '/images/otpyuk-mascot-happy.webp'} 
                      alt={displayName} 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = '/images/otpyuk-mascot-happy.webp';
                        e.currentTarget.onerror = null;
                      }}
                    />
                  </div>
                  <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:block" />
                </button>

                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                    <div className="absolute right-0 top-12 z-50 w-56 bg-white dark:bg-[#1a1a24] rounded-xl shadow-xl border border-slate-200 dark:border-white/10 p-2">
                      <div className="px-3 py-2 border-b border-slate-100 dark:border-white/5 mb-1">
                        <p className="text-sm font-semibold text-slate-800 dark:text-white">{displayName}</p>
                        <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                        <p className="text-xs font-bold text-amber-500 mt-1 sm:hidden">{formatRupiah(user?.balance || 0)}</p>
                      </div>
                      <Link href="/client/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors">
                        <User className="w-4 h-4" /> Profil
                      </Link>
                      <Link href="/client/developer" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors">
                        <Settings className="w-4 h-4" /> Developer
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        <LogOut className="w-4 h-4" /> Keluar
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Mobile hamburger */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden w-9 h-9 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-500"
              >
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Nav */}
          {mobileMenuOpen && (
            <nav className="md:hidden pb-4 pt-2 border-t border-slate-100 dark:border-white/5 flex flex-col gap-1">
              {NAV.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-xl transition-all',
                      active
                        ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400'
                        : 'text-slate-600 dark:text-slate-400'
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                );
              })}
              {/* Mobile balance */}
              <Link
                href="/client/topup"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between px-3 py-2.5 text-sm font-bold text-amber-600 dark:text-amber-400"
              >
                <span>Saldo: {formatRupiah(user?.balance || 0)}</span>
                <Wallet className="w-4 h-4" />
              </Link>
            </nav>
          )}
        </div>
      </header>

      {/* ── Page Content ────────────────────────────── */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 min-h-[calc(100vh-140px)]">
        {children}
      </main>

      {/* ── Footer ──────────────────────────────────── */}
      <Footer />
    </div>
  );
}
