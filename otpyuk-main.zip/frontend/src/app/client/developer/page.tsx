'use client';

import { Code2, Sparkles } from 'lucide-react';
import Link from 'next/link';

export default function DeveloperPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <div className="w-20 h-20 bg-blue-50 dark:bg-blue-500/10 rounded-full flex items-center justify-center mb-6 relative">
        <div className="absolute inset-0 rounded-full border border-blue-200 dark:border-blue-500/20 animate-ping opacity-20"></div>
        <Code2 className="w-10 h-10 text-blue-500" />
      </div>
      
      <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white mb-4 flex items-center gap-3">
        Developer Hub <Sparkles className="w-6 h-6 text-blue-400" />
      </h1>
      
      <p className="text-lg text-slate-500 dark:text-slate-400 max-w-xl mx-auto mb-8">
        Portal Developer sedang dalam tahap pengembangan. Fitur pengelolaan API Key, Webhook, dan Sandbox akan segera hadir di sini.
      </p>

      <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-slate-900 dark:bg-white text-white dark:text-black font-bold uppercase tracking-widest text-sm shadow-xl shadow-black/10 mb-6">
        <span className="relative flex h-3 w-3 mr-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
        </span>
        Coming Soon
      </div>

      <div className="flex items-center gap-4">
        <Link 
          href="/client/dashboard"
          className="text-sm font-semibold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors"
        >
          &larr; Kembali
        </Link>
        <span className="text-slate-300 dark:text-slate-700">|</span>
        <Link 
          href="/developer/api"
          className="text-sm font-semibold text-amber-500 hover:text-amber-600 transition-colors"
        >
          Lihat Docs API &rarr;
        </Link>
      </div>
    </div>
  );
}
