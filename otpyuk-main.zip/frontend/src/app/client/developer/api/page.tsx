'use client';

import { FileJson, Sparkles } from 'lucide-react';
import Link from 'next/link';

export default function ApiDocsPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <div className="w-20 h-20 bg-amber-50 dark:bg-amber-500/10 rounded-full flex items-center justify-center mb-6 relative">
        <div className="absolute inset-0 rounded-full border border-amber-200 dark:border-amber-500/20 animate-ping opacity-20"></div>
        <FileJson className="w-10 h-10 text-amber-500" />
      </div>
      
      <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white mb-4 flex items-center gap-3">
        API Documentation <Sparkles className="w-6 h-6 text-amber-400" />
      </h1>
      
      <p className="text-lg text-slate-500 dark:text-slate-400 max-w-xl mx-auto mb-8">
        Kami sedang membangun dokumentasi API yang lengkap agar Anda dapat mengintegrasikan layanan otpyuk ke dalam bot Telegram, Discord, atau aplikasi custom Anda dengan mudah.
      </p>

      <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-slate-900 dark:bg-white text-white dark:text-black font-bold uppercase tracking-widest text-sm shadow-xl shadow-black/10">
        <span className="relative flex h-3 w-3 mr-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
        </span>
        Coming Soon
      </div>

      <Link 
        href="/client/dashboard"
        className="mt-10 text-sm font-semibold text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
      >
        &larr; Kembali ke Dashboard
      </Link>
    </div>
  );
}
