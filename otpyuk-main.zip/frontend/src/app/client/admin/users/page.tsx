/**
 * Admin Users Page — /client/admin/users
 * User management with search, suspension toggle, balance adjustment, and role management.
 */

'use client';

import { useEffect, useState, useCallback } from 'react';
import { 
  Users, Search, Ban, CheckCircle, Loader2, ChevronLeft, ChevronRight,
  Shield, User, Crown, Wallet, Plus, Minus, X, Edit3
} from 'lucide-react';
import { cn, formatRupiah, formatDateShort } from '@/lib/utils';
import api from '@/lib/api';

interface UserItem {
  id: string;
  userId: string;
  username?: string;
  email: string;
  firstName?: string;
  lastName?: string;
  balance: number;
  role: string;
  isActive: boolean;
  isVerified: boolean;
  createdAt: string;
  _count: { orders: number; deposits: number };
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [togglingId, setTogglingId] = useState('');
  
  // Balance Modal states
  const [balanceModal, setBalanceModal] = useState<{ 
    open: boolean; 
    userId: string; 
    email: string; 
    currentBalance: number;
    action: 'add' | 'subtract';
  }>({ 
    open: false, 
    userId: '', 
    email: '', 
    currentBalance: 0,
    action: 'add' 
  });
  
  // Role Modal states
  const [roleModal, setRoleModal] = useState<{ 
    open: boolean; 
    userId: string; 
    email: string; 
    currentRole: string 
  }>({ 
    open: false, 
    userId: '', 
    email: '', 
    currentRole: '' 
  });
  
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/api/v1/admin/users?page=${page}&limit=15`);
      setUsers(data.data || []);
      setTotalPages(data.meta?.totalPages || 1);
    } catch { 
      // ignore
    } finally { 
      setLoading(false); 
    }
  }, [page]);

  useEffect(() => { 
    fetchUsers(); 
  }, [fetchUsers]);

  const toggleStatus = async (userId: string) => {
    setTogglingId(userId);
    try {
      await api.patch(`/api/v1/admin/users/${userId}/status`);
      fetchUsers();
    } catch { 
      // ignore
    } finally { 
      setTogglingId(''); 
    }
  };

  const updateBalance = async () => {
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      alert('Masukkan nominal yang valid (angka positif)');
      return;
    }

    setSubmitting(true);
    const numAmount = balanceModal.action === 'add' ? parseFloat(amount) : -parseFloat(amount);
    
    try {
      await api.patch(`/api/v1/admin/users/${balanceModal.userId}/balance`, {
        amount: numAmount,
        description: description || `Admin ${balanceModal.action === 'add' ? 'tambah' : 'kurang'} saldo: ${formatRupiah(parseFloat(amount))}`
      });
      alert(`Berhasil ${balanceModal.action === 'add' ? 'menambah' : 'mengurangi'} saldo!`);
      setBalanceModal({ open: false, userId: '', email: '', currentBalance: 0, action: 'add' });
      setAmount('');
      setDescription('');
      fetchUsers();
    } catch (error: any) {
      alert(error?.response?.data?.error?.message || 'Gagal mengubah saldo');
    } finally {
      setSubmitting(false);
    }
  };

  const updateRole = async () => {
    if (!selectedRole) {
      alert('Pilih role terlebih dahulu');
      return;
    }

    setSubmitting(true);
    try {
      await api.patch(`/api/v1/admin/users/${roleModal.userId}/role`, { role: selectedRole });
      alert(`Berhasil mengubah role menjadi ${selectedRole}`);
      setRoleModal({ open: false, userId: '', email: '', currentRole: '' });
      setSelectedRole('');
      fetchUsers();
    } catch (error: any) {
      alert(error?.response?.data?.error?.message || 'Gagal mengubah role');
    } finally {
      setSubmitting(false);
    }
  };

  const openBalanceModal = (user: UserItem, action: 'add' | 'subtract') => {
    setBalanceModal({
      open: true,
      userId: user.id,
      email: user.email,
      currentBalance: user.balance,
      action
    });
    setAmount('');
    setDescription('');
  };

  const openRoleModal = (user: UserItem) => {
    setRoleModal({
      open: true,
      userId: user.id,
      email: user.email,
      currentRole: user.role
    });
    setSelectedRole('');
  };

  const filtered = search
    ? users.filter((u) =>
        u.email.toLowerCase().includes(search.toLowerCase()) ||
        u.userId.toLowerCase().includes(search.toLowerCase()) ||
        (u.username || '').toLowerCase().includes(search.toLowerCase())
      )
    : users;

  const getRoleIcon = (role: string) => {
    if (role === 'ADMIN') return <Shield className="w-3.5 h-3.5" />;
    if (role === 'RESELLER') return <Crown className="w-3.5 h-3.5" />;
    return <User className="w-3.5 h-3.5" />;
  };

  const getRoleColor = (role: string) => {
    if (role === 'ADMIN') return 'bg-red-100 dark:bg-red-500/10 text-red-700 dark:text-red-400';
    if (role === 'RESELLER') return 'bg-purple-100 dark:bg-purple-500/10 text-purple-700 dark:text-purple-400';
    return 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Manajemen User</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Kelola semua pengguna platform</p>
        </div>
        <div className="text-xs text-slate-400 bg-slate-100 dark:bg-white/5 px-3 py-1.5 rounded-full">
          Total: {users.length} users
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Cari email, user ID, atau username..."
          className={cn(
            'w-full pl-10 pr-4 py-2.5 text-sm rounded-xl',
            'bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10',
            'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500'
          )}
        />
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 flex items-center justify-center">
            <Loader2 className="w-6 h-6 text-amber-500 animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-white/[0.02]">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">User</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Saldo</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Aksi Saldo</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Orders</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Role</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Aksi Role</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Joined</th>
                  <th className="text-right px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                {filtered.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
                    {/* User Info */}
                    <td className="px-5 py-3">
                      <div>
                        <p className="font-medium text-slate-800 dark:text-white">{user.email}</p>
                        <p className="text-xs text-slate-400">{user.userId}</p>
                        {user.username && <p className="text-xs text-slate-400">@{user.username}</p>}
                      </div>
                    </td>

                    {/* Balance Display */}
                    <td className="px-5 py-3">
                      <span className="font-bold text-slate-800 dark:text-white">{formatRupiah(user.balance)}</span>
                    </td>

                    {/* Balance Actions */}
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openBalanceModal(user, 'add')}
                          className="flex items-center gap-1 px-2 py-1 rounded-lg bg-green-100 dark:bg-green-500/20 text-green-600 hover:bg-green-200 dark:hover:bg-green-500/30 transition-colors text-xs font-medium"
                          title="Tambah Saldo"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Tambah
                        </button>
                        <button
                          onClick={() => openBalanceModal(user, 'subtract')}
                          className="flex items-center gap-1 px-2 py-1 rounded-lg bg-red-100 dark:bg-red-500/20 text-red-600 hover:bg-red-200 dark:hover:bg-red-500/30 transition-colors text-xs font-medium"
                          title="Kurang Saldo"
                        >
                          <Minus className="w-3.5 h-3.5" />
                          Kurang
                        </button>
                      </div>
                    </td>

                    {/* Orders Count */}
                    <td className="px-5 py-3 text-slate-600 dark:text-slate-400">
                      {user._count.orders}
                    </td>

                    {/* Role Display */}
                    <td className="px-5 py-3">
                      <span className={cn('px-2 py-1 rounded-md text-xs font-semibold uppercase flex items-center gap-1 w-fit', getRoleColor(user.role))}>
                        {getRoleIcon(user.role)}
                        {user.role}
                      </span>
                    </td>

                    {/* Role Action */}
                    <td className="px-5 py-3">
                      <button
                        onClick={() => openRoleModal(user)}
                        className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-100 dark:bg-amber-500/20 text-amber-600 hover:bg-amber-200 dark:hover:bg-amber-500/30 transition-colors text-xs font-medium"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Edit Role
                      </button>
                    </td>

                    {/* Status */}
                    <td className="px-5 py-3">
                      <span className={cn(
                        'flex items-center gap-1.5 text-xs font-medium',
                        user.isActive ? 'text-green-600 dark:text-green-400' : 'text-red-500 dark:text-red-400'
                      )}>
                        <span className={cn('w-1.5 h-1.5 rounded-full', user.isActive ? 'bg-green-500' : 'bg-red-500')} />
                        {user.isActive ? 'Active' : 'Suspended'}
                      </span>
                    </td>

                    {/* Joined Date */}
                    <td className="px-5 py-3 text-xs text-slate-400">
                      {formatDateShort(user.createdAt)}
                    </td>

                    {/* Toggle Status Action */}
                    <td className="px-5 py-3 text-right">
                      <button
                        onClick={() => toggleStatus(user.id)}
                        disabled={togglingId === user.id}
                        className={cn(
                          'p-1.5 rounded-lg transition-colors',
                          user.isActive
                            ? 'hover:bg-red-50 dark:hover:bg-red-500/10 text-red-500'
                            : 'hover:bg-green-50 dark:hover:bg-green-500/10 text-green-600'
                        )}
                        title={user.isActive ? 'Suspend User' : 'Activate User'}
                      >
                        {togglingId === user.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : user.isActive ? (
                          <Ban className="w-4 h-4" />
                        ) : (
                          <CheckCircle className="w-4 h-4" />
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 dark:border-white/5">
            <span className="text-xs text-slate-400">Page {page} of {totalPages}</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5 disabled:opacity-30 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5 disabled:opacity-30 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Balance Modal - TERPISAH */}
      {balanceModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setBalanceModal({ open: false, userId: '', email: '', currentBalance: 0, action: 'add' })}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-amber-500" />
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {balanceModal.action === 'add' ? 'Tambah Saldo' : 'Kurang Saldo'}
                </h2>
              </div>
              <button 
                onClick={() => setBalanceModal({ open: false, userId: '', email: '', currentBalance: 0, action: 'add' })} 
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-3 mb-4">
              <p className="text-sm text-slate-500">User: <span className="font-medium text-slate-700 dark:text-slate-300">{balanceModal.email}</span></p>
              <p className="text-sm text-slate-500">Saldo saat ini: <span className="font-bold text-slate-700 dark:text-slate-300">{formatRupiah(balanceModal.currentBalance)}</span></p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nominal (Rp)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Contoh: 50000"
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-amber-500"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Deskripsi (Opsional)</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Contoh: Bonus referral"
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <button
                onClick={updateBalance}
                disabled={submitting}
                className={cn(
                  'w-full py-2.5 rounded-xl font-semibold transition-all',
                  balanceModal.action === 'add'
                    ? 'bg-green-500 hover:bg-green-600 text-white'
                    : 'bg-red-500 hover:bg-red-600 text-white',
                  submitting && 'opacity-50 cursor-not-allowed'
                )}
              >
                {submitting ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : (balanceModal.action === 'add' ? 'Tambah Saldo' : 'Kurang Saldo')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Role Modal - TERPISAH */}
      {roleModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setRoleModal({ open: false, userId: '', email: '', currentRole: '' })}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-500" />
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">Ubah Role User</h2>
              </div>
              <button 
                onClick={() => setRoleModal({ open: false, userId: '', email: '', currentRole: '' })} 
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-3 mb-4">
              <p className="text-sm text-slate-500">User: <span className="font-medium text-slate-700 dark:text-slate-300">{roleModal.email}</span></p>
              <p className="text-sm text-slate-500">Role saat ini: <span className="font-bold text-amber-500">{roleModal.currentRole}</span></p>
            </div>
            
            <div className="space-y-3">
              <button
                onClick={() => setSelectedRole('USER')}
                className={cn(
                  'w-full flex items-center gap-3 p-3 rounded-xl border transition-all',
                  selectedRole === 'USER'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
                    : 'border-slate-200 dark:border-white/10 hover:border-amber-300'
                )}
              >
                <User className="w-5 h-5 text-slate-500" />
                <div className="text-left">
                  <p className="font-medium">User</p>
                  <p className="text-xs text-slate-400">Hanya bisa beli OTP</p>
                </div>
                {selectedRole === 'USER' && <CheckCircle className="w-4 h-4 ml-auto text-amber-500" />}
              </button>
              
              <button
                onClick={() => setSelectedRole('RESELLER')}
                className={cn(
                  'w-full flex items-center gap-3 p-3 rounded-xl border transition-all',
                  selectedRole === 'RESELLER'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
                    : 'border-slate-200 dark:border-white/10 hover:border-amber-300'
                )}
              >
                <Crown className="w-5 h-5 text-purple-500" />
                <div className="text-left">
                  <p className="font-medium">Reseller</p>
                  <p className="text-xs text-slate-400">Bisa jual & punya markup harga</p>
                </div>
                {selectedRole === 'RESELLER' && <CheckCircle className="w-4 h-4 ml-auto text-amber-500" />}
              </button>
              
              <button
                onClick={() => setSelectedRole('ADMIN')}
                className={cn(
                  'w-full flex items-center gap-3 p-3 rounded-xl border transition-all',
                  selectedRole === 'ADMIN'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
                    : 'border-slate-200 dark:border-white/10 hover:border-amber-300'
                )}
              >
                <Shield className="w-5 h-5 text-red-500" />
                <div className="text-left">
                  <p className="font-medium">Admin</p>
                  <p className="text-xs text-slate-400">Akses penuh ke semua fitur</p>
                </div>
                {selectedRole === 'ADMIN' && <CheckCircle className="w-4 h-4 ml-auto text-amber-500" />}
              </button>
              
              <button
                onClick={updateRole}
                disabled={submitting || !selectedRole}
                className="w-full mt-4 py-2.5 rounded-xl font-semibold bg-amber-500 hover:bg-amber-600 text-white disabled:opacity-50 transition-all"
              >
                {submitting ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'Simpan Perubahan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
