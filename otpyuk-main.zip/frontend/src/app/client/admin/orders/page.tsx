/**
 * Admin Orders Page — /client/admin/orders
 * View all system orders with user info and pagination.
 */

'use client';

import { useEffect, useState, useCallback } from 'react';
import { ShoppingCart, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { cn, formatRupiah, formatDateShort, getStatusColor } from '@/lib/utils';
import api from '@/lib/api';

interface OrderItem {
  id: string;
  orderId: string;
  serviceName: string;
  phoneNumber: string;
  country: string;
  price: number;
  status: string;
  otpCode?: string;
  createdAt: string;
  user: { userId: string; email: string };
}

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/api/v1/admin/orders?page=${page}&limit=20`);
      setOrders(data.data || []);
      setTotalPages(data.meta?.totalPages || 1);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  }, [page]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Semua Pesanan</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Monitor pesanan seluruh sistem</p>
      </div>

      <div className="bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 flex items-center justify-center">
            <Loader2 className="w-6 h-6 text-amber-500 animate-spin" />
          </div>
        ) : orders.length === 0 ? (
          <div className="p-12 text-center">
            <ShoppingCart className="w-10 h-10 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-400">Belum ada pesanan</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-white/[0.02]">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Order</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">User</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Layanan</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Nomor</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Harga</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Waktu</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                {orders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{order.orderId}</td>
                    <td className="px-5 py-3">
                      <p className="text-xs text-slate-600 dark:text-slate-400">{order.user.email}</p>
                    </td>
                    <td className="px-5 py-3 font-medium text-slate-800 dark:text-white">{order.serviceName}</td>
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{order.phoneNumber}</td>
                    <td className="px-5 py-3 font-semibold text-slate-800 dark:text-white">{formatRupiah(order.price)}</td>
                    <td className="px-5 py-3">
                      <span className={cn('px-2 py-0.5 rounded-md text-[10px] font-semibold uppercase', getStatusColor(order.status))}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-xs text-slate-400">{formatDateShort(order.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 dark:border-white/5">
            <span className="text-xs text-slate-400">Page {page} of {totalPages}</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5 disabled:opacity-30">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page === totalPages} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5 disabled:opacity-30">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
