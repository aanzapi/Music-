/**
 * Admin Dashboard — /client/admin/dashboard
 * System overview with stats, user count, orders, and revenue.
 */

'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, ShoppingCart, Wallet, TrendingUp, ArrowRight } from 'lucide-react';
import { cn, formatRupiah } from '@/lib/utils';
import api from '@/lib/api';

interface AdminStats {
  totalUsers: number;
  totalOrders: number;
  activeOrders: number;
  totalDeposits: number;
  pendingDeposits: number;
  totalRevenue: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetch() {
      try {
        const { data } = await api.get('/api/v1/admin/dashboard/stats');
        setStats(data.data);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    }
    fetch();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-32 rounded-2xl bg-slate-100 dark:bg-white/5 animate-pulse" />
        ))}
      </div>
    );
  }

  const statCards = [
    { label: 'Total Users', value: String(stats?.totalUsers || 0), icon: Users, color: 'from-blue-500 to-blue-600', href: '/client/admin/users' },
    { label: 'Total Orders', value: String(stats?.totalOrders || 0), icon: ShoppingCart, color: 'from-amber-500 to-amber-600', href: '/client/admin/orders' },
    { label: 'Active Orders', value: String(stats?.activeOrders || 0), icon: ShoppingCart, color: 'from-green-500 to-green-600' },
    { label: 'Total Deposits', value: String(stats?.totalDeposits || 0), icon: Wallet, color: 'from-purple-500 to-purple-600', href: '/client/admin/deposits' },
    { label: 'Pending Deposits', value: String(stats?.pendingDeposits || 0), icon: Wallet, color: 'from-orange-500 to-orange-600' },
    { label: 'Total Revenue', value: formatRupiah(stats?.totalRevenue || 0), icon: TrendingUp, color: 'from-emerald-500 to-emerald-600' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Ringkasan sistem otpyuk</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className={cn(
              'p-5 rounded-2xl card-hover',
              'bg-white dark:bg-white/[0.03]',
              'border border-slate-100 dark:border-white/5'
            )}>
              <div className="flex items-center justify-between mb-3">
                <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center bg-gradient-to-br', stat.color)}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                {stat.href && (
                  <Link href={stat.href} className="text-slate-400 hover:text-amber-500 transition-colors">
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                )}
              </div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
