/**
 * Profile Page — /client/profile
 * Premium user profile management with 2FA, password change, social links, and terminal data.
 */

'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { 
  User, Mail, Lock, Shield, Eye, EyeOff, Loader2, Check, AlertCircle, 
  Terminal as TerminalIcon, MessageCircle, Smartphone, Key, Settings
} from 'lucide-react';
import { cn, formatDate } from '@/lib/utils';
import api from '@/lib/api';
import { Terminal } from '@/components/ui/terminal';
import ReCaptcha from '@/components/common/ReCaptcha';

// Google icon
const GoogleIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

// GitHub icon
const GithubIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
  </svg>
);

interface ProfileData {
  userId: string;
  email: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  role: string;
  isVerified: boolean;
  twoFaEnabled: boolean;
  googleId?: string;
  githubId?: string;
  createdAt: string;
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const [form, setForm] = useState({ firstName: '', lastName: '', username: '' });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [showPw, setShowPw] = useState(false);
  const [changingPw, setChangingPw] = useState(false);
  const [pwCaptcha, setPwCaptcha] = useState('');

  const [setup2fa, setSetup2fa] = useState(false);
  const [twoFaCaptcha, setTwoFaCaptcha] = useState('');

  useEffect(() => {
    async function fetch() {
      try {
        const { data } = await api.get('/api/v1/user/profile');
        setProfile(data.data);
        setForm({
          firstName: data.data.firstName || '',
          lastName: data.data.lastName || '',
          username: data.data.username || '',
        });
      } catch { /* ignore */ }
      finally { setLoading(false); }
    }
    fetch();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setMessage({ type: '', text: '' });
    try {
      const { data } = await api.patch('/api/v1/user/profile', form);
      setProfile((p) => p ? { ...p, ...data.data } : null);
      setMessage({ type: 'success', text: 'Profil berhasil diperbarui!' });
      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { message?: string } } };
      setMessage({ type: 'error', text: axiosErr.response?.data?.message || 'Gagal menyimpan' });
    } finally { setSaving(false); }
  };

  const handleChangePassword = async () => {
    if (pwForm.newPassword !== pwForm.confirmPassword) {
      setMessage({ type: 'error', text: 'Password baru tidak cocok' });
      return;
    }
    setChangingPw(true);
    setMessage({ type: '', text: '' });
    try {
      await api.patch('/api/v1/user/password', {
        currentPassword: pwForm.currentPassword,
        newPassword: pwForm.newPassword,
        confirmPassword: pwForm.confirmPassword,
        recaptchaToken: pwCaptcha,
      });
      setMessage({ type: 'success', text: 'Password berhasil diubah!' });
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setPwCaptcha('');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { message?: string } } };
      setMessage({ type: 'error', text: axiosErr.response?.data?.message || 'Gagal mengubah password' });
    } finally { setChangingPw(false); }
  };

  const handleEnable2fa = async () => {
    try {
      // In a real app, this would show the QR code modal.
      // Here we simulate the API call to get the secret, which now requires ReCaptcha.
      const { data } = await api.post('/api/v1/auth/2fa/enable', { recaptchaToken: twoFaCaptcha });
      alert('2FA Setup: Scan this QR with Authenticator\\n' + data.data.otpauthUrl);
      // After scanning, the user would enter the code to confirm.
      // For now, we'll just simulate it passing.
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { message?: string } } };
      setMessage({ type: 'error', text: axiosErr.response?.data?.message || 'Gagal memulai 2FA setup' });
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
           <div key={i} className="h-48 rounded-3xl bg-slate-100 dark:bg-white/5 animate-pulse" />
        ))}
      </div>
    );
  }

  // Generate Terminal content dynamically based on user profile
  const terminalCommands = [
    'sf-cli sys check --auth',
    'sf-cli user whoami',
    'sf-cli sys status',
  ];
  const terminalOutputs = {
    0: [
      '✔ Authentication valid',
      `  userId: "${profile?.userId}"`,
      `  email: "${profile?.email}"`,
      `  status: "VERIFIED"`,
    ],
    1: [
      `  Name: "${profile?.firstName} ${profile?.lastName || ''}".trim()`,
      `  Role: "${profile?.role}"`,
      `  Joined: "${formatDate(profile?.createdAt || '')}"`,
      `  2FA: ${profile?.twoFaEnabled ? '"ENABLED"' : '"DISABLED"'}`,
    ],
    2: [
      '  API Server: "ONLINE"',
      '  Latency: "24ms"',
      '  System: "READY"',
    ],
  };

  return (
    <div className="max-w-5xl space-y-8">
      {/* ═══ Header ═══ */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-3">
            <Settings className="w-8 h-8 text-amber-500" />
            Pengaturan Akun
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Kelola profil, keamanan, dan integrasi Anda di satu tempat.</p>
        </div>
      </div>

      {message.text && (
        <div className={cn(
          'px-4 py-3 rounded-xl text-sm flex items-center gap-3 font-medium animate-in fade-in slide-in-from-top-2',
          message.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 text-green-700 dark:text-green-400'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-600 dark:text-red-400'
        )}>
          {message.type === 'success' ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {message.text}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* ═══ Left Column: Profile & Socials ═══ */}
        <div className="lg:col-span-1 space-y-8">
          
          {/* Profile Card */}
          <div className="bg-white dark:bg-[#111118] border border-slate-200 dark:border-white/10 rounded-3xl p-6 shadow-sm overflow-hidden relative group">
            <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-br from-amber-400 to-amber-600 z-0" />
            <div className="relative z-10 flex flex-col items-center mt-8 text-center">
              <div className="w-24 h-24 rounded-full bg-slate-900 border-4 border-white dark:border-[#111118] flex items-center justify-center text-white text-4xl font-bold shadow-xl mb-4 relative">
                {profile?.avatar ? (
                  <img 
                    src={profile.avatar} 
                    alt="Avatar" 
                    className="w-full h-full rounded-full object-cover" 
                    onError={(e) => {
                      e.currentTarget.src = '/images/otpyuk-mascot-happy.webp';
                      e.currentTarget.onerror = null;
                    }}
                  />
                ) : (
                  <img src="/images/otpyuk-mascot-happy.webp" alt="Avatar" className="w-full h-full rounded-full object-cover" />
                )}
                {profile?.isVerified && (
                  <div className="absolute bottom-0 right-0 bg-blue-500 text-white rounded-full p-1 border-2 border-white dark:border-[#111118]">
                    <Shield className="w-4 h-4" />
                  </div>
                )}
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {form.firstName} {form.lastName}
              </h2>
              <p className="text-slate-500 text-sm mt-1">{profile?.email}</p>
              <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-white/5 text-xs font-semibold text-slate-600 dark:text-slate-300">
                <User className="w-3.5 h-3.5" />
                ID: {profile?.userId}
              </div>
            </div>
          </div>

          {/* Connected Accounts */}
          <div className="bg-white dark:bg-[#111118] border border-slate-200 dark:border-white/10 rounded-3xl p-6 shadow-sm">
             <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-5">Integrasi Akun</h3>
             <div className="space-y-3">
                {/* Google */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white dark:bg-[#181822] shadow-sm flex items-center justify-center">
                      <GoogleIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 dark:text-white">Google</p>
                      <p className="text-xs text-slate-500">{profile?.googleId ? 'Terhubung' : 'Tidak terhubung'}</p>
                    </div>
                  </div>
                  {profile?.googleId && <Check className="w-5 h-5 text-green-500" />}
                </div>

                {/* GitHub */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white dark:bg-[#181822] shadow-sm flex items-center justify-center text-slate-900 dark:text-white">
                      <GithubIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 dark:text-white">GitHub</p>
                      <p className="text-xs text-slate-500">{profile?.githubId ? 'Terhubung' : 'Tidak terhubung'}</p>
                    </div>
                  </div>
                  {profile?.githubId && <Check className="w-5 h-5 text-green-500" />}
                </div>

                {/* Telegram (Coming Soon) */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 opacity-60">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#2AABEE]/10 flex items-center justify-center text-[#2AABEE]">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 dark:text-white">Telegram</p>
                      <p className="text-xs text-[#2AABEE] font-bold">Coming Soon</p>
                    </div>
                  </div>
                </div>

                {/* WhatsApp (Coming Soon) */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 opacity-60">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#25D366]/10 flex items-center justify-center text-[#25D366]">
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 dark:text-white">WhatsApp</p>
                      <p className="text-xs text-[#25D366] font-bold">Coming Soon</p>
                    </div>
                  </div>
                </div>
             </div>
          </div>

          {/* 2FA Card (Moved to Left Column) */}
          <div className="bg-white dark:bg-[#111118] border border-slate-200 dark:border-white/10 rounded-3xl p-6 shadow-sm flex flex-col">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-500 flex items-center justify-center mb-4">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Autentikasi 2 Langkah</h3>
            <p className="text-sm text-slate-500 mb-6 flex-1">Amankan akun Anda dengan mewajibkan kode 6 digit dari aplikasi authenticator saat login.</p>
            
            {profile?.twoFaEnabled ? (
              <div className="p-4 rounded-xl bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 text-center">
                <Check className="w-6 h-6 text-green-500 mx-auto mb-2" />
                <p className="text-sm font-bold text-green-700 dark:text-green-400">2FA Aktif & Melindungi</p>
              </div>
            ) : (
              <div className="space-y-4">
                <ReCaptcha onVerify={setTwoFaCaptcha} onExpire={() => setTwoFaCaptcha('')} />
                <button
                  onClick={handleEnable2fa}
                  disabled={!twoFaCaptcha}
                  className="w-full py-3 rounded-xl bg-slate-900 dark:bg-white/10 hover:dark:bg-white/20 text-white text-sm font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Mulai Setup 2FA
                </button>
              </div>
            )}
          </div>

        </div>

        {/* ═══ Right Column: Forms & Terminal ═══ */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Unified Basic Info & Password Card */}
          <div className="bg-white dark:bg-[#111118] border border-slate-200 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden">
            <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-white/10">
              
              {/* Left Side: Basic Info */}
              <div className="p-6 md:p-8 flex flex-col">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                  <User className="w-5 h-5 text-amber-500" />
                  Informasi Dasar
                </h3>
                
                <div className="space-y-5 flex-1">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Nama Depan</label>
                    <input
                      type="text"
                      value={form.firstName}
                      onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                      className="w-full px-4 py-3 text-sm rounded-xl bg-slate-50 dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Nama Belakang</label>
                    <input
                      type="text"
                      value={form.lastName}
                      onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                      className="w-full px-4 py-3 text-sm rounded-xl bg-slate-50 dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Username</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm text-slate-400 font-bold">@</span>
                      <input
                        type="text"
                        value={form.username}
                        onChange={(e) => setForm({ ...form, username: e.target.value })}
                        className="w-full pl-9 pr-4 py-3 text-sm rounded-xl bg-slate-50 dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="w-full flex items-center justify-center gap-2 px-6 py-3 text-sm font-bold rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-500/25 hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Simpan Profil'}
                  </button>
                </div>
              </div>

              {/* Right Side: Password */}
              <div className="p-6 md:p-8 flex flex-col bg-slate-50/50 dark:bg-white/[0.01]">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                  <Key className="w-5 h-5 text-amber-500" />
                  Ubah Password
                </h3>
                
                <div className="space-y-4 flex-1 flex flex-col">
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={pwForm.currentPassword}
                    onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
                    placeholder="Password saat ini"
                    className="w-full px-4 py-3 text-sm rounded-xl bg-white dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                  />
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={pwForm.newPassword}
                    onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
                    placeholder="Password baru"
                    className="w-full px-4 py-3 text-sm rounded-xl bg-white dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                  />
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={pwForm.confirmPassword}
                    onChange={(e) => setPwForm({ ...pwForm, confirmPassword: e.target.value })}
                    placeholder="Konfirmasi password baru"
                    className="w-full px-4 py-3 text-sm rounded-xl bg-white dark:bg-[#181822] border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                  />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="text-xs text-amber-600 dark:text-amber-500 hover:underline text-left">
                    {showPw ? 'Sembunyikan Password' : 'Lihat Password'}
                  </button>

                  <div className="mt-auto pt-4 space-y-4">
                    <ReCaptcha onVerify={setPwCaptcha} onExpire={() => setPwCaptcha('')} />
                    <button
                      onClick={handleChangePassword}
                      disabled={changingPw || !pwForm.currentPassword || !pwForm.newPassword || !pwCaptcha}
                      className="w-full py-3 text-sm font-bold rounded-xl flex items-center justify-center gap-2 bg-slate-900 dark:bg-white/10 text-white hover:dark:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      {changingPw ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Ganti Password'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Terminal System Status (Full Width) */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl overflow-hidden flex flex-col relative">
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
              <Shield className="w-32 h-32 text-white" />
            </div>
            
            <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2 mb-1">
                   <TerminalIcon className="w-5 h-5 text-amber-500" />
                   <h3 className="text-xl font-bold text-white">System Status</h3>
                </div>
                <p className="text-sm text-slate-400">Log sistem mencatat status registrasi dan keamanan akun Anda saat ini.</p>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-white/10 border border-white/10 text-white text-xs font-mono flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                SYSTEM ONLINE
              </div>
            </div>
            
            <div className="relative z-10 rounded-xl overflow-hidden shadow-2xl border border-slate-800 bg-black">
              <Terminal
                commands={terminalCommands}
                outputs={terminalOutputs}
                username={profile?.username || 'user'}
                typingSpeed={25}
                delayBetweenCommands={800}
                enableSound={false}
              />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
