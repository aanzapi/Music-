/**
 * Virtual Number Page — /client/virtual-number
 * Redesigned with Aceternity UI components.
 */

'use client';

import { useEffect, useState, useCallback } from 'react';
import { ShoppingCart, Copy, Check, X, Loader2, Clock, Zap, HeadphonesIcon, AlertCircle, Info, Ban, RotateCcw, ChevronDown, CheckCircle, RefreshCw } from 'lucide-react';
import { cn, formatRupiah, formatDateShort, getStatusColor, copyToClipboard } from '@/lib/utils';
import api from '@/lib/api';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { notify } from '@/components/ui/custom-toast';

// Aceternity UI Components
import { NoiseBackground } from '@/components/ui/noise-background';
import { TextFlippingBoard } from '@/components/ui/text-flipping-board';
import { LayoutTextFlip } from '@/components/ui/layout-text-flip';
import { DraggableCardContainer, DraggableCardBody } from '@/components/ui/draggable-card';
import { CreateOrderModal } from '@/components/orders/CreateOrderModal';

interface Order {
  orderId: string;
  serviceName: string;
  serviceImg?: string;
  phoneNumber: string;
  country: string;
  operator: string;
  server?: string;
  price: number;
  status: string;
  otpCode?: string;
  otpMessage?: string;
  expiredAt: string;
  createdAt: string;
}

const FAQ_ITEMS = [
  {
    icon: AlertCircle,
    color: 'text-amber-500',
    title: 'Ayo belajar membaca!',
    content: (
      <>
        <p>Baca dan lihat info sebelum melakukan deposit atau membeli pada website, harap tidak egois atau bersikap arogan karena segala info telah tertulis <strong>LENGKAP</strong> dalam FAQ.</p>
        <p className="mt-2">Jika system maintenance itu berarti sedang dalam perbaikan, orderan kosong berarti stock nomor habis dan belum direstock bukan berarti <strong>Tidak Dapat Order!</strong></p>
        <button className="mt-3 px-4 py-2 rounded-xl text-xs font-bold bg-blue-500 hover:bg-blue-600 text-white transition-colors">Instant Help</button>
      </>
    )
  },
  {
    icon: Info,
    color: 'text-amber-500',
    title: 'OTP gak masuk masuk',
    content: (
      <>
        <p>Kendala ini dapat terjadi karena faktor perangkat pengguna atau ketersediaan stok dari penyedia yang sedang kurang stabil.</p>
        <p className="mt-2">Perlu diingat, nomor yang digunakan adalah <strong>nomor kosong</strong>. Jika kendala masih berlanjut, disarankan menggunakan VPN untuk membantu mengurangi deteksi keamanan.</p>
      </>
    )
  },
  {
    icon: Ban,
    color: 'text-red-500',
    title: 'Cancel tapi saldo terpotong',
    content: 'Silakan hubungi customer service kami dan jelaskan kendala yang dialami dengan menyertakan ID transaksi agar saldo dapat dikembalikan 100%. Berlaku jika kode OTP belum diterima sama sekali.'
  },
  {
    icon: RotateCcw,
    color: 'text-amber-500',
    title: 'Lupa cancel active order',
    content: 'Saldo Anda kami kembalikan 100% tanpa potongan biaya apapun, karena auto cancel nomor setelah 15 menit.'
  },
  {
    icon: Check,
    color: 'text-amber-500',
    title: 'Syarat refund',
    content: (
      <>
        <p>Syarat refund adalah ketika Anda belum menerima nomor atau code verifikasi, kami kembalikan uang sesuai dengan harga yang dibeli.</p>
        <p className="font-semibold text-red-500 dark:text-red-400 mt-2">Namun jika nomor atau code sudah diterima maka refund tidak dapat dilakukan.</p>
      </>
    )
  }
];

const CountdownBadge = ({ expiredAt }: { expiredAt: string }) => {
  const [timeLeft, setTimeLeft] = useState<string>('00:00');

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(expiredAt).getTime() - Date.now();
      if (difference <= 0) return '00:00';
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);
      return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    setTimeLeft(calculateTimeLeft());
    const timer = setInterval(() => setTimeLeft(calculateTimeLeft()), 1000);
    return () => clearInterval(timer);
  }, [expiredAt]);

  const isUrgent = timeLeft !== '00:00' && parseInt(timeLeft.split(':')[0]) < 3;

  return (
    <span className={cn(
      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-colors',
      isUrgent 
        ? 'text-red-600 bg-red-100 dark:bg-red-500/20 dark:text-red-400 animate-pulse' 
        : 'text-amber-600 bg-amber-50 dark:bg-amber-500/15 dark:text-amber-400'
    )}>
      <Clock className="w-3 h-3" />
      {timeLeft}
    </span>
  );
};

export default function VirtualNumberPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [copiedId, setCopiedId] = useState('');
  const [cancelingId, setCancelingId] = useState('');
  const [resendingId, setResendingId] = useState('');
  const [buyingAgainId, setBuyingAgainId] = useState('');
  const [completingId, setCompletingId] = useState('');
  const [profile, setProfile] = useState<any>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number>(3); // Default open "Lupa cancel"
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const fetchOrders = useCallback(async (manual = false) => {
    if (manual) setIsRefreshing(true);
    try {
      const { data } = await api.get(`/api/v1/orders?status=WAITING`);
      const { data: data2 } = await api.get(`/api/v1/orders?status=RECEIVED`);
      const combined = [...(data.data || []), ...(data2.data || [])];
      const uniqueOrders = combined.filter((v, i, a) => a.findIndex(t => (t.orderId === v.orderId)) === i);
      setOrders(uniqueOrders);
    } catch { /* ignore */ }
    finally { 
      setLoading(false);
      if (manual) setIsRefreshing(false);
    }
  }, []);

  const fetchProfile = useCallback(async () => {
    try {
      const { data } = await api.get('/api/v1/user/profile');
      setProfile(data.data);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    fetchOrders();
    fetchProfile();
    const interval = setInterval(() => {
      fetchOrders();
      fetchProfile();
    }, 3000);
    return () => clearInterval(interval);
  }, [fetchOrders, fetchProfile]);

  const handleCopy = (text: string, id: string) => {
    copyToClipboard(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(''), 2000);
  };

  const handleCancel = async (orderId: string) => {
    setCancelingId(orderId);
    try {
      await api.patch(`/api/v1/orders/${orderId}/cancel`);
      notify.cancelSuccess();
      fetchOrders();
      fetchProfile();
    } catch (err: any) {
      notify.apiError(err, 'Gagal membatalkan pesanan');
    } finally {
      setCancelingId('');
    }
  };

  const handleResend = async (orderId: string) => {
    setResendingId(orderId);
    try {
      await api.patch(`/api/v1/orders/${orderId}/resend`);
      notify.resendSuccess();
      fetchOrders(true);
    } catch (err: any) {
      notify.apiError(err, 'Gagal meminta ulang kode');
    } finally {
      setResendingId('');
    }
  };

  const handleBuyAgain = async (orderId: string) => {
    if (!window.confirm('Beli ulang nomor dengan spesifikasi yang sama?')) return;
    setBuyingAgainId(orderId);
    try {
      await api.post(`/api/v1/orders/${orderId}/buy-again`);
      notify.buyAgainSuccess();
      fetchOrders(true);
      fetchProfile();
    } catch (err: any) {
      notify.apiError(err, 'Gagal membuat pesanan ulang');
    } finally {
      setBuyingAgainId('');
    }
  };

  const handleDone = async (orderId: string) => {
    setCompletingId(orderId);
    try {
      await api.patch(`/api/v1/orders/${orderId}/done`);
      notify.doneSuccess();
      fetchOrders(true);
    } catch (err: any) {
      notify.apiError(err, 'Gagal menyelesaikan pesanan');
    } finally {
      setCompletingId('');
    }
  };

  const draggableItems = [
    { title: 'WhatsApp', image: '/images/app/whatsapp.webp', className: 'absolute top-[8%] left-[8%] rotate-[-12deg] z-20' },
    { title: 'Telegram', image: '/images/app/telegram.webp', className: 'absolute top-[12%] right-[12%] rotate-[15deg] z-20' },
    { title: 'Facebook', image: '/images/app/facebook.webp', className: 'absolute bottom-[15%] left-[10%] rotate-[8deg] z-20' },
    { title: 'Instagram', image: '/images/app/instagram.webp', className: 'absolute bottom-[10%] right-[15%] rotate-[-10deg] z-20' },
    { title: 'Netflix', image: '/images/app/netflix.webp', className: 'absolute top-[45%] left-[4%] rotate-[20deg] z-20' },
    { title: 'Google', image: '/images/app/googlegmailyoutube.webp', className: 'absolute top-[35%] right-[6%] rotate-[-15deg] z-20' },
    { title: 'Twitter', image: '/images/app/twitter.webp', className: 'absolute bottom-[35%] right-[5%] rotate-[25deg] z-20' },
    { title: 'Gojek', image: '/images/app/gojek.webp', className: 'absolute top-[65%] left-[18%] rotate-[-18deg] z-20' },
    { title: 'Grab', image: '/images/app/grab.webp', className: 'absolute top-[20%] left-[25%] rotate-[5deg] z-20' },
    { title: 'Tiktok', image: '/images/app/tiktok.webp', className: 'absolute bottom-[25%] right-[30%] rotate-[-8deg] z-20' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto overflow-x-hidden">
      
      {/* ── Top Row: Balance & Buy Banner ── */}
      <div className="grid lg:grid-cols-3 gap-6">
        
        {/* Balance Card */}
        <div className="bg-white dark:bg-[#15151c] rounded-3xl p-6 border border-slate-200/60 dark:border-white/5 shadow-sm flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center overflow-hidden border border-amber-200/50 dark:border-amber-500/20">
                {profile?.avatar ? (
                  <img 
                    src={profile.avatar} 
                    alt="Avatar" 
                    className="w-full h-full object-cover" 
                    onError={(e) => {
                      e.currentTarget.src = '/images/otpyuk-mascot-happy.webp';
                      e.currentTarget.onerror = null;
                    }}
                  />
                ) : (
                  <img src="/images/otpyuk-mascot-happy.webp" alt="Avatar" className="w-full h-full object-cover" />
                )}
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Saldo Kamu</p>
                <p className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                  {profile ? formatRupiah(profile.balance) : '...'} IDR
                </p>
              </div>
            </div>
            <Link
              href="/client/topup"
              className="px-3 py-2 rounded-xl text-xs font-bold bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-500/20 transition-colors flex items-center gap-1 shrink-0"
            >
              <Zap className="w-4 h-4" /> Top Up
            </Link>
          </div>
          
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-white/5 flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-green-500 font-bold bg-green-50 dark:bg-green-500/10 px-2 py-1 rounded-md shrink-0">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Online
            </span>
            <span className="text-slate-500 dark:text-slate-400 truncate">
              <strong className="text-green-500">45ms</strong> response
            </span>
          </div>
        </div>

        {/* Buy Number Noise Banner */}
        <div className="lg:col-span-2 rounded-3xl overflow-hidden group min-h-[140px] flex items-stretch">
          <NoiseBackground
            containerClassName="w-full relative"
            className="w-full h-full p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between relative z-10"
            gradientColors={["#f59e0b", "#f97316", "#fbbf24"]}
            noiseIntensity={0.05}
          >
            {/* Floating Decorative App Icons for Top Banner */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 opacity-20 dark:opacity-30">
              <img src="/images/app/whatsapp.webp" alt="WA" className="absolute top-2 right-[40%] w-12 h-12 object-contain rotate-12 blur-[1px]" />
              <img src="/images/app/telegram.webp" alt="TG" className="absolute bottom-2 left-[35%] w-10 h-10 object-contain -rotate-12 blur-[1px]" />
              <img src="/images/app/instagram.webp" alt="IG" className="absolute -top-4 left-[20%] w-16 h-16 object-contain rotate-45 blur-[2px]" />
              <img src="/images/app/netflix.webp" alt="NFLX" className="absolute -bottom-6 right-[20%] w-20 h-20 object-contain -rotate-6 blur-[2px]" />
              <img src="/images/app/facebook.webp" alt="FB" className="absolute top-8 right-[10%] w-14 h-14 object-contain rotate-[30deg] blur-[1px]" />
            </div>

            <div className="text-white space-y-1 text-center sm:text-left mb-4 sm:mb-0 w-full sm:w-auto relative z-10">
              <h2 className="text-xl sm:text-2xl font-black drop-shadow-md">Beli Nomor Virtual</h2>
              <div className="text-xs sm:text-sm font-semibold text-white/90 drop-shadow-sm flex items-center justify-center sm:justify-start">
                <LayoutTextFlip 
                  text="Penyedia OTP untuk" 
                  words={["WhatsApp", "Telegram", "Instagram", "Facebook", "Netflix", "Google", "Gojek", "Grab"]} 
                  className="text-sm"
                />
              </div>
            </div>
            <button
              onClick={() => setIsOrderModalOpen(true)}
              className="relative z-10 whitespace-nowrap px-6 py-3 rounded-2xl bg-white text-amber-600 font-extrabold hover:scale-105 transition-transform shadow-xl shadow-black/10 text-sm flex items-center gap-2 shrink-0"
            >
              Beli Nomor &rarr;
            </button>
          </NoiseBackground>
        </div>

      </div>

      {/* ── Middle Row: Active Orders ── */}
      <div className="bg-white dark:bg-[#15151c] rounded-3xl border border-slate-200/60 dark:border-white/5 shadow-sm flex flex-col relative z-10 overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 dark:border-white/5 bg-white dark:bg-[#15151c] relative z-20 flex justify-between items-center">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Pesanan Pending</h2>
          <button 
            onClick={() => { fetchOrders(true); fetchProfile(); }}
            disabled={isRefreshing}
            className="w-8 h-8 rounded-lg flex items-center justify-center border-2 border-blue-100 dark:border-blue-500/20 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-colors active:scale-95 disabled:opacity-50"
            title="Refresh Pesanan"
          >
            <RotateCcw className={cn("w-4 h-4", (loading || isRefreshing) && "animate-spin")} />
          </button>
        </div>

        {loading ? (
          <div className="p-6 space-y-3">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="h-20 rounded-2xl bg-slate-100 dark:bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : orders.length === 0 ? (
          <div className="relative flex-1 flex flex-col items-center justify-center p-10 min-h-[400px] bg-[#F8FAFC] dark:bg-[#0a0a0f] overflow-hidden">
            {/* Draggable Background Decor (Medium Icons) */}
            <DraggableCardContainer className="absolute inset-0 w-full h-full pointer-events-auto z-10">
              {draggableItems.map((item) => (
                <DraggableCardBody key={item.title} className={item.className}>
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white dark:bg-white/10 shadow-xl p-3 flex items-center justify-center backdrop-blur-md border border-slate-200/50 dark:border-white/10 cursor-grab active:cursor-grabbing hover:scale-110 transition-transform duration-200 group">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-full object-contain drop-shadow-md group-hover:drop-shadow-xl transition-all"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.innerHTML = `<span class="text-xs font-bold text-slate-400">${item.title.substring(0,2)}</span>`;
                      }}
                    />
                  </div>
                </DraggableCardBody>
              ))}
            </DraggableCardContainer>

            {/* Empty State Content */}
            <div className="relative z-20 flex flex-col items-center text-center max-w-sm mx-auto bg-white/70 dark:bg-black/60 backdrop-blur-2xl p-8 rounded-3xl border border-white/50 dark:border-white/10 shadow-2xl pointer-events-auto">
              <img src="/images/otpyuk-mascot-run.webp" alt="Mascot" className="w-24 h-24 object-contain mb-4 animate-float drop-shadow-xl" />
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Tidak ada pesanan</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
                Pesanan aktif akan muncul di sini. Silakan beli nomor virtual terlebih dahulu.
              </p>
              <button
                onClick={() => setIsOrderModalOpen(true)}
                className="px-6 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-black text-sm font-bold hover:scale-105 transition-transform shadow-lg shadow-black/10"
              >
                + Buat Pesanan
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[750px]">
              <thead>
                <tr className="bg-gradient-to-r from-slate-50 to-slate-100/50 dark:from-white/[0.03] dark:to-white/[0.01] border-b border-slate-200/80 dark:border-white/10">
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Server</th>
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Layanan</th>
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Nomor HP</th>
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Harga</th>
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Status</th>
                  <th className="px-5 py-3.5 text-left text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Kode OTP</th>
                  <th className="px-5 py-3.5 text-right text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-[0.1em]">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  const hasOtp = order.otpCode && order.otpCode !== '-' && order.otpCode.trim() !== '';
                  const isWaiting = order.status === 'WAITING';
                  const isReceived = order.status === 'RECEIVED';

                  return (
                    <motion.tr
                      key={order.orderId}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className={cn(
                        'border-b border-slate-100 dark:border-white/5 transition-all duration-200',
                        'hover:bg-gradient-to-r hover:from-slate-50/80 hover:to-transparent dark:hover:from-white/[0.03] dark:hover:to-transparent',
                        isReceived && 'bg-green-50/30 dark:bg-green-500/[0.03]'
                      )}
                    >
                      {/* Server */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <span className="inline-flex px-2 py-0.5 rounded-md text-[11px] font-mono font-semibold bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-slate-400">
                          {order.server || 'v2.0'}
                        </span>
                      </td>

                      {/* Layanan */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-slate-100 to-slate-50 dark:from-white/10 dark:to-white/5 flex items-center justify-center flex-shrink-0 overflow-hidden shadow-sm border border-slate-200/50 dark:border-white/10">
                            {order.serviceImg ? (
                              <img src={order.serviceImg} alt={order.serviceName} className="w-5 h-5 object-contain" />
                            ) : (
                              <span className="text-[10px] font-bold text-slate-500">{order.serviceName.substring(0,2).toUpperCase()}</span>
                            )}
                          </div>
                          <span className="text-[13px] font-semibold text-slate-800 dark:text-slate-200">{order.serviceName}</span>
                        </div>
                      </td>

                      {/* Nomor HP */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div 
                          className="inline-flex items-center gap-2 cursor-pointer group/phone rounded-lg px-2 py-1 -mx-2 hover:bg-slate-100/80 dark:hover:bg-white/5 transition-colors" 
                          onClick={() => handleCopy(order.phoneNumber, `phone-${order.orderId}`)}
                        >
                          <span className="text-base">🇮🇩</span>
                          <span className="text-[13px] font-semibold text-slate-800 dark:text-slate-200 font-mono">{order.phoneNumber}</span>
                          {copiedId === `phone-${order.orderId}` ? (
                            <Check className="w-3.5 h-3.5 text-green-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600 opacity-0 group-hover/phone:opacity-100 transition-opacity" />
                          )}
                        </div>
                      </td>

                      {/* Harga */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <span className="text-[13px] font-semibold text-slate-700 dark:text-slate-300">{formatRupiah(order.price)}</span>
                      </td>

                      {/* Status */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        {isWaiting ? (
                          <CountdownBadge expiredAt={order.expiredAt} />
                        ) : isReceived ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-500 dark:bg-green-400" />
                            Sukses
                          </span>
                        ) : (
                          <span className={cn('inline-flex px-2.5 py-1 rounded-full text-[11px] font-bold', getStatusColor(order.status))}>
                            {order.status}
                          </span>
                        )}
                      </td>

                      {/* Kode OTP */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        {hasOtp ? (
                          <button
                            onClick={() => handleCopy(order.otpCode!, `otp-${order.orderId}`)}
                            className={cn(
                              'inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl transition-all active:scale-[0.97] cursor-pointer',
                              'bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-500/10 dark:to-emerald-500/10',
                              'border border-green-200 dark:border-green-500/25',
                              'hover:shadow-md hover:shadow-green-200/50 dark:hover:shadow-green-500/10 hover:border-green-300 dark:hover:border-green-400/40'
                            )}
                          >
                            <span className="font-mono text-sm font-extrabold text-green-600 dark:text-green-400 tracking-[0.15em]">{order.otpCode}</span>
                            {copiedId === `otp-${order.orderId}` ? (
                              <Check className="w-3.5 h-3.5 text-green-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5 text-green-400/60" />
                            )}
                          </button>
                        ) : (
                          <div className="inline-flex items-center gap-2">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500" />
                            </span>
                            <span className="text-[13px] font-semibold text-amber-500 dark:text-amber-400">Menunggu</span>
                          </div>
                        )}
                      </td>

                      {/* Aksi */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          {isWaiting && (
                            <>
                              <button
                                onClick={() => handleResend(order.orderId)}
                                disabled={resendingId === order.orderId}
                                title="Minta Ulang Kode"
                                className="w-8 h-8 rounded-xl flex items-center justify-center bg-blue-50 dark:bg-blue-500/10 border border-blue-200/80 dark:border-blue-500/30 text-blue-500 hover:bg-blue-100 dark:hover:bg-blue-500/20 hover:shadow-md hover:shadow-blue-200/40 transition-all disabled:opacity-50"
                              >
                                {resendingId === order.orderId ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                              </button>
                              <button
                                onClick={() => {
                                  const elapsed = Date.now() - new Date(order.createdAt).getTime();
                                  if (elapsed < 5 * 60 * 1000) {
                                    notify.cancelTooEarly();
                                    return;
                                  }
                                  handleCancel(order.orderId);
                                }}
                                disabled={cancelingId === order.orderId || (Date.now() - new Date(order.createdAt).getTime() < 5 * 60 * 1000)}
                                title="Batalkan Pesanan"
                                className="w-8 h-8 rounded-xl flex items-center justify-center bg-red-50 dark:bg-red-500/10 border border-red-200/80 dark:border-red-500/30 text-red-400 hover:bg-red-100 dark:hover:bg-red-500/20 hover:shadow-md hover:shadow-red-200/40 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                              >
                                {cancelingId === order.orderId ? <Loader2 className="w-4 h-4 animate-spin" /> : <Ban className="w-4 h-4" />}
                              </button>
                            </>
                          )}
                          {isReceived && hasOtp && (
                            <>
                              <button
                                onClick={() => handleBuyAgain(order.orderId)}
                                disabled={buyingAgainId === order.orderId}
                                title="Beli Ulang"
                                className="w-8 h-8 rounded-xl flex items-center justify-center bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200/80 dark:border-indigo-500/30 text-indigo-500 hover:bg-indigo-100 dark:hover:bg-indigo-500/20 hover:shadow-md hover:shadow-indigo-200/40 transition-all disabled:opacity-50"
                              >
                                {buyingAgainId === order.orderId ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                              </button>
                              <button
                                onClick={() => handleDone(order.orderId)}
                                disabled={completingId === order.orderId}
                                title="Selesai"
                                className="w-8 h-8 rounded-xl flex items-center justify-center bg-green-50 dark:bg-green-500/10 border border-green-200/80 dark:border-green-500/30 text-green-500 hover:bg-green-100 dark:hover:bg-green-500/20 hover:shadow-md hover:shadow-green-200/40 transition-all disabled:opacity-50"
                              >
                                {completingId === order.orderId ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Bottom Row: Info & FAQ ── */}
      <div className="grid lg:grid-cols-2 gap-6 relative z-0">
        
        {/* Left Col: Notification & Terms */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#15151c] rounded-3xl p-6 border border-slate-200/60 dark:border-white/5 shadow-sm h-full flex flex-col">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-6 shrink-0">
              <HeadphonesIcon className="w-4 h-4 text-amber-500" />
              Notifikasi Sistem
            </h3>
            
            <div className="w-full flex-1 rounded-2xl bg-neutral-100 dark:bg-neutral-900 overflow-hidden relative flex items-center justify-center mb-6 shadow-inner border border-neutral-200 dark:border-neutral-800 p-4 min-h-[120px]">
              {/* Reduced duration to 4 seconds to slow down animation */}
              <TextFlippingBoard text={"GUNAKAN \nVPN JIKA \nOTP LAMA"} duration={4} className="scale-90 transform-gpu" />
            </div>

            <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-500/10 border border-blue-100 dark:border-blue-500/20 shrink-0">
              <h4 className="text-xs font-bold text-blue-900 dark:text-blue-300 mb-1">Message Notifikasi Real-time</h4>
              <p className="text-[11px] text-blue-700 dark:text-blue-400/80 leading-relaxed">
                Disarankan menggunakan notifikasi real-time agar SMS message dapat diterima tepat waktu tanpa delay walaupun situs ditutup saat mendaftar nomor.
              </p>
            </div>
            
            <div className="pt-6 mt-6 border-t border-slate-100 dark:border-white/5 shrink-0">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">Ketentuan Sebelum Membeli</h3>
              <div className="flex gap-2 flex-wrap">
                <button className="px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors">Kebijakan Refund ↗</button>
                <button className="px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors">Kebijakan Privasi ↗</button>
                <button className="px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors">Syarat Ketentuan ↗</button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Animated FAQ */}
        <div className="bg-white dark:bg-[#15151c] rounded-3xl p-6 border border-slate-200/60 dark:border-white/5 shadow-sm h-full">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-6">
            <Info className="w-4 h-4 text-amber-500" />
            Pertanyaan Umum
          </h3>
          
          <div className="space-y-3">
            {FAQ_ITEMS.map((faq, index) => {
              const Icon = faq.icon;
              const isOpen = openFaqIndex === index;
              return (
                <div 
                  key={index} 
                  className={cn(
                    'rounded-2xl border transition-colors overflow-hidden',
                    isOpen 
                      ? 'bg-amber-50/50 dark:bg-amber-500/5 border-amber-200 dark:border-amber-500/20' 
                      : 'bg-slate-50 dark:bg-white/[0.02] border-slate-100 dark:border-white/5 hover:border-slate-200 dark:hover:border-white/10'
                  )}
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? -1 : index)}
                    className="w-full flex items-center justify-between p-4 text-left cursor-pointer focus:outline-none"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={cn('w-4 h-4', faq.color)} />
                      <span className={cn('font-semibold text-xs sm:text-sm transition-colors', isOpen ? 'text-amber-900 dark:text-amber-400' : 'text-slate-800 dark:text-slate-200')}>{faq.title}</span>
                    </div>
                    <motion.div
                      animate={{ rotate: isOpen ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <ChevronDown className={cn('w-4 h-4', isOpen ? 'text-amber-500' : 'text-slate-400')} />
                    </motion.div>
                  </button>
                  
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                      >
                        <div className={cn(
                          'px-4 pb-4 text-xs leading-relaxed border-t pt-3',
                          isOpen ? 'border-amber-200/50 dark:border-amber-500/20 text-amber-900/80 dark:text-amber-200/80' : 'border-slate-200 dark:border-white/5 text-slate-600 dark:text-slate-400'
                        )}>
                          {faq.content}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      <CreateOrderModal 
        isOpen={isOrderModalOpen} 
        onClose={() => setIsOrderModalOpen(false)} 
        onOrderSuccess={() => {
          fetchOrders();
          fetchProfile();
        }} 
      />

    </div>
  );
}
