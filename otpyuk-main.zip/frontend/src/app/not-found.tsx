/**
 * not-found.tsx — Custom 404 with Otpyuk running animation
 */

'use client';

import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-[#0a0a0f] text-center px-4">
      {/* Otpyuk running video with float animation */}
      <div className="relative animate-float mb-6">
        <Image
          src="/images/otpyuk-mascot-404.webp"
          alt="404 Not Found"
          width={250}
          height={250}
          className="drop-shadow-lg object-contain"
          priority
        />
        {/* 404 badge */}
        <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
          404
        </div>
      </div>

      <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-2">
        Halaman Tidak Ditemukan
      </h1>
      <p className="text-slate-500 dark:text-slate-400 max-w-md mb-8">
        Oops! Otpyuk sepertinya tersesat. Halaman yang kamu cari tidak ada
        atau sudah dipindahkan.
      </p>

      <div className="flex flex-col sm:flex-row gap-3">
        <Link
          href="/"
          className={cn(
            'inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl',
            'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
            'hover:from-amber-600 hover:to-amber-700',
            'shadow-lg shadow-amber-500/20 transition-all duration-200 btn-hover'
          )}
        >
          <Home className="w-4 h-4" />
          Ke Beranda
        </Link>
        <button
          onClick={() => window.history.back()}
          className={cn(
            'inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl',
            'border border-slate-200 dark:border-white/10',
            'text-slate-700 dark:text-slate-300',
            'hover:bg-slate-50 dark:hover:bg-white/5 transition-all duration-200'
          )}
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali
        </button>
      </div>
    </div>
  );
}
