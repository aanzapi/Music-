/**
 * Forgot Password Page — /forgot-password
 * Simple email form for password reset request.
 */

'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Zap, Mail, ArrowLeft, Loader2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import api from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await api.post('/api/v1/auth/forgot-password', { email });
    } catch {
      // Always show success to prevent email enumeration
    }

    setSent(true);
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-white dark:bg-[#0a0a0f]">
      <div className="w-full max-w-md">
        {/* Logo */}
        <Link href="/" className="inline-flex items-center gap-2 mb-8 group">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg rotate-6 group-hover:rotate-12 transition-transform" />
            <Zap className="relative w-5 h-5 text-white fill-white" />
          </div>
          <span className="text-lg font-bold">
            <span className="text-amber-500">Otp</span>
            <span className="text-slate-800 dark:text-white">Yuk</span>
          </span>
        </Link>

        {!sent ? (
          <>
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-2">
              Reset Password
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">
              Masukkan email Anda dan kami akan mengirimkan link untuk reset password.
            </p>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@email.com"
                    className={cn(
                      'w-full pl-10 pr-4 py-3 text-sm rounded-xl',
                      'bg-slate-50 dark:bg-white/5',
                      'border border-slate-200 dark:border-white/10',
                      'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                      'transition-all duration-200'
                    )}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className={cn(
                  'w-full flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-xl',
                  'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
                  'hover:from-amber-600 hover:to-amber-700',
                  'shadow-lg shadow-amber-500/20',
                  'disabled:opacity-60 disabled:cursor-not-allowed',
                  'transition-all duration-200'
                )}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Kirim Link Reset'}
              </button>
            </form>
          </>
        ) : (
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-500/10 flex items-center justify-center mx-auto mb-6">
              <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-3">
              Cek Email Anda
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
              Jika akun dengan email <strong className="text-slate-800 dark:text-white">{email}</strong> terdaftar, kami telah mengirimkan link reset password.
            </p>
            <p className="text-xs text-slate-400 mb-8">
              Tidak menerima email? Cek folder spam atau coba lagi dalam beberapa menit.
            </p>
          </div>
        )}

        <Link
          href="/login"
          className="mt-6 flex items-center justify-center gap-2 text-sm text-slate-500 hover:text-amber-600 dark:text-slate-400 dark:hover:text-amber-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Login
        </Link>
      </div>
    </div>
  );
}
