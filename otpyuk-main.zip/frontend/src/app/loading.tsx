/**
 * loading.tsx — Global Loading with LoadingScreen component
 */

import { LoadingScreen } from '@/components/common/LoadingScreen';

export default function Loading() {
  return <LoadingScreen message="Memuat otpyuk..." />;
}
