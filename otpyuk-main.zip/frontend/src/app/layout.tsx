/**
 * layout.tsx — Root Layout
 * Sets up Inter font, ThemeProvider (next-themes), and global metadata.
 * Default theme: light mode.
 */

import type { Metadata } from 'next';
import { Inter, Geist } from 'next/font/google';
import { ThemeProvider } from '@/components/layout/ThemeProvider';
import { OrganizationJsonLd } from '@/components/seo/JsonLd';
import './globals.css';
import { cn } from "@/lib/utils";
import { Toaster } from 'sonner';
import { AntiDevTools } from '@/components/security/AntiDevTools';

const geist = Geist({subsets:['latin'],variable:'--font-sans'});

const inter = Inter({
  variable: '--font-inter',
  subsets: ['latin'],
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://otpyuk.my.id'),
  title: {
    default: 'OtpYuk - OTP Virtual Instan & Terpercaya | Mulai Rp650',
    template: '%s | OtpYuk',
  },
  description:
    'Beli OTP virtual dari 1.700+ layanan & 100+ negara. Instan, aman, murah. WhatsApp, Telegram, TikTok, dan lainnya. Daftar gratis sekarang!',
  keywords: [
    'otp virtual',
    'beli otp',
    'nomor virtual',
    'jasa otp',
    'otp otomatis',
    'otp murah',
    'OtpYuk',
  ],
  authors: [{ name: 'OtpYuk', url: 'https://otpyuk.my.id' }],
  creator: 'frkhnsptra__',
  openGraph: {
    type: 'website',
    locale: 'id_ID',
    url: 'https://otpyuk.my.id',
    siteName: 'OtpYuk',
    title: 'OtpYuk - OTP Virtual Instan & Terpercaya',
    description: 'Beli OTP virtual dari 1.700+ layanan & 100+ negara. Mulai Rp650.',
    images: [{ url: '/images/og-image.webp', width: 1200, height: 630, alt: 'OtpYuk' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'OtpYuk - OTP Virtual Instan & Terpercaya',
    description: 'Beli OTP virtual dari 1.700+ layanan & 100+ negara.',
    images: ['/images/og-image.webp'],
  },
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
      { url: '/images/otpyuk-logo.webp', sizes: '192x192', type: 'image/webp' },
    ],
    apple: '/images/otpyuk-logo.webp',
    other: [
      { rel: 'manifest', url: '/site.webmanifest' },
    ],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

import Script from 'next/script';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning className={cn(inter.variable, "font-sans", geist.variable)}>
      <body className="min-h-screen bg-white text-slate-900 antialiased dark:bg-[#0a0a0f] dark:text-slate-50 font-[family-name:var(--font-inter)]">
        <OrganizationJsonLd />
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange={false}
        >
          {children}
        </ThemeProvider>
        {process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY && (
          <>
            <Script id="recaptcha-init" strategy="beforeInteractive">
              {`window.onRecaptchaLoad = function() { window.recaptchaLoaded = true; };`}
            </Script>
            <Script
              src="https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit"
              strategy="afterInteractive"
            />
          </>
        )}
        <AntiDevTools />
        <Toaster position="top-center" richColors theme="system" />
      </body>
    </html>
  );
}
