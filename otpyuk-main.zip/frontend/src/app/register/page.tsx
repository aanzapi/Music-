/**
 * Register Page — /register
 * Premium registration form with email/password, username, and Google OAuth.
 */

'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Zap, Mail, Lock, User, Eye, EyeOff, ArrowRight, Loader2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import api from '@/lib/api';
import ChromaVideo from '@/components/common/ChromaVideo';
import ReCaptcha from '@/components/common/ReCaptcha';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', firstName: '', password: '', confirmPassword: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [captchaToken, setCaptchaToken] = useState('');

  const passwordChecks = [
    { label: 'Minimal 8 karakter', valid: form.password.length >= 8 },
    { label: 'Huruf besar & kecil', valid: /[a-z]/.test(form.password) && /[A-Z]/.test(form.password) },
    { label: 'Angka', valid: /\d/.test(form.password) },
    { label: 'Password cocok', valid: form.password.length > 0 && form.password === form.confirmPassword },
  ];

  const allValid = passwordChecks.every((c) => c.valid);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!allValid) return;
    setError('');
    setLoading(true);

    try {
      if (!captchaToken) {
        setError('Silakan verifikasi reCAPTCHA terlebih dahulu');
        setLoading(false);
        return;
      }
      await api.post('/api/v1/auth/register', {
        email: form.email,
        firstName: form.firstName,
        password: form.password,
        confirmPassword: form.confirmPassword,
        recaptchaToken: captchaToken,
      });

      setSuccess(true);
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { message?: string } } };
      setError(axiosErr.response?.data?.message || 'Registrasi gagal.');
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-white dark:bg-[#0a0a0f]">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-500/10 flex items-center justify-center mx-auto mb-6">
            <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-3">
            Registrasi Berhasil! 🎉
          </h1>
          <p className="text-slate-600 dark:text-slate-400 mb-8">
            Akun Anda telah dibuat. Silakan login untuk mulai menggunakan otpyuk.
          </p>
          <Link
            href="/login"
            className={cn(
              'inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl',
              'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
              'hover:from-amber-600 hover:to-amber-700',
              'shadow-lg shadow-amber-500/20',
              'transition-all duration-200'
            )}
          >
            Masuk ke Dashboard
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left panel — Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 bg-dot-pattern opacity-10" />

        {/* Glow effects */}
        <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-amber-400/20 rounded-full blur-3xl animate-blob" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-orange-400/20 rounded-full blur-3xl animate-blob animation-delay-2000" />

        <div className="relative text-center text-white z-10 flex flex-col items-center justify-center h-full">
          {/* Otpyuk running animation — compact, above text */}
          <div className="relative w-[280px] h-[180px] mb-4">
            <ChromaVideo
              src="/videos/Animated_Bird_Speed_Run.mp4"
              className="w-full h-full object-contain drop-shadow-2xl"
              colorToKey={[0, 255, 0]}
              tolerance={150}
            />
          </div>

          <h2 className="text-2xl font-extrabold mb-3">Bergabung Sekarang!</h2>
          <p className="text-amber-100/90 text-base max-w-sm mx-auto leading-relaxed">
            Daftar gratis dan langsung bisa beli OTP dari 1.700+ layanan. Proses cepat, aman, dan terpercaya.
          </p>

          {/* Benefits list */}
          <div className="mt-6 space-y-2 text-left max-w-xs mx-auto">
            {['Harga mulai Rp650', 'Auto refund jika gagal', 'Dashboard real-time', 'API developer ready', 'Support 24/7'].map((item) => (
              <div key={item} className="flex items-center gap-2.5 text-xs font-semibold text-amber-100/90">
                <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <Check className="w-2.5 h-2.5 text-white" />
                </div>
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — Form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-white dark:bg-[#0a0a0f]">
        <div className="w-full max-w-md">
          <Link href="/" className="inline-flex items-center gap-2 mb-8 group">
            <div className="relative w-8 h-8 flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg rotate-6 group-hover:rotate-12 transition-transform" />
              <Zap className="relative w-5 h-5 text-white fill-white" />
            </div>
            <span className="text-lg font-bold">
              <span className="text-amber-500">Otp</span>
              <span className="text-slate-800 dark:text-white">Yuk</span>
            </span>
          </Link>

          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-2">Buat Akun Baru</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">Gratis, tanpa kartu kredit.</p>

          {error && (
            <div className="mb-6 px-4 py-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-sm text-red-600 dark:text-red-400">
              {error}
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="nama@email.com"
                  className={cn(
                    'w-full pl-10 pr-4 py-3 text-sm rounded-xl',
                    'bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10',
                    'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                    'transition-all duration-200'
                  )}
                />
              </div>
            </div>

            {/* Nama */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nama</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  placeholder="Nama kamu"
                  className={cn(
                    'w-full pl-10 pr-4 py-3 text-sm rounded-xl',
                    'bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10',
                    'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                    'transition-all duration-200'
                  )}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPw ? 'text' : 'password'}
                  required
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                  className={cn(
                    'w-full pl-10 pr-12 py-3 text-sm rounded-xl',
                    'bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10',
                    'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                    'transition-all duration-200'
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Konfirmasi Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPw ? 'text' : 'password'}
                  required
                  value={form.confirmPassword}
                  onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
                  placeholder="••••••••"
                  className={cn(
                    'w-full pl-10 pr-4 py-3 text-sm rounded-xl',
                    'bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10',
                    'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                    'transition-all duration-200'
                  )}
                />
              </div>
            </div>

            {/* Password strength indicators */}
            <div className="grid grid-cols-2 gap-2">
              {passwordChecks.map((check, i) => (
                <div key={i} className="flex items-center gap-1.5 text-xs">
                  <div className={cn(
                    'w-3.5 h-3.5 rounded-full flex items-center justify-center',
                    check.valid
                      ? 'bg-green-100 dark:bg-green-500/10'
                      : 'bg-slate-100 dark:bg-white/5'
                  )}>
                    <Check className={cn('w-2.5 h-2.5', check.valid ? 'text-green-600 dark:text-green-400' : 'text-slate-300 dark:text-slate-600')} />
                  </div>
                  <span className={cn(check.valid ? 'text-green-600 dark:text-green-400' : 'text-slate-400')}>{check.label}</span>
                </div>
              ))}
            </div>

            {/* reCAPTCHA Checkbox */}
            <ReCaptcha
              onVerify={(token) => setCaptchaToken(token)}
              onExpire={() => setCaptchaToken('')}
            />

            <button
              type="submit"
              disabled={loading || !allValid || !captchaToken}
              className={cn(
                'w-full flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-xl',
                'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
                'hover:from-amber-600 hover:to-amber-700',
                'shadow-lg shadow-amber-500/20',
                'disabled:opacity-60 disabled:cursor-not-allowed',
                'transition-all duration-200'
              )}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  Daftar Gratis
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-slate-200 dark:bg-white/10" />
            <span className="text-xs text-slate-400">atau</span>
            <div className="flex-1 h-px bg-slate-200 dark:bg-white/10" />
          </div>

          {/* Google OAuth */}
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/api/v1/auth/google`}
            className={cn(
              'w-full flex items-center justify-center gap-3 py-3 text-sm font-medium rounded-xl',
              'border border-slate-200 dark:border-white/10',
              'text-slate-700 dark:text-slate-300',
              'hover:bg-slate-50 dark:hover:bg-white/5',
              'transition-all duration-200'
            )}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" /><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" /><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" /><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" /></svg>
            Daftar dengan Google
          </a>

          {/* GitHub OAuth */}
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/api/v1/auth/github`}
            className={cn(
              'w-full flex items-center justify-center gap-3 py-3 text-sm font-medium rounded-xl mt-3',
              'bg-[#24292f] dark:bg-white/10 text-white',
              'hover:bg-[#1b1f23] dark:hover:bg-white/15',
              'transition-all duration-200'
            )}
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z" /></svg>
            Daftar dengan GitHub
          </a>

          <p className="mt-8 text-center text-sm text-slate-500 dark:text-slate-400">
            Sudah punya akun?{' '}
            <Link href="/login" className="text-amber-600 dark:text-amber-400 font-semibold hover:underline">
              Masuk
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
