/**
 * middleware.ts — Next.js Edge Middleware
 * Protects /client/* routes by checking for auth cookie.
 * Redirects unauthenticated users to /login.
 * Redirects authenticated users away from /login and /register.
 */

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const PROTECTED_PATHS = ['/client'];
const AUTH_PATHS = ['/login', '/register', '/forgot-password'];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasRefreshToken = request.cookies.has('refreshToken');

  // Protected routes — redirect to login if no auth
  const isProtected = PROTECTED_PATHS.some((p) => pathname.startsWith(p));
  if (isProtected && !hasRefreshToken) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Auth pages — redirect to dashboard if already logged in
  const isAuthPage = AUTH_PATHS.some((p) => pathname === p);
  if (isAuthPage && hasRefreshToken) {
    return NextResponse.redirect(new URL('/client/dashboard', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/client/:path*', '/login', '/register', '/forgot-password'],
};
