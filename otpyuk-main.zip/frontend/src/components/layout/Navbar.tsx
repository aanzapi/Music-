/**
 * Navbar.tsx — Main Navigation Bar
 * Glassmorphism navbar with logo, nav links, theme toggle, and auth buttons.
 * Sticky on scroll with backdrop blur and subtle border.
 */

'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useTheme } from 'next-themes';
import { Menu, X, Zap, ChevronRight } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { NAV_ITEMS } from '@/lib/constants';
import { cn } from '@/lib/utils';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { theme } = useTheme();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) setIsMobileOpen(false);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <nav
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
          isScrolled
            ? 'bg-white/80 dark:bg-[#0a0a0f]/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-white/5 shadow-sm'
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-18">
            {/* Logo */}
            <Link
              href="/"
              className="flex items-center gap-2 group"
            >
              <div className="relative w-10 h-10 flex items-center justify-center">
                <Image 
                  src="/images/otpyuk-mascot-run.webp" 
                  alt="otpyuk Logo" 
                  width={40} 
                  height={40} 
                  className="object-contain"
                />
              </div>
              <span className="text-lg font-bold">
                <span className="text-gradient-amber">Otp</span>
                <span className="text-slate-800 dark:text-white">Yuk</span>
              </span>
            </Link>

            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center gap-1">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200',
                    'text-slate-600 hover:text-slate-900 hover:bg-slate-100',
                    'dark:text-slate-400 dark:hover:text-white dark:hover:bg-white/5'
                  )}
                >
                  {item.label}
                </a>
              ))}
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-3">
              <ThemeToggle />

              <Link
                href="/login"
                className={cn(
                  'px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200',
                  'text-slate-700 hover:text-slate-900 hover:bg-slate-100',
                  'dark:text-slate-300 dark:hover:text-white dark:hover:bg-white/5'
                )}
              >
                Masuk
              </Link>

              <Link
                href="/register"
                className={cn(
                  'group flex items-center gap-1.5 px-5 py-2.5 text-sm font-semibold rounded-xl',
                  'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
                  'hover:from-amber-600 hover:to-amber-700',
                  'shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30',
                  'transition-all duration-200 btn-hover'
                )}
              >
                Daftar Gratis
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex md:hidden items-center gap-2">
              <ThemeToggle />
              <button
                onClick={() => setIsMobileOpen(!isMobileOpen)}
                className={cn(
                  'w-9 h-9 rounded-lg flex items-center justify-center',
                  'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700',
                  'transition-colors duration-200'
                )}
                aria-label="Toggle menu"
              >
                {isMobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/20 dark:bg-black/50 backdrop-blur-sm"
            onClick={() => setIsMobileOpen(false)}
          />
          <div
            className={cn(
              'absolute top-16 left-0 right-0 bg-white dark:bg-[#111118]',
              'border-b border-slate-200 dark:border-white/5',
              'shadow-xl animate-slide-up'
            )}
          >
            <div className="px-4 py-4 space-y-1">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setIsMobileOpen(false)}
                  className={cn(
                    'block px-4 py-3 text-sm font-medium rounded-lg transition-colors',
                    'text-slate-600 hover:text-slate-900 hover:bg-slate-50',
                    'dark:text-slate-400 dark:hover:text-white dark:hover:bg-white/5'
                  )}
                >
                  {item.label}
                </a>
              ))}
              <hr className="my-3 border-slate-200 dark:border-white/5" />
              <Link
                href="/login"
                onClick={() => setIsMobileOpen(false)}
                className="block px-4 py-3 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg"
              >
                Masuk
              </Link>
              <Link
                href="/register"
                onClick={() => setIsMobileOpen(false)}
                className={cn(
                  'block px-4 py-3 text-sm font-semibold text-center rounded-xl',
                  'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
                  'hover:from-amber-600 hover:to-amber-700'
                )}
              >
                Daftar Gratis
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
