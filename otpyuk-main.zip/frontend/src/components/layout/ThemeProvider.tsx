/**
 * ThemeProvider.tsx — Next-Themes Provider Wrapper
 * Client component that wraps the app with theme support.
 */

'use client';

import { ThemeProvider as NextThemesProvider } from 'next-themes';

export function ThemeProvider({
  children,
  ...props
}: React.ComponentProps<typeof NextThemesProvider>) {
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>;
}
