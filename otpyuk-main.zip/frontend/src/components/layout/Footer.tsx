/**
 * Footer.tsx — Site Footer
 * Professional footer with brand, navigation columns, social links, and status bar.
 */

import Link from 'next/link';
import { Zap, Send, MessageCircle, Mail, Code2, ArrowUpRight } from 'lucide-react';
import { SOCIAL_LINKS, SERVERS } from '@/lib/constants';

export function Footer() {
  return (
    <footer id="footer" className="relative overflow-hidden bg-slate-50 dark:bg-[#0a0a0f] border-t border-slate-200 dark:border-white/5">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-amber-50/20 dark:to-amber-950/5 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link href="/" className="inline-flex items-center gap-3 mb-4 group">
              <div className="relative w-12 h-12 flex items-center justify-center animate-float">
                <img src="/images/otpyuk-logo.webp" alt="Otpyuk Logo" className="w-full h-full object-contain drop-shadow-lg group-hover:scale-110 transition-transform" />
              </div>
              <span className="text-2xl font-black tracking-tight">
                <span className="text-amber-500">Otp</span>
                <span className="text-slate-800 dark:text-white">Yuk</span>
              </span>
            </Link>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 leading-relaxed max-w-xs">
              Platform OTP virtual terpercaya di Indonesia. Beli nomor dari 1.700+ layanan di 100+ negara dengan harga mulai Rp650.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3">
              <a
                href={SOCIAL_LINKS.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-amber-100 dark:hover:bg-amber-500/10 flex items-center justify-center transition-colors group"
                aria-label="Telegram"
              >
                <Send className="w-4 h-4 text-slate-500 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors" />
              </a>
              <a
                href={`https://wa.me/${SOCIAL_LINKS.whatsapp.replace('https://wa.me/', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-green-100 dark:hover:bg-green-500/10 flex items-center justify-center transition-colors group"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4 text-slate-500 group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors" />
              </a>
              <a
                href={SOCIAL_LINKS.github}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 flex items-center justify-center transition-colors group"
                aria-label="GitHub"
              >
                <Code2 className="w-4 h-4 text-slate-500 group-hover:text-slate-800 dark:group-hover:text-white transition-colors" />
              </a>
              <a
                href={`mailto:${SOCIAL_LINKS.email}`}
                className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-red-100 dark:hover:bg-red-500/10 flex items-center justify-center transition-colors group"
                aria-label="Email"
              >
                <Mail className="w-4 h-4 text-slate-500 group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors" />
              </a>
            </div>
          </div>

          {/* Navigation Columns */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-4">Produk</h4>
            <ul className="space-y-3">
              {[
                { label: 'Virtual Number', href: '/client/virtual-number' },
                { label: 'Harga & Layanan', href: '/#pricing' },
                { label: 'Status Server', href: '#' },
                { label: 'API Developer', href: '/developer/api' }
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className="text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-4">Support</h4>
            <ul className="space-y-3">
              {['Pusat Bantuan', 'FAQ', 'Kebijakan Privasi', 'Syarat & Ketentuan'].map((item) => (
                <li key={item}>
                  <Link
                    href="#"
                    className="text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Server Status */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-4">Status Server</h4>
            <div className="space-y-2">
              {SERVERS.slice(0, 6).map((server, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <img src={`https://flagcdn.com/w20/${server.country}.png`} alt={server.country} className="w-4 h-3 rounded-[2px]" />
                    <span>{server.name}</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="status-dot status-dot-online" />
                    <span className="text-xs text-green-600 dark:text-green-400 font-medium">Online</span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-200 dark:border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-400 dark:text-slate-500">
            © 2026 otpyuk. All rights reserved. Powered by{' '}
            <a
              href="https://rumahotp.io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-600 dark:text-amber-400 hover:underline inline-flex items-center gap-0.5"
            >
              RumahOTP
              <ArrowUpRight className="w-3 h-3" />
            </a>
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span className="status-dot status-dot-online" />
            All systems operational
          </div>
        </div>
      </div>
    </footer>
  );
}
