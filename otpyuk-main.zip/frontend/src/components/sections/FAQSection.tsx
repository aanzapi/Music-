/**
 * FAQSection.tsx — Frequently Asked Questions
 * Accordion-style FAQ with smooth open/close animations.
 */

'use client';

import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { FAQ_ITEMS } from '@/lib/constants';

function FAQItem({ question, answer, isOpen, onToggle }: {
  question: string;
  answer: string;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <div className={cn(
      'rounded-2xl border transition-all duration-200',
      isOpen
        ? 'border-amber-200 dark:border-amber-500/20 bg-amber-50/50 dark:bg-amber-500/5 shadow-sm'
        : 'border-slate-100 dark:border-white/5 bg-white dark:bg-white/[0.02]'
    )}>
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-5 text-left"
      >
        <span className={cn(
          'text-sm sm:text-base font-semibold pr-4 transition-colors',
          isOpen ? 'text-amber-700 dark:text-amber-400' : 'text-slate-800 dark:text-white'
        )}>
          {question}
        </span>
        <ChevronDown className={cn(
          'w-5 h-5 flex-shrink-0 transition-all duration-300',
          isOpen
            ? 'rotate-180 text-amber-500'
            : 'text-slate-400'
        )} />
      </button>
      <div className={cn(
        'overflow-hidden transition-all duration-300',
        isOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'
      )}>
        <div className="px-5 pb-5">
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {answer}
          </p>
        </div>
      </div>
    </div>
  );
}

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 bg-white dark:bg-[#0a0a0f]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 mb-4">
            <HelpCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span className="text-xs font-medium text-amber-700 dark:text-amber-400">FAQ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">
            Pertanyaan <span className="text-gradient-amber">Umum</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Jawaban untuk pertanyaan yang sering ditanyakan.
          </p>
        </div>

        {/* FAQ Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column: Mascot Image */}
          <div className="hidden lg:flex justify-center relative animate-float">
            {/* Glow background */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-400/10 dark:bg-blue-500/10 rounded-full blur-3xl" />
            
            <div className="relative w-full max-w-md aspect-square">
              <img 
                src="/images/otpyuk_faq_sofa.webp" 
                alt="FAQ Mascot" 
                className="w-full h-full object-contain drop-shadow-2xl"
              />
            </div>
          </div>

          {/* Right Column: Accordion Items */}
          <div className="space-y-3">
            {FAQ_ITEMS.map((item, i) => (
              <FAQItem
                key={i}
                question={item.q}
                answer={item.a}
                isOpen={openIndex === i}
                onToggle={() => setOpenIndex(openIndex === i ? null : i)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
