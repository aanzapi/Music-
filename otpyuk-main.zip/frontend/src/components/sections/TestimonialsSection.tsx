/**
 * TestimonialsSection.tsx — Infinite Marquee Testimonials
 * Auto-scrolling testimonial cards with star ratings.
 */

import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { TESTIMONIALS } from '@/lib/constants';

function TestimonialCard({ name, rating, text }: { name: string; rating: number; text: string }) {
  return (
    <div className={cn(
      'flex-shrink-0 w-80 p-6 rounded-2xl mx-3',
      'bg-white dark:bg-white/[0.03]',
      'border border-slate-100 dark:border-white/5',
      'shadow-sm'
    )}>
      {/* Stars */}
      <div className="flex items-center gap-0.5 mb-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={cn(
              'w-4 h-4',
              i < rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200 dark:text-slate-700'
            )}
          />
        ))}
      </div>
      {/* Quote */}
      <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
        &quot;{text}&quot;
      </p>
      {/* Author */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white text-xs font-bold">
          {name.charAt(0)}
        </div>
        <div>
          <p className="text-sm font-semibold text-slate-800 dark:text-white">{name}</p>
          <p className="text-xs text-slate-400">Pengguna otpyuk</p>
        </div>
      </div>
    </div>
  );
}

export function TestimonialsSection() {
  // Double the items for seamless infinite scroll
  const items = [...TESTIMONIALS, ...TESTIMONIALS];

  return (
    <section className="relative py-24 bg-slate-50 dark:bg-[#0f0f18] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">
            Dipercaya Ribuan <span className="text-gradient-amber">Pengguna</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Lihat apa kata mereka tentang pengalaman menggunakan otpyuk.
          </p>
        </div>
      </div>

      {/* Marquee Row 1 */}
      <div className="relative mb-4">
        <div className="flex animate-marquee">
          {items.map((t, i) => (
            <TestimonialCard key={`row1-${i}`} {...t} />
          ))}
        </div>
        {/* Fade edges */}
        <div className="absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-slate-50 dark:from-[#0f0f18] to-transparent pointer-events-none z-10" />
        <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-slate-50 dark:from-[#0f0f18] to-transparent pointer-events-none z-10" />
      </div>

      {/* Marquee Row 2 (reverse) */}
      <div className="relative">
        <div className="flex animate-marquee" style={{ animationDirection: 'reverse', animationDuration: '40s' }}>
          {[...items].reverse().map((t, i) => (
            <TestimonialCard key={`row2-${i}`} {...t} />
          ))}
        </div>
        <div className="absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-slate-50 dark:from-[#0f0f18] to-transparent pointer-events-none z-10" />
        <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-slate-50 dark:from-[#0f0f18] to-transparent pointer-events-none z-10" />
      </div>
    </section>
  );
}
