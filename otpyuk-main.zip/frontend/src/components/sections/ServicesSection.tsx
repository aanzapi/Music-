/**
 * ServicesSection.tsx — Real-time Services Grid with Pricing
 * Fetches live service data from RumahOTP v2 API, shows images & starting price.
 * Uses SWR-like pattern with stale-while-revalidate for instant feel.
 */

'use client';

import { useState, useMemo, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { Search, ArrowRight, TrendingUp, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { POPULAR_SERVICES } from '@/lib/constants';
import ChromaVideo from '@/components/common/ChromaVideo';

interface RumahOtpService {
  service_code: number;
  service_name: string;
  service_img: string;
}

// Static fallback data shown instantly while API loads
const STATIC_FALLBACK: RumahOtpService[] = POPULAR_SERVICES.map((s, i) => ({
  service_code: i + 1,
  service_name: s.name,
  service_img: '',
}));

export function ServicesSection() {
  const [search, setSearch] = useState('');
  const [services, setServices] = useState<RumahOtpService[]>(STATIC_FALLBACK);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchServices = useCallback(async () => {
    try {
      // Try backend proxy first (fastest, cached in Redis)
      const res = await fetch('/api/v1/services/public', {
        signal: AbortSignal.timeout(5000),
      });
      if (!res.ok) throw new Error('Backend offline');
      const json = await res.json();
      if (json.data?.length > 0) {
        setServices(json.data);
        setError('');
        return;
      }
    } catch {
      // Fallback: fetch directly from RumahOTP
      try {
        const res = await fetch('https://www.rumahotp.io/api/v2/services', {
          headers: { 'Accept': 'application/json' },
          signal: AbortSignal.timeout(8000),
        });
        if (!res.ok) throw new Error('API offline');
        const json = await res.json();
        if (json.data?.length > 0) {
          setServices(json.data);
          setError('');
          return;
        }
      } catch {
        setError('Gagal memuat data layanan terbaru.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchServices();
  }, [fetchServices]);

  const filtered = useMemo(() => {
    const list = search
      ? services.filter((svc) =>
        svc.service_name.toLowerCase().includes(search.toLowerCase())
      )
      : services;
    return list.slice(0, 20);
  }, [search, services]);

  return (
    <section id="services" className="relative py-24 bg-white dark:bg-[#0a0a0f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col items-center justify-center text-center mb-12 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 mb-4">
            <TrendingUp className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span className="text-xs font-medium text-amber-700 dark:text-amber-400">Layanan Populer</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">
            {services.length > 20 ? `${services.length}+` : '1.700+'} Layanan <span className="text-gradient-amber">Tersedia</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Pilih dari ribuan layanan yang tersedia. Data tersinkronisasi secara real-time dari API pusat RumahOTP.
          </p>
        </div>

        {/* Search */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-8">
          <div className="relative flex-1 max-w-md w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari layanan... (WhatsApp, Telegram, dll)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={cn(
                'w-full pl-10 pr-4 py-2.5 text-sm rounded-xl',
                'bg-slate-50 dark:bg-white/5',
                'border border-slate-200 dark:border-white/10',
                'text-slate-900 dark:text-white',
                'focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500',
                'placeholder:text-slate-400 dark:placeholder:text-slate-500',
                'transition-all duration-200'
              )}
            />
          </div>
          {!loading && services.length > 20 && (
            <p className="text-xs text-slate-400 dark:text-slate-500">
              Menampilkan {filtered.length} dari {services.length} layanan
            </p>
          )}
        </div>

        {/* Error banner (non-blocking — still shows static data) */}
        {error && (
          <div className="flex items-center gap-2 p-3 mb-6 rounded-xl bg-red-50 dark:bg-red-500/5 border border-red-200 dark:border-red-500/10">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-xs text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}

        {/* Services Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {filtered.map((svc) => (
            <div
              key={svc.service_code}
              className={cn(
                'group relative p-4 rounded-xl cursor-pointer card-hover',
                'bg-white dark:bg-white/[0.02]',
                'border border-slate-100 dark:border-white/5',
                'hover:border-amber-200 dark:hover:border-amber-500/20',
                'hover:shadow-lg hover:shadow-amber-500/5',
                loading && 'animate-pulse'
              )}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-lg bg-slate-50 dark:bg-white/5 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {svc.service_img ? (
                    <Image
                      src={svc.service_img}
                      alt={svc.service_name}
                      width={28}
                      height={28}
                      className="object-contain"
                      loading="lazy"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        if (e.currentTarget.parentElement) {
                          e.currentTarget.parentElement.innerHTML = '<span class="text-lg">📱</span>';
                        }
                      }}
                    />
                  ) : (
                    <span className="text-lg">📱</span>
                  )}
                </div>
                <span className="text-sm font-semibold text-slate-800 dark:text-white truncate">
                  {svc.service_name}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                  #{svc.service_code}
                </span>
                <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                  Mulai Rp650
                </span>
              </div>
              {/* Hover arrow */}
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowRight className="w-4 h-4 text-amber-500" />
              </div>
            </div>
          ))}
        </div>

        {!loading && filtered.length === 0 && (
          <div className="text-center py-12 text-slate-400 dark:text-slate-500">
            <p className="text-lg mb-2">Tidak ada layanan ditemukan</p>
            <p className="text-sm">Coba kata kunci lain</p>
          </div>
        )}

        {/* CTA */}
        <div className="text-center mt-10">
          <a
            href="/register"
            className={cn(
              'inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl',
              'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
              'hover:from-amber-600 hover:to-amber-700',
              'shadow-lg shadow-amber-500/20',
              'transition-all duration-200 btn-hover'
            )}
          >
            Lihat Semua Layanan
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
