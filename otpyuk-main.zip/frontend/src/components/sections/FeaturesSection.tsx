/**
 * FeaturesSection.tsx — Platform Features Showcase
 * Highlights key platform features with icon cards.
 */

import { Zap, Shield, RefreshCw, Code, Headphones, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';

const FEATURES = [
  {
    icon: Zap,
    title: 'Super Cepat',
    desc: 'OTP diterima rata-rata dalam 3-15 detik. Sistem polling real-time tanpa perlu refresh manual.',
    gradient: 'from-amber-500 to-orange-500',
    bgLight: 'bg-amber-50',
    bgDark: 'dark:bg-amber-500/10',
  },
  {
    icon: Shield,
    title: 'Aman & Terpercaya',
    desc: 'Enkripsi end-to-end, 2FA opsional, dan API key dengan IP whitelist untuk keamanan maksimal.',
    gradient: 'from-green-500 to-emerald-500',
    bgLight: 'bg-green-50',
    bgDark: 'dark:bg-green-500/10',
  },
  {
    icon: RefreshCw,
    title: 'Auto Refund',
    desc: 'OTP tidak masuk? Saldo otomatis dikembalikan. Tidak ada resiko kehilangan uang.',
    gradient: 'from-blue-500 to-cyan-500',
    bgLight: 'bg-blue-50',
    bgDark: 'dark:bg-blue-500/10',
  },
  {
    icon: Code,
    title: 'Developer API',
    desc: 'REST API lengkap dengan dokumentasi Swagger. Integrasi ke bot Telegram, Discord, atau app custom.',
    gradient: 'from-purple-500 to-violet-500',
    bgLight: 'bg-purple-50',
    bgDark: 'dark:bg-purple-500/10',
  },
  {
    icon: Headphones,
    title: 'Support 24/7',
    desc: 'Tim support aktif via Telegram dan WhatsApp. Respon cepat untuk semua kendala.',
    gradient: 'from-red-500 to-pink-500',
    bgLight: 'bg-red-50',
    bgDark: 'dark:bg-red-500/10',
  },
  {
    icon: Globe,
    title: '100+ Negara',
    desc: 'Nomor virtual dari seluruh dunia. Indonesia, US, UK, Russia, India, dan banyak lagi.',
    gradient: 'from-indigo-500 to-blue-500',
    bgLight: 'bg-indigo-50',
    bgDark: 'dark:bg-indigo-500/10',
  },
];

export function FeaturesSection() {
  return (
    <section className="relative py-24 bg-white dark:bg-[#0a0a0f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 mb-4">
            <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span className="text-xs font-medium text-amber-700 dark:text-amber-400">Kenapa otpyuk?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">
            Fitur <span className="text-gradient-amber">Unggulan</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Platform yang dirancang untuk kecepatan, keamanan, dan kemudahan penggunaan.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feat, i) => {
            const Icon = feat.icon;
            return (
              <div
                key={i}
                className={cn(
                  'group p-6 rounded-2xl card-hover',
                  'bg-white dark:bg-white/[0.02]',
                  'border border-slate-100 dark:border-white/5',
                  'hover:border-amber-200 dark:hover:border-amber-500/20'
                )}
              >
                {/* Icon */}
                <div className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center mb-4',
                  feat.bgLight, feat.bgDark,
                  'group-hover:scale-110 transition-transform duration-300'
                )}>
                  <Icon className={cn('w-6 h-6 bg-gradient-to-br bg-clip-text', feat.gradient === 'from-amber-500 to-orange-500' ? 'text-amber-600 dark:text-amber-400' : feat.gradient === 'from-green-500 to-emerald-500' ? 'text-green-600 dark:text-green-400' : feat.gradient === 'from-blue-500 to-cyan-500' ? 'text-blue-600 dark:text-blue-400' : feat.gradient === 'from-purple-500 to-violet-500' ? 'text-purple-600 dark:text-purple-400' : feat.gradient === 'from-red-500 to-pink-500' ? 'text-red-600 dark:text-red-400' : 'text-indigo-600 dark:text-indigo-400')} />
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  {feat.title}
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
