/**
 * HowItWorksSection.tsx — Step-by-step Guide
 * Visual 4-step process with numbered cards and connecting lines.
 */

import { UserPlus, Wallet, ShoppingCart, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

const STEPS = [
  {
    step: 1,
    icon: UserPlus,
    title: 'Daftar Akun',
    desc: 'Buat akun gratis dalam 30 detik. Bisa pakai email atau login Google.',
    color: 'from-blue-500 to-blue-600',
    bgLight: 'bg-blue-50',
    bgDark: 'dark:bg-blue-500/10',
    textColor: 'text-blue-600 dark:text-blue-400',
  },
  {
    step: 2,
    icon: Wallet,
    title: 'Top Up Saldo',
    desc: 'Isi saldo via QRIS (scan semua e-wallet & bank) atau USDT crypto.',
    color: 'from-amber-500 to-amber-600',
    bgLight: 'bg-amber-50',
    bgDark: 'dark:bg-amber-500/10',
    textColor: 'text-amber-600 dark:text-amber-400',
  },
  {
    step: 3,
    icon: ShoppingCart,
    title: 'Pilih Layanan',
    desc: 'Pilih layanan & negara, klik Beli. Nomor virtual siap dalam hitungan detik.',
    color: 'from-green-500 to-green-600',
    bgLight: 'bg-green-50',
    bgDark: 'dark:bg-green-500/10',
    textColor: 'text-green-600 dark:text-green-400',
  },
  {
    step: 4,
    icon: MessageSquare,
    title: 'Terima OTP',
    desc: 'OTP masuk otomatis ke dashboard. Copy kode dan selesai!',
    color: 'from-purple-500 to-purple-600',
    bgLight: 'bg-purple-50',
    bgDark: 'dark:bg-purple-500/10',
    textColor: 'text-purple-600 dark:text-purple-400',
  },
];

export function HowItWorksSection() {
  return (
    <section className="relative py-24 bg-slate-50 dark:bg-[#0f0f18]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 mb-4">
            <span className="text-xs font-medium text-amber-700 dark:text-amber-400">Mudah Banget!</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">
            Cara Kerja <span className="text-gradient-amber">otpyuk</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            4 langkah sederhana untuk mendapatkan OTP virtual. Proses dari daftar sampai terima OTP kurang dari 1 menit.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-4 gap-6 relative">
          {/* Connecting line (desktop only) */}
          <div className="hidden md:block absolute top-[15.5rem] left-[12%] right-[12%] h-0.5 bg-gradient-to-r from-blue-200 via-amber-200 via-green-200 to-purple-200 dark:from-blue-500/20 dark:via-amber-500/20 dark:via-green-500/20 dark:to-purple-500/20" />

          {STEPS.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.step} className="relative flex flex-col items-center text-center">
                {/* Image Illustration */}
                <div className="mb-6 relative w-48 h-48 animate-float" style={{ animationDelay: `${step.step * 200}ms` }}>
                  <img
                    src={`/images/step-${step.step}.webp`}
                    alt={step.title}
                    className="w-full h-full object-contain drop-shadow-xl"
                  />
                </div>

                {/* Step number & icon */}
                <div className="relative z-10 mb-6">
                  <div className={cn(
                    'w-16 h-16 rounded-2xl flex items-center justify-center',
                    'bg-gradient-to-br shadow-lg',
                    step.color
                  )}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <span className={cn(
                    'absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center',
                    'text-[10px] font-bold text-white',
                    'bg-gradient-to-br', step.color,
                    'ring-4 ring-slate-50 dark:ring-[#0f0f18]'
                  )}>
                    {step.step}
                  </span>
                </div>

                {/* Card */}
                <div className={cn(
                  'flex-1 p-6 rounded-2xl w-full',
                  'bg-white dark:bg-white/[0.03]',
                  'border border-slate-100 dark:border-white/5',
                  'card-hover'
                )}>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
