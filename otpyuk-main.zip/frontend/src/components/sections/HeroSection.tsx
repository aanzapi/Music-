/**
 * HeroSection.tsx — Above-the-fold Hero
 * Uses static transparent WebP mascot image for clean look on both themes.
 */

'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Zap, ArrowRight, Shield, Clock, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';
import { STATS_DATA } from '@/lib/constants';
import { Globe3DDemo } from '@/components/ui/globe-demo';
import { AnimatedTooltip } from '@/components/ui/animated-tooltip';

const tooltipPeople = [
  { id: 1, name: "Reza Anugrah", designation: "Seller TikTok", image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" },
  { id: 2, name: "Siti Aminah", designation: "Marketer", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" },
  { id: 3, name: "Budi Santoso", designation: "Crypto Trader", image: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" },
  { id: 4, name: "Dewi Lestari", designation: "Agen Sosmed", image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" },
  { id: 5, name: "Andi Saputra", designation: "Gamer", image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" },
];

function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [target]);

  return <span>{count.toLocaleString('id-ID')}{suffix}</span>;
}

export function HeroSection() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-50/80 via-white to-orange-50/50 dark:from-[#0a0a0f] dark:via-[#0f0f18] dark:to-[#0a0a0f]" />
      <div className="absolute inset-0 bg-dot-pattern opacity-30 dark:opacity-10" />

      {/* Floating gradient orbs */}
      <div className="absolute top-20 right-[15%] w-[400px] h-[400px] rounded-full bg-gradient-to-br from-amber-400/20 to-orange-500/10 dark:from-amber-400/5 dark:to-orange-500/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 left-[10%] w-[300px] h-[300px] rounded-full bg-gradient-to-br from-red-400/10 to-amber-400/10 dark:from-red-400/5 dark:to-amber-500/5 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column — Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 mb-6 animate-slide-up">
              <span className="status-dot status-dot-online" />
              <span className="text-xs font-medium text-amber-700 dark:text-amber-400">
                All Servers Operational • 99.9% Uptime
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6 leading-[1.1]">
              <span className="text-slate-900 dark:text-white">OTP </span>
              <span className="text-gradient-amber">Super Cepat</span>
              <br />
              <span className="text-slate-900 dark:text-white">Instan & </span>
              <span className="text-amber-500">Terpercaya</span>
            </h1>

            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Beli nomor virtual OTP dari <strong className="text-slate-800 dark:text-white">1.700+ layanan</strong> di{' '}
              <strong className="text-slate-800 dark:text-white">100+ negara</strong>. Proses instan, harga mulai{' '}
              <strong className="text-amber-600 dark:text-amber-400">Rp650</strong>. Refund otomatis jika OTP tidak masuk.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 mb-8 lg:justify-start justify-center">
              <Link
                href="/register"
                className={cn(
                  'group flex items-center gap-2 px-8 py-4 text-base font-semibold rounded-2xl',
                  'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
                  'hover:from-amber-600 hover:to-amber-700',
                  'shadow-xl shadow-amber-500/25 hover:shadow-amber-500/35',
                  'transition-all duration-300 btn-hover'
                )}
              >
                Mulai Sekarang — Gratis
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <a
                href="#services"
                className={cn(
                  'flex items-center gap-2 px-8 py-4 text-base font-semibold rounded-2xl',
                  'border border-slate-200 dark:border-white/10',
                  'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5',
                  'transition-all duration-200'
                )}
              >
                Lihat Layanan
              </a>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-6 mb-10 lg:justify-start justify-center">
              <div className="flex flex-row items-center justify-center -space-x-2 w-full sm:w-auto mb-2 sm:mb-0">
                <AnimatedTooltip items={tooltipPeople} />
              </div>
              <div className="text-center sm:text-left">
                <div className="flex items-center gap-1 justify-center sm:justify-start mb-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg key={star} className="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-xs font-medium text-slate-600 dark:text-slate-400">Dipercaya oleh <strong className="text-slate-900 dark:text-white">10.000+</strong> pengguna aktif</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 sm:gap-6 justify-center lg:justify-start text-xs text-slate-500 dark:text-slate-500">
              <span className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-green-500" /> Aman & Terenkripsi
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-500" /> OTP 3-15 Detik
              </span>
              <span className="flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-blue-500" /> 100+ Negara
              </span>
            </div>
          </div>

          {/* Right Column — Static transparent WebP image */}
          <div className="relative hidden lg:flex items-center justify-center">
            <div className="absolute w-72 h-72 rounded-full bg-amber-400/20 dark:bg-amber-500/10 blur-3xl animate-blob" />
            <div className="absolute w-60 h-60 rounded-full bg-orange-400/15 dark:bg-orange-500/8 blur-3xl animate-blob animation-delay-2000" />
            <div className="absolute w-48 h-48 rounded-full bg-red-400/10 dark:bg-red-500/5 blur-3xl animate-blob animation-delay-4000" />
            <div className="absolute w-80 h-80 rounded-full border border-amber-200/30 dark:border-amber-500/10 animate-spin-slow" />

            {/* Otpyuk mascot — transparent WebP image */}
            <div className="relative z-10 animate-float">
              <Image
                src="/images/otpyuk-hero.webp"
                alt="Otpyuk otpyuk Mascot"
                width={420}
                height={420}
                priority
                className="drop-shadow-2xl"
              />
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-48 h-8 bg-amber-400/30 rounded-full blur-xl" />
            </div>

            {/* Floating Info cards */}
            <div className="absolute bottom-10 -left-8 glass-card rounded-2xl p-4 shadow-lg animate-float animation-delay-1000 z-20 hidden xl:block">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">WhatsApp OTP</p>
                  <p className="otp-digit text-sm">842-684</p>
                </div>
                <div className="w-2 h-2 bg-green-400 rounded-full animate-ping-slow ml-2" />
              </div>
            </div>

            <div className="absolute top-8 right-4 glass-card rounded-2xl px-4 py-3 shadow-lg animate-float z-20" style={{ animationDelay: '0.5s' }}>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-500/10 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Avg Speed</p>
                  <p className="text-sm font-bold text-slate-800 dark:text-white">3.2 detik</p>
                </div>
              </div>
            </div>

            <div className="absolute bottom-12 left-0 glass-card rounded-2xl px-4 py-3 shadow-lg animate-float z-20" style={{ animationDelay: '1s' }}>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-500/10 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Deliver Rate</p>
                  <p className="text-sm font-bold text-slate-800 dark:text-white">99.2%</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS_DATA.map((stat, i) => (
            <div
              key={i}
              className={cn(
                'text-center p-6 rounded-2xl card-hover',
                'bg-white/70 dark:bg-white/[0.03]',
                'border border-slate-100 dark:border-white/5',
                'shadow-sm'
              )}
            >
              <div className="text-3xl sm:text-4xl font-extrabold text-gradient-amber mb-1">
                <AnimatedCounter target={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-sm text-slate-500 dark:text-slate-400 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
