/**
 * CTASection.tsx — Final Call-to-Action
 * Full-width gradient banner with compelling CTA before the footer.
 */

import Link from 'next/link';
import { ArrowRight, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

export function CTASection() {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600" />
      <div className="absolute inset-0 bg-dot-pattern opacity-10" />

      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
      <div className="absolute bottom-10 right-10 w-48 h-48 rounded-full bg-orange-400/20 blur-3xl" />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Otpyuk emoji */}
        <div className="text-6xl mb-6">🐤</div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white mb-6 leading-tight">
          Siap Dapat OTP
          <br />
          <span className="text-amber-100">Super Cepat?</span>
        </h2>

        <p className="text-lg text-amber-100/80 mb-10 max-w-2xl mx-auto">
          Bergabung dengan 50.000+ pengguna yang sudah mempercayai otpyuk. Daftar gratis sekarang dan dapatkan saldo bonus!
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            href="/register"
            className={cn(
              'group flex items-center gap-2 px-8 py-4 text-base font-bold rounded-2xl',
              'bg-white text-amber-600',
              'hover:bg-amber-50',
              'shadow-xl shadow-black/10',
              'transition-all duration-200 btn-hover'
            )}
          >
            <Zap className="w-5 h-5 fill-amber-500" />
            Daftar Gratis Sekarang
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>

          <Link
            href="#services"
            className={cn(
              'flex items-center gap-2 px-8 py-4 text-base font-semibold rounded-2xl',
              'border-2 border-white/30 text-white',
              'hover:bg-white/10 hover:border-white/50',
              'transition-all duration-200'
            )}
          >
            Lihat Harga
          </Link>
        </div>

        <p className="mt-6 text-sm text-amber-200/60">
          Tanpa kartu kredit • Langsung bisa pakai • Refund otomatis
        </p>
      </div>
    </section>
  );
}
