'use client';

import { Globe3DDemo } from '@/components/ui/globe-demo';
import { Globe } from 'lucide-react';

export function GlobeSection() {
  return (
    <section className="relative py-24 bg-slate-50 dark:bg-[#0f0f18] overflow-hidden text-center">
      <div className="absolute inset-0 bg-dot-pattern opacity-30 dark:opacity-10" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/80 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 mb-6">
          <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Global Coverage</span>
        </div>
        
        <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">
          Tersedia di <span className="text-blue-500 dark:text-blue-400">100+ Negara</span>
        </h2>
        <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-16">
          Dari Asia hingga Eropa, kami menyediakan nomor virtual dari server terbaik di seluruh dunia dengan tingkat kesuksesan pengiriman OTP hingga 99.9%.
        </p>

        <div className="w-full flex justify-center mt-8">
          <Globe3DDemo />
        </div>
      </div>
    </section>
  );
}
