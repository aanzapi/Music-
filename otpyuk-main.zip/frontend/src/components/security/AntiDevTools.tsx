/**
 * AntiDevTools.tsx — DevTools & Inspection Prevention
 * Client-side deterrent to prevent casual inspection of the website.
 * Note: This cannot prevent determined users but deters casual inspection.
 */

'use client';

import { useEffect } from 'react';

export function AntiDevTools() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') return;

    // ── Block keyboard shortcuts ────────────────────
    const handleKeyDown = (e: KeyboardEvent) => {
      // F12
      if (e.key === 'F12') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+I (DevTools)
      if (e.ctrlKey && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+J (Console)
      if (e.ctrlKey && e.shiftKey && e.key === 'J') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+C (Element picker)
      if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        return false;
      }

      // Ctrl+U (View Source)
      if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        return false;
      }

      // Ctrl+S (Save page)
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        return false;
      }
    };

    // ── Block right-click context menu ──────────────
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };

    // ── DevTools detection via debugger timing ──────
    let devtoolsOpen = false;
    const threshold = 160;

    const detectDevTools = () => {
      const start = performance.now();
      // debugger statement pauses execution when DevTools is open
       
      debugger;
      const end = performance.now();

      if (end - start > threshold) {
        if (!devtoolsOpen) {
          devtoolsOpen = true;
          // Clear console and warn
          console.clear();
          console.log(
            '%c⚠️ WARNING',
            'color: red; font-size: 40px; font-weight: bold;'
          );
          console.log(
            '%cMenutup DevTools disarankan. Aktivitas mencurigakan akan dilaporkan.',
            'color: red; font-size: 16px;'
          );
        }
      } else {
        devtoolsOpen = false;
      }
    };

    // ── Disable text selection on sensitive elements ─
    const handleSelectStart = (e: Event) => {
      const target = e.target as HTMLElement;
      if (target.closest('[data-no-select]')) {
        e.preventDefault();
      }
    };

    // ── Disable drag on images ──────────────────────
    const handleDragStart = (e: DragEvent) => {
      if ((e.target as HTMLElement).tagName === 'IMG') {
        e.preventDefault();
      }
    };

    // Attach listeners
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('selectstart', handleSelectStart);
    document.addEventListener('dragstart', handleDragStart);

    // Check DevTools periodically (every 2s to avoid performance impact)
    const devtoolsInterval = setInterval(detectDevTools, 2000);

    // ── Console message for hackers ─────────────────
    console.clear();
    console.log(
      '%c🛡️ otpyuk Security',
      'color: #f59e0b; font-size: 24px; font-weight: bold;'
    );
    console.log(
      '%cBerhenti! Ini adalah fitur browser yang ditujukan untuk developer.',
      'color: red; font-size: 16px;'
    );
    console.log(
      '%cJika seseorang menyuruh Anda menempel sesuatu di sini, itu adalah penipuan.',
      'color: red; font-size: 14px;'
    );

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('selectstart', handleSelectStart);
      document.removeEventListener('dragstart', handleDragStart);
      clearInterval(devtoolsInterval);
    };
  }, []);

  return null;
}
