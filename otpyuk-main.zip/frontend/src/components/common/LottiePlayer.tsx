/**
 * LottiePlayer.tsx
 * Lightweight Lottie animation component — loads JSON from public path
 */
'use client';

import Lottie from 'lottie-react';
import { useEffect, useState } from 'react';

interface LottiePlayerProps {
  src: string;
  loop?: boolean;
  autoplay?: boolean;
  className?: string;
  width?: number;
  height?: number;
}

export function LottiePlayer({
  src,
  loop = true,
  autoplay = true,
  className,
  width,
  height,
}: LottiePlayerProps) {
  const [animationData, setAnimationData] = useState<object | null>(null);

  useEffect(() => {
    fetch(src)
      .then((res) => res.json())
      .then((data) => setAnimationData(data))
      .catch(() => {
        // Silently fail — animation is decorative
      });
  }, [src]);

  if (!animationData) return null;

  return (
    <Lottie
      animationData={animationData}
      loop={loop}
      autoplay={autoplay}
      className={className}
      style={{ width, height }}
    />
  );
}
