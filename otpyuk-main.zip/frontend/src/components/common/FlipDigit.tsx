/**
 * FlipDigit.tsx
 * Komponen digit OTP dengan animasi flip — mirip score board
 */
'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

interface FlipDigitProps {
  digit: string;
  className?: string;
}

export function FlipDigit({ digit, className }: FlipDigitProps) {
  const [current, setCurrent] = useState(digit);
  const [isFlipping, setIsFlipping] = useState(false);

  useEffect(() => {
    if (digit !== current) {
      setIsFlipping(true);
      const timer = setTimeout(() => {
        setCurrent(digit);
        setIsFlipping(false);
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [digit, current]);

  return (
    <span
      className={cn(
        'inline-flex w-8 h-10 items-center justify-center',
        'bg-white dark:bg-slate-800 rounded-md shadow-sm',
        'font-mono font-bold text-lg text-slate-800 dark:text-white',
        'border border-amber-200 dark:border-amber-900',
        isFlipping ? 'animate-flip-in' : '',
        className
      )}
    >
      {current}
    </span>
  );
}

interface OtpDisplayProps {
  code: string;
  className?: string;
}

export function OtpDisplay({ code, className }: OtpDisplayProps) {
  const digits = code.split('');

  return (
    <div className={cn('flex items-center gap-1', className)}>
      {digits.map((digit, i) => (
        <FlipDigit key={i} digit={digit} />
      ))}
    </div>
  );
}
