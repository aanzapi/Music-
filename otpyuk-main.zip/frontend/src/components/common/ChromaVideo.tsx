'use client';

import { useEffect, useRef } from 'react';

interface ChromaVideoProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
  src: string;
  className?: string;
  colorToKey?: [number, number, number]; // RGB array, default to bright green
  tolerance?: number;
}

export default function ChromaVideo({
  src,
  className = '',
  colorToKey = [0, 255, 0], // Default pure green
  tolerance = 100,
  ...props
}: ChromaVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    let animationFrameId: number;

    const drawFrame = () => {
      if (video.paused || video.ended) {
        animationFrameId = requestAnimationFrame(drawFrame);
        return;
      }

      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const frameData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = frameData.data;

      const [rKey, gKey, bKey] = colorToKey;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        // Convert RGB to HSL for much better green screen removal (handles vignettes)
        const rNorm = r / 255;
        const gNorm = g / 255;
        const bNorm = b / 255;
        const max = Math.max(rNorm, gNorm, bNorm);
        const min = Math.min(rNorm, gNorm, bNorm);
        let h = 0;
        let s = 0;
        const l = (max + min) / 2;

        if (max !== min) {
          const d = max - min;
          s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
          switch (max) {
            case rNorm: h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0); break;
            case gNorm: h = (bNorm - rNorm) / d + 2; break;
            case bNorm: h = (rNorm - gNorm) / d + 4; break;
          }
          h /= 6;
        }

        const hue = h * 360;
        const saturation = s * 100;
        const lightness = l * 100;

        // Pure green is hue 120. Yellow is hue 60.
        // If hue is between 85 and 160, and it has some color (saturation > 15%), it's our green screen!
        if (hue > 85 && hue < 165 && saturation > 15 && lightness > 5) {
          // Calculate softness at the edges of the hue range
          let alpha = 0;
          if (hue < 95) alpha = ((95 - hue) / 10) * 255;
          else if (hue > 155) alpha = ((hue - 155) / 10) * 255;
          else if (lightness < 15) alpha = ((15 - lightness) / 10) * 255; // Fade dark vignette shadows
          
          data[i + 3] = alpha; // Make transparent
        }
      }

      ctx.putImageData(frameData, 0, 0);
      animationFrameId = requestAnimationFrame(drawFrame);
    };

    const handlePlay = () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      drawFrame();
    };

    video.addEventListener('play', handlePlay);

    return () => {
      video.removeEventListener('play', handlePlay);
      cancelAnimationFrame(animationFrameId);
    };
  }, [colorToKey, tolerance]);

  return (
    <div className={`relative ${className}`}>
      {/* Hidden original video but kept in DOM for playback */}
      <video
        ref={videoRef}
        src={src}
        className="opacity-0 absolute w-px h-px pointer-events-none"
        crossOrigin="anonymous"
        muted
        playsInline
        autoPlay
        loop
        {...props}
      />
      {/* Canvas displaying processed frames */}
      <canvas ref={canvasRef} className="w-full h-full object-contain" />
    </div>
  );
}
