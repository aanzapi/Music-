/**
 * LoadingScreen.tsx
 * Global loading screen with Otpyuk running animation
 */
'use client';

import Image from 'next/image';

interface LoadingScreenProps {
  message?: string;
}

export function LoadingScreen({
  message = 'Memuat...',
}: LoadingScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-[#0a0a0f] gap-4">
      <div className="relative w-24 h-24">
        <Image
          src="/images/otpyuk-mascot-run.webp"
          alt="Loading..."
          width={96}
          height={96}
          className="animate-float object-contain"
          priority
        />
      </div>
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce" />
        <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce animation-delay-1000" />
        <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce animation-delay-2000" />
      </div>
      <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{message}</p>
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="p-6 space-y-4 animate-pulse">
      <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-lg w-1/3" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-24 bg-slate-200 dark:bg-slate-800 rounded-xl" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-32 bg-slate-200 dark:bg-slate-800 rounded-xl" />
        ))}
      </div>
    </div>
  );
}
