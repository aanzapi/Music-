/**
 * LoadingSkeleton.tsx — Reusable loading placeholder
 */

import { cn } from '@/lib/utils';

interface LoadingSkeletonProps {
  rows?: number;
  height?: string;
  className?: string;
}

export function LoadingSkeleton({ rows = 3, height = 'h-20', className }: LoadingSkeletonProps) {
  return (
    <div className={cn('space-y-3', className)}>
      {Array.from({ length: rows }).map((_, i) => (
        <div
          key={i}
          className={cn(height, 'rounded-2xl bg-slate-100 dark:bg-white/5 animate-pulse')}
        />
      ))}
    </div>
  );
}

export function CardSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn('p-5 rounded-2xl bg-white dark:bg-white/[0.03] border border-slate-100 dark:border-white/5', className)}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/5 animate-pulse" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-24 rounded bg-slate-100 dark:bg-white/5 animate-pulse" />
          <div className="h-3 w-16 rounded bg-slate-100 dark:bg-white/5 animate-pulse" />
        </div>
      </div>
      <div className="h-8 w-32 rounded bg-slate-100 dark:bg-white/5 animate-pulse" />
    </div>
  );
}
