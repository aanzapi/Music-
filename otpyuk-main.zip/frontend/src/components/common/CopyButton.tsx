/**
 * CopyButton.tsx — Copy-to-clipboard button with feedback
 */

'use client';

import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { cn, copyToClipboard } from '@/lib/utils';

interface CopyButtonProps {
  text: string;
  className?: string;
  label?: string;
}

export function CopyButton({ text, className, label }: CopyButtonProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg',
        'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400',
        'hover:bg-amber-50 dark:hover:bg-amber-500/10 hover:text-amber-600 dark:hover:text-amber-400',
        'transition-all duration-200',
        className
      )}
      title="Copy"
    >
      {copied ? (
        <>
          <Check className="w-3.5 h-3.5 text-green-500" />
          {label && <span className="text-green-500">Copied!</span>}
        </>
      ) : (
        <>
          <Copy className="w-3.5 h-3.5" />
          {label && <span>{label}</span>}
        </>
      )}
    </button>
  );
}
