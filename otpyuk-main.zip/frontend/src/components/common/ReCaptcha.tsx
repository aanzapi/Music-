/**
 * ReCaptcha.tsx — Google reCAPTCHA v2 Checkbox Component
 * Renders the "I'm not a robot" checkbox widget.
 */

'use client';

import { useEffect, useRef, useCallback } from 'react';
import '@/lib/recaptcha'; // Import shared type declarations

const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || '';

interface ReCaptchaProps {
  onVerify: (token: string) => void;
  onExpire?: () => void;
  theme?: 'light' | 'dark';
}

export default function ReCaptcha({ onVerify, onExpire, theme = 'light' }: ReCaptchaProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const widgetIdRef = useRef<number | null>(null);
  const renderedRef = useRef(false);

  const renderWidget = useCallback(() => {
    if (!containerRef.current || !window.grecaptcha || !window.grecaptcha.render || renderedRef.current || !SITE_KEY) return;

    try {
      widgetIdRef.current = window.grecaptcha.render(containerRef.current, {
        sitekey: SITE_KEY,
        callback: (token: string) => onVerify(token),
        'expired-callback': () => onExpire?.(),
        theme,
        size: 'normal',
      });
      renderedRef.current = true;
    } catch {
      // Widget may already be rendered
    }
  }, [onVerify, onExpire, theme]);

  useEffect(() => {
    // If grecaptcha is already loaded, render immediately
    if (typeof window !== 'undefined' && window.grecaptcha && 'render' in window.grecaptcha) {
      renderWidget();
      return;
    }

    // Otherwise, wait for the script to load
    window.onRecaptchaLoad = () => {
      renderWidget();
    };

    return () => {
      window.onRecaptchaLoad = undefined;
    };
  }, [renderWidget]);

  if (!SITE_KEY) return null;

  return (
    <div className="flex justify-center">
      <div ref={containerRef} />
    </div>
  );
}
