/**
 * StatusBadge.tsx
 * Badge status order/deposit — konsisten dengan tampilan RumahOTP
 */

import { cn } from '@/lib/utils';

type StatusType =
  | 'received' | 'completed' | 'canceled' | 'waiting'
  | 'expiring' | 'success' | 'pending' | 'cancel'
  | 'RECEIVED' | 'COMPLETED' | 'CANCELED' | 'WAITING'
  | 'EXPIRED' | 'SUCCESS' | 'PENDING' | 'REFUNDED';

interface StatusBadgeProps {
  status: string;
  className?: string;
  showDot?: boolean;
}

const STATUS_CONFIG: Record<string, {
  label: string;
  bg: string;
  text: string;
  dot: string;
}> = {
  RECEIVED:  { label: 'Diterima',   bg: 'bg-amber-50 dark:bg-amber-950',   text: 'text-amber-800 dark:text-amber-300',   dot: 'bg-amber-500' },
  received:  { label: 'Diterima',   bg: 'bg-amber-50 dark:bg-amber-950',   text: 'text-amber-800 dark:text-amber-300',   dot: 'bg-amber-500' },
  COMPLETED: { label: 'Selesai',    bg: 'bg-green-50 dark:bg-green-950',    text: 'text-green-800 dark:text-green-300',    dot: 'bg-green-500' },
  completed: { label: 'Selesai',    bg: 'bg-green-50 dark:bg-green-950',    text: 'text-green-800 dark:text-green-300',    dot: 'bg-green-500' },
  SUCCESS:   { label: 'Sukses',     bg: 'bg-green-50 dark:bg-green-950',    text: 'text-green-800 dark:text-green-300',    dot: 'bg-green-500' },
  success:   { label: 'Sukses',     bg: 'bg-green-50 dark:bg-green-950',    text: 'text-green-800 dark:text-green-300',    dot: 'bg-green-500' },
  CANCELED:  { label: 'Dibatalkan', bg: 'bg-red-50 dark:bg-red-950',        text: 'text-red-800 dark:text-red-300',        dot: 'bg-red-500' },
  canceled:  { label: 'Dibatalkan', bg: 'bg-red-50 dark:bg-red-950',        text: 'text-red-800 dark:text-red-300',        dot: 'bg-red-500' },
  cancel:    { label: 'Cancel',     bg: 'bg-red-50 dark:bg-red-950',        text: 'text-red-800 dark:text-red-300',        dot: 'bg-red-500' },
  REFUNDED:  { label: 'Refund',     bg: 'bg-blue-50 dark:bg-blue-950',      text: 'text-blue-800 dark:text-blue-300',      dot: 'bg-blue-500' },
  WAITING:   { label: 'Menunggu',   bg: 'bg-slate-50 dark:bg-slate-900',    text: 'text-slate-600 dark:text-slate-400',    dot: 'bg-slate-400' },
  waiting:   { label: 'Menunggu',   bg: 'bg-slate-50 dark:bg-slate-900',    text: 'text-slate-600 dark:text-slate-400',    dot: 'bg-slate-400' },
  PENDING:   { label: 'Pending',    bg: 'bg-slate-50 dark:bg-slate-900',    text: 'text-slate-600 dark:text-slate-400',    dot: 'bg-slate-400' },
  pending:   { label: 'Pending',    bg: 'bg-slate-50 dark:bg-slate-900',    text: 'text-slate-600 dark:text-slate-400',    dot: 'bg-slate-400' },
  EXPIRED:   { label: 'Expired',    bg: 'bg-orange-50 dark:bg-orange-950',  text: 'text-orange-800 dark:text-orange-300',  dot: 'bg-orange-500' },
  expiring:  { label: 'Expiring',   bg: 'bg-orange-50 dark:bg-orange-950',  text: 'text-orange-800 dark:text-orange-300',  dot: 'bg-orange-500' },
};

const DEFAULT_CONFIG = { label: 'Unknown', bg: 'bg-slate-50 dark:bg-slate-900', text: 'text-slate-600 dark:text-slate-400', dot: 'bg-slate-400' };

export function StatusBadge({ status, className, showDot = true }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status] ?? DEFAULT_CONFIG;

  return (
    <span className={cn(
      'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium',
      config.bg, config.text, className
    )}>
      {showDot && (
        <span className={cn('w-1.5 h-1.5 rounded-full flex-shrink-0', config.dot)} />
      )}
      {config.label}
    </span>
  );
}
