/**
 * PaymentHistory.tsx — Deposit history sidebar component
 * Shows recent deposit transactions with status badges.
 */

'use client';

import { useEffect, useState } from 'react';
import { Clock, CheckCircle2, XCircle, Loader2, Receipt, ArrowDownLeft } from 'lucide-react';
import { cn, formatRupiah, formatDateShort, getStatusColor } from '@/lib/utils';
import api from '@/lib/api';

interface Deposit {
  depositId: string;
  amount: number;
  received: number;
  method: string;
  status: string;
  createdAt: string;
  paidAt?: string;
  brandName?: string | null;
  brandIcon?: string | null;
}

export function PaymentHistory() {
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchDeposits() {
      try {
        const { data } = await api.get('/api/v1/deposit');
        setDeposits((data.data || []).slice(0, 15));
      } catch { /* ignore */ }
      finally { setLoading(false); }
    }
    fetchDeposits();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status.toUpperCase()) {
      case 'SUCCESS': 
      case 'COMPLETED': return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'CANCEL':
      case 'EXPIRED':
      case 'CANCELED':
      case 'FAILED': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-amber-500" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status.toUpperCase()) {
      case 'SUCCESS':
      case 'COMPLETED': return 'Berhasil';
      case 'PENDING':
      case 'WAITING': return 'Menunggu';
      case 'CANCEL':
      case 'CANCELED': return 'Dibatalkan';
      case 'FAILED': return 'Gagal';
      case 'EXPIRED': return 'Kadaluarsa';
      default: return status;
    }
  };

  return (
    <div className="bg-white dark:bg-[#15151c] rounded-3xl border border-slate-200/60 dark:border-white/5 shadow-sm overflow-hidden flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-white/5">
        <div className="flex items-center gap-2">
          <Receipt className="w-5 h-5 text-[#0066FF]" />
          <h2 className="text-[15px] font-bold text-slate-900 dark:text-white">Riwayat Pembayaran</h2>
        </div>
        <span className="text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-white/5 px-2 py-1 rounded-md">
          {deposits.length} transaksi
        </span>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto max-h-[600px] scrollbar-thin">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          </div>
        ) : deposits.length === 0 ? (
          <div className="text-center py-16 px-4">
            <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Receipt className="w-8 h-8 text-slate-300 dark:text-slate-600" />
            </div>
            <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Belum ada riwayat</p>
            <p className="text-xs text-slate-400 mt-1">Transaksi deposit akan muncul di sini</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-white/5">
            {deposits.map((dep) => (
              <div
                key={dep.depositId}
                className="flex items-center gap-3 px-5 py-4 hover:bg-slate-50/60 dark:hover:bg-white/[0.02] transition-colors group"
              >
                {/* Icon */}
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center flex-shrink-0 overflow-hidden border border-slate-100 dark:border-white/5">
                  {dep.brandIcon ? (
                    <img src={dep.brandIcon} alt={dep.brandName || dep.method} className="w-full h-full object-contain p-1" />
                  ) : (
                    <ArrowDownLeft className="w-5 h-5 text-[#0066FF]" />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="text-sm font-semibold text-slate-800 dark:text-white truncate">
                      Deposit {dep.brandName || dep.method}
                    </p>
                    {getStatusIcon(dep.status)}
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono truncate">
                    {dep.depositId} · {formatDateShort(dep.createdAt)}
                  </p>
                </div>

                {/* Amount + Status */}
                <div className="text-right flex-shrink-0">
                  <p className={cn(
                    'text-sm font-bold',
                    dep.status === 'SUCCESS' || dep.status === 'COMPLETED' ? 'text-green-600 dark:text-green-400' : 'text-slate-700 dark:text-slate-300'
                  )}>
                    +{formatRupiah(dep.received || dep.amount)}
                  </p>
                  <span className={cn(
                    'inline-block text-[10px] font-bold px-2 py-0.5 rounded-md mt-0.5',
                    getStatusColor(dep.status)
                  )}>
                    {getStatusLabel(dep.status)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
