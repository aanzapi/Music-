/**
 * Breadcrumb.tsx — Visual Breadcrumb + JSON-LD
 * Renders a styled breadcrumb trail with Schema.org structured data.
 */

import Link from 'next/link';
import { ChevronRight, Home } from 'lucide-react';
import { BreadcrumbJsonLd } from './JsonLd';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://otpyuk.markect.dev';

interface BreadcrumbItem {
  label: string;
  href: string;
}

export function Breadcrumb({ items }: { items: BreadcrumbItem[] }) {
  const allItems = [{ label: 'Beranda', href: '/' }, ...items];

  const jsonLdItems = allItems.map((item) => ({
    name: item.label,
    url: `${SITE_URL}${item.href}`,
  }));

  return (
    <>
      <BreadcrumbJsonLd items={jsonLdItems} />
      <nav aria-label="Breadcrumb" className="mb-8">
        <ol className="flex items-center flex-wrap gap-1.5 text-sm text-slate-500 dark:text-slate-400">
          {allItems.map((item, i) => {
            const isLast = i === allItems.length - 1;
            return (
              <li key={item.href} className="flex items-center gap-1.5">
                {i === 0 && (
                  <Home className="w-3.5 h-3.5 flex-shrink-0" />
                )}
                {i > 0 && (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600 flex-shrink-0" />
                )}
                {isLast ? (
                  <span className="font-medium text-slate-800 dark:text-white truncate">
                    {item.label}
                  </span>
                ) : (
                  <Link
                    href={item.href}
                    className="hover:text-amber-600 dark:hover:text-amber-400 transition-colors truncate"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
    </>
  );
}
