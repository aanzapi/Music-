/**
 * JsonLd.tsx — Structured Data (JSON-LD) Components
 * Injects Schema.org structured data for SEO and Google Sitelinks.
 */

import { APP_NAME } from '@/lib/constants';
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://otpyuk.markect.dev';
const SITE_NAME = APP_NAME;

/**
 * Organization + WebSite structured data.
 * Injected in root layout for sitelinks & search box.
 */
export function OrganizationJsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Organization',
        '@id': `${SITE_URL}/#organization`,
        name: SITE_NAME,
        url: SITE_URL,
        logo: {
          '@type': 'ImageObject',
          url: `${SITE_URL}/images/otpyuk-logo.webp`,
          width: 192,
          height: 192,
        },
        description:
          'Platform OTP virtual terpercaya di Indonesia. Beli nomor dari 1.700+ layanan di 100+ negara dengan harga mulai Rp650.',
        contactPoint: {
          '@type': 'ContactPoint',
          contactType: 'customer service',
          availableLanguage: ['Indonesian', 'English'],
          url: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
        },
        sameAs: [
          'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
          'https://github.com/frkhnsptra__',
        ],
      },
      {
        '@type': 'WebSite',
        '@id': `${SITE_URL}/#website`,
        url: SITE_URL,
        name: SITE_NAME,
        description:
          'Beli OTP virtual dari 1.700+ layanan & 100+ negara. Instan, aman, murah.',
        publisher: { '@id': `${SITE_URL}/#organization` },
        inLanguage: 'id-ID',
        potentialAction: {
          '@type': 'SearchAction',
          target: {
            '@type': 'EntryPoint',
            urlTemplate: `${SITE_URL}/client/virtual-number?q={search_term_string}`,
          },
          'query-input': 'required name=search_term_string',
        },
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

/**
 * BreadcrumbList structured data.
 * @param items - Array of breadcrumb items [{name, url}]
 */
export function BreadcrumbJsonLd({
  items,
}: {
  items: { name: string; url: string }[];
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

/**
 * FAQPage structured data.
 * Enables FAQ rich results in Google Search.
 * @param faqs - Array of FAQ items [{question, answer}]
 */
export function FAQPageJsonLd({
  faqs,
}: {
  faqs: { question: string; answer: string }[];
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

/**
 * WebPage structured data for inner pages.
 */
export function WebPageJsonLd({
  name,
  description,
  url,
}: {
  name: string;
  description: string;
  url: string;
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    '@id': url,
    name,
    description,
    url,
    isPartOf: { '@id': `${SITE_URL}/#website` },
    publisher: { '@id': `${SITE_URL}/#organization` },
    inLanguage: 'id-ID',
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
