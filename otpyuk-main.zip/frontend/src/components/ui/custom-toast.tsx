"use client";

import React from 'react';
import { toast as sonnerToast } from 'sonner';
import { CheckCircle, XCircle, AlertTriangle, Info, ShoppingCart, Ban, RefreshCw, Loader2 } from 'lucide-react';

type ToastType = 'success' | 'error' | 'warning' | 'info';

interface ToastOptions {
  title: string;
  description?: string;
  duration?: number;
}

const icons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />,
  error: <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />,
  warning: <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0" />,
  info: <Info className="w-5 h-5 text-blue-500 flex-shrink-0" />,
};

const borderColors: Record<ToastType, string> = {
  success: 'border-l-green-500',
  error: 'border-l-red-500',
  warning: 'border-l-amber-500',
  info: 'border-l-blue-500',
};

const bgColors: Record<ToastType, string> = {
  success: 'bg-green-50 dark:bg-green-500/10',
  error: 'bg-red-50 dark:bg-red-500/10',
  warning: 'bg-amber-50 dark:bg-amber-500/10',
  info: 'bg-blue-50 dark:bg-blue-500/10',
};

function showToast(type: ToastType, options: ToastOptions) {
  return sonnerToast.custom(
    (id) => (
      <div
        className={`w-full max-w-sm rounded-2xl border border-slate-200 dark:border-white/10 border-l-4 ${borderColors[type]} ${bgColors[type]} backdrop-blur-xl shadow-2xl shadow-black/10 overflow-hidden`}
      >
        <div className="flex items-start gap-3 px-4 py-3.5">
          <div className="mt-0.5">
            {icons[type]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
              {options.title}
            </p>
            {options.description && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                {options.description}
              </p>
            )}
          </div>
          <button
            onClick={() => sonnerToast.dismiss(id)}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors p-0.5 -mt-0.5 -mr-1 flex-shrink-0"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    ),
    {
      duration: options.duration || 4000,
      position: 'top-center',
    }
  );
}

// ═══════════════════════════════════════
// Pre-built notification helpers
// ═══════════════════════════════════════

export const notify = {
  // Generic
  success: (title: string, description?: string) => showToast('success', { title, description }),
  error: (title: string, description?: string) => showToast('error', { title, description }),
  warning: (title: string, description?: string) => showToast('warning', { title, description }),
  info: (title: string, description?: string) => showToast('info', { title, description }),

  // ─── Order-specific ───
  orderSuccess: (serviceName: string, phoneNumber: string) =>
    showToast('success', {
      title: '🎉 Pesanan Berhasil!',
      description: `${serviceName} • ${phoneNumber} — Tunggu OTP masuk`,
    }),

  orderFailed: (message: string) =>
    showToast('error', {
      title: 'Gagal Membuat Pesanan',
      description: message || 'Terjadi kesalahan saat memproses pesanan Anda.',
      duration: 5000,
    }),

  stockEmpty: () =>
    showToast('warning', {
      title: 'Stok Habis',
      description: 'Stok penyedia sedang habis. Silakan coba beberapa menit lagi atau pilih server lain.',
      duration: 5000,
    }),

  maintenance: () =>
    showToast('warning', {
      title: '🔧 Sistem Sedang Maintenance',
      description: 'Layanan RumahOTP sedang maintenance (23:00 – 01:00 WIB). Silakan coba lagi nanti.',
      duration: 6000,
    }),

  // ─── Cancel / Resend / Buy Again / Done ───
  cancelSuccess: () =>
    showToast('success', {
      title: 'Pesanan Dibatalkan',
      description: 'Saldo Anda telah dikembalikan secara otomatis.',
    }),

  cancelFailed: (message: string) =>
    showToast('error', {
      title: 'Gagal Membatalkan',
      description: message || 'Tidak dapat membatalkan pesanan saat ini.',
    }),

  cancelTooEarly: () =>
    showToast('warning', {
      title: 'Belum Bisa Dibatalkan',
      description: 'Pesanan baru bisa dibatalkan setelah 5 menit sejak pemesanan.',
    }),

  resendSuccess: () =>
    showToast('success', {
      title: 'Kode Diminta Ulang',
      description: 'Permintaan resend berhasil dikirim. Tunggu beberapa saat.',
    }),

  resendFailed: (message: string) =>
    showToast('error', {
      title: 'Gagal Resend',
      description: message || 'Tidak dapat mengirim ulang kode saat ini.',
    }),

  buyAgainSuccess: () =>
    showToast('success', {
      title: '🛒 Pesanan Ulang Berhasil',
      description: 'Nomor baru telah dipesan dengan spesifikasi yang sama.',
    }),

  buyAgainFailed: (message: string) =>
    showToast('error', {
      title: 'Gagal Beli Ulang',
      description: message || 'Tidak dapat membuat pesanan ulang.',
    }),

  doneSuccess: () =>
    showToast('success', {
      title: '✅ Pesanan Selesai',
      description: 'Riwayat pesanan telah dibersihkan dari daftar pending.',
    }),

  doneFailed: (message: string) =>
    showToast('error', {
      title: 'Gagal Menyelesaikan',
      description: message || 'Tidak dapat menyelesaikan pesanan.',
    }),

  // ─── Balance ───
  insufficientBalance: (needed: string, current: string) =>
    showToast('error', {
      title: 'Saldo Tidak Cukup',
      description: `Dibutuhkan ${needed}, saldo Anda ${current}. Silakan top up terlebih dahulu.`,
      duration: 5000,
    }),

  // ─── Generic API error parser ───
  apiError: (err: any, fallback: string = 'Terjadi kesalahan') => {
    const msg = err?.response?.data?.error?.message || err?.response?.data?.message || err?.message || fallback;
    
    // Detect special cases
    const lower = msg.toLowerCase();
    if (lower.includes('stock') || lower.includes('stok') || lower.includes('habis')) {
      return notify.stockEmpty();
    }
    if (lower.includes('maintenance') || lower.includes('maint')) {
      return notify.maintenance();
    }
    if (lower.includes('saldo tidak cukup') || lower.includes('insufficient')) {
      return showToast('error', { title: 'Saldo Tidak Cukup', description: msg, duration: 5000 });
    }
    
    return showToast('error', { title: fallback, description: msg });
  },
};
