"use client";
import { Globe3D, GlobeMarker } from "@/components/ui/3d-globe";
import { useEffect, useState } from "react";

const sampleMarkers: GlobeMarker[] = [
  { lat: 40.7128, lng: -74.006, src: "https://flagcdn.com/w160/us.png", label: "Amerika Serikat" },
  { lat: 51.5074, lng: -0.1278, src: "https://flagcdn.com/w160/gb.png", label: "Inggris" },
  { lat: 35.6762, lng: 139.6503, src: "https://flagcdn.com/w160/jp.png", label: "Jepang" },
  { lat: -33.8688, lng: 151.2093, src: "https://flagcdn.com/w160/au.png", label: "Australia" },
  { lat: 48.8566, lng: 2.3522, src: "https://flagcdn.com/w160/fr.png", label: "Prancis" },
  { lat: 28.6139, lng: 77.209, src: "https://flagcdn.com/w160/in.png", label: "India" },
  { lat: 55.7558, lng: 37.6173, src: "https://flagcdn.com/w160/ru.png", label: "Rusia" },
  { lat: -22.9068, lng: -43.1729, src: "https://flagcdn.com/w160/br.png", label: "Brasil" },
  { lat: 31.2304, lng: 121.4737, src: "https://flagcdn.com/w160/cn.png", label: "China" },
  { lat: 25.2048, lng: 55.2708, src: "https://flagcdn.com/w160/ae.png", label: "Uni Emirat Arab" },
  { lat: -34.6037, lng: -58.3816, src: "https://flagcdn.com/w160/ar.png", label: "Argentina" },
  { lat: 1.3521, lng: 103.8198, src: "https://flagcdn.com/w160/sg.png", label: "Singapura" },
  { lat: 37.5665, lng: 126.978, src: "https://flagcdn.com/w160/kr.png", label: "Korea Selatan" },
  { lat: -6.2088, lng: 106.8456, src: "https://flagcdn.com/w160/id.png", label: "Indonesia" },
  { lat: 3.1390, lng: 101.6869, src: "https://flagcdn.com/w160/my.png", label: "Malaysia" },
];

// Static globe image fallback for mobile
function MobileGlobeFallback() {
  return (
    <div className="relative w-full max-w-[320px] mx-auto aspect-square flex items-center justify-center">
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/10 blur-2xl" />
      <div className="relative w-full h-full rounded-full overflow-hidden border-2 border-blue-200/30 dark:border-blue-500/20 shadow-2xl shadow-blue-500/10">
        <img
          src="https://unpkg.com/three-globe@2.31.0/example/img/earth-blue-marble.jpg"
          alt="Globe"
          className="w-full h-full object-cover animate-spin-slow"
          style={{ animationDuration: '30s' }}
        />
      </div>
      {/* Flag badges around the globe */}
      <div className="absolute -top-2 right-8 w-8 h-8 rounded-full overflow-hidden border-2 border-white dark:border-slate-800 shadow-lg animate-float">
        <img src="https://flagcdn.com/w160/us.png" alt="US" className="w-full h-full object-cover" />
      </div>
      <div className="absolute top-1/4 -left-2 w-7 h-7 rounded-full overflow-hidden border-2 border-white dark:border-slate-800 shadow-lg animate-float animation-delay-1000">
        <img src="https://flagcdn.com/w160/jp.png" alt="JP" className="w-full h-full object-cover" />
      </div>
      <div className="absolute bottom-1/4 -right-2 w-7 h-7 rounded-full overflow-hidden border-2 border-white dark:border-slate-800 shadow-lg animate-float animation-delay-2000">
        <img src="https://flagcdn.com/w160/id.png" alt="ID" className="w-full h-full object-cover" />
      </div>
      <div className="absolute -bottom-2 left-8 w-8 h-8 rounded-full overflow-hidden border-2 border-white dark:border-slate-800 shadow-lg animate-float animation-delay-3000">
        <img src="https://flagcdn.com/w160/gb.png" alt="GB" className="w-full h-full object-cover" />
      </div>
    </div>
  );
}

export function Globe3DDemo() {
  const [isMobile, setIsMobile] = useState(true); // default to mobile to avoid SSR flash

  useEffect(() => {
    // Detect mobile: screen width OR touch device
    const checkMobile = () => {
      const mobile = window.innerWidth < 768 || 
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      setIsMobile(mobile);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // On mobile: show simple rotating image fallback (no WebGL)
  if (isMobile) {
    return <MobileGlobeFallback />;
  }

  // Desktop: full 3D globe
  return (
    <div className="relative w-full aspect-square max-w-[500px] flex items-center justify-center -mb-20">
      <Globe3D
        markers={sampleMarkers}
        config={{
          atmosphereColor: "#4da6ff",
          atmosphereIntensity: 20,
          bumpScale: 5,
          autoRotateSpeed: 0.8,
        }}
        onMarkerClick={(marker) => {
          console.log("Clicked marker:", marker.label);
        }}
      />
    </div>
  );
}
