/**
 * AnimatedTabs — Aceternity-inspired animated tabs component
 * Smooth sliding pill indicator with framer-motion transitions.
 */

'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

export interface Tab {
  title: string;
  value: string;
  icon?: React.ReactNode;
  content: React.ReactNode;
}

interface AnimatedTabsProps {
  tabs: Tab[];
  containerClassName?: string;
  tabClassName?: string;
  activeTabClassName?: string;
  contentClassName?: string;
}

export function AnimatedTabs({
  tabs,
  containerClassName,
  tabClassName,
  activeTabClassName,
  contentClassName,
}: AnimatedTabsProps) {
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [tabWidths, setTabWidths] = useState<number[]>([]);
  const [tabOffsets, setTabOffsets] = useState<number[]>([]);
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    const widths: number[] = [];
    const offsets: number[] = [];
    tabRefs.current.forEach((ref) => {
      if (ref) {
        widths.push(ref.offsetWidth);
        offsets.push(ref.offsetLeft);
      }
    });
    setTabWidths(widths);
    setTabOffsets(offsets);
  }, [tabs]);

  const activeIdx = tabs.findIndex((t) => t.value === activeTab.value);

  return (
    <div className={cn('w-full', containerClassName)}>
      {/* Tab Bar */}
      <div className="relative flex items-center gap-1 p-1.5 rounded-2xl bg-slate-100 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 w-fit no-visible-scrollbar overflow-x-auto">
        {/* Sliding Pill Background */}
        {tabWidths.length > 0 && (
          <motion.div
            className={cn(
              'absolute top-1.5 bottom-1.5 rounded-xl bg-white dark:bg-[#1a1a24] shadow-sm border border-slate-200/50 dark:border-white/10',
              activeTabClassName
            )}
            initial={false}
            animate={{
              x: tabOffsets[activeIdx] - 6,
              width: tabWidths[activeIdx],
            }}
            transition={{
              type: 'spring',
              stiffness: 400,
              damping: 35,
            }}
          />
        )}

        {tabs.map((tab, idx) => (
          <button
            key={tab.value}
            ref={(el) => { tabRefs.current[idx] = el; }}
            onClick={() => setActiveTab(tab)}
            onMouseEnter={() => setHoveredIdx(idx)}
            onMouseLeave={() => setHoveredIdx(null)}
            className={cn(
              'relative z-10 flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl transition-colors whitespace-nowrap',
              activeTab.value === tab.value
                ? 'text-slate-900 dark:text-white'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200',
              tabClassName
            )}
          >
            {tab.icon}
            {tab.title}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className={cn('mt-6 relative', contentClassName)}>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab.value}
            initial={{ opacity: 0, y: 12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
          >
            {activeTab.content}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
