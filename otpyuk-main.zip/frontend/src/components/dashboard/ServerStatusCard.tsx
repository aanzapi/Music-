/**
 * ServerStatusCard.tsx
 * Kartu status server dengan ping realtime dan signal bars
 */
'use client';

import { cn } from '@/lib/utils';

interface ServerStatusCardProps {
  name: string;
  flag?: string;
  ping: number;
  isOnline: boolean;
  className?: string;
}

function SignalBars({ strength }: { strength: 'strong' | 'medium' | 'weak' }) {
  return (
    <div className="flex items-end gap-0.5 h-4">
      {[1, 2, 3, 4].map((bar) => {
        const active =
          strength === 'strong' ? true :
          strength === 'medium' ? bar <= 3 :
          bar <= 1;
        return (
          <div
            key={bar}
            style={{ height: `${bar * 25}%` }}
            className={cn(
              'w-1 rounded-sm',
              active
                ? strength === 'strong' ? 'bg-green-500'
                : strength === 'medium' ? 'bg-amber-500'
                : 'bg-red-500'
                : 'bg-gray-200 dark:bg-gray-700'
            )}
          />
        );
      })}
    </div>
  );
}

export function ServerStatusCard({
  name, flag, ping, isOnline, className
}: ServerStatusCardProps) {
  const strength: 'strong' | 'medium' | 'weak' =
    ping < 50 ? 'strong' :
    ping < 150 ? 'medium' : 'weak';

  const pingColor =
    ping < 50 ? 'text-green-600 dark:text-green-400' :
    ping < 150 ? 'text-amber-600 dark:text-amber-400' :
    'text-red-600 dark:text-red-400';

  return (
    <div className={cn(
      'bg-white dark:bg-[#111118] rounded-xl border border-slate-100 dark:border-white/5',
      'p-4 flex items-center justify-between hover:shadow-lg transition-shadow',
      className
    )}>
      <div className="flex items-center gap-2.5">
        {flag && <span className="text-lg">{flag}</span>}
        <div>
          <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{name}</p>
          <div className="flex items-center gap-1.5 mt-0.5">
            <div className={cn(
              'w-1.5 h-1.5 rounded-full',
              isOnline ? 'bg-green-500 animate-ping-slow' : 'bg-red-500'
            )} />
            <span className={cn('text-xs font-mono', pingColor)}>
              {isOnline ? `${ping}ms` : 'Offline'}
            </span>
          </div>
        </div>
      </div>
      <SignalBars strength={isOnline ? strength : 'weak'} />
    </div>
  );
}
