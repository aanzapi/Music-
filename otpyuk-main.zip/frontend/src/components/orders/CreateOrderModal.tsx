"use client";

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Search, X, Loader2, Zap } from 'lucide-react';
import api from '@/lib/api';
import { notify } from '@/components/ui/custom-toast';

interface Service {
  service_code: number;
  service_name: string;
  service_img: string;
}

interface PricelistItem {
  provider_id: number;
  server_id: number;
  stock: number;
  rate: number;
  price: number;
  price_format: string;
  available: boolean;
}

interface Country {
  number_id: number;
  name: string;
  img: string;
  prefix: string;
  iso_code: string;
  rate: number;
  stock_total: number;
  pricelist: PricelistItem[];
}

interface Operator {
  id: number;
  name: string;
  image: string;
}

interface CreateOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: () => void;
}

export function CreateOrderModal({ isOpen, onClose, onOrderSuccess }: CreateOrderModalProps) {
  // Data States
  const [services, setServices] = useState<Service[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);

  // Selection States
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [searchCountry, setSearchCountry] = useState('');
  const [searchService, setSearchService] = useState('');
  const [expandedCountry, setExpandedCountry] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'rate' | 'price'>('price');

  // Loading States
  const [loadingServices, setLoadingServices] = useState(false);
  const [loadingCountries, setLoadingCountries] = useState(false);
  const [loadingOperators, setLoadingOperators] = useState(false);
  const [ordering, setOrdering] = useState(false);

  // View States
  const [view, setView] = useState<'main' | 'services' | 'operators'>('main');

  // Pending order selection for operator view
  const [pendingSelection, setPendingSelection] = useState<{
    numberId: number;
    providerId: number;
    price: number;
    countryName: string;
  } | null>(null);

  // Fetch Services on open
  useEffect(() => {
    if (isOpen && services.length === 0) {
      fetchServices();
    }
  }, [isOpen]);

  // Fetch Countries when service changes
  useEffect(() => {
    if (selectedService) {
      fetchCountries(selectedService.service_code);
    }
  }, [selectedService]);

  const fetchServices = async () => {
    setLoadingServices(true);
    try {
      const res = await api.get('/api/v1/orders/services');
      if (res.data.success) {
        setServices(res.data.data);
        // Pre-select WhatsApp or first available
        const defaultSvc = res.data.data.find((s: Service) => s.service_name.toLowerCase().includes('whatsapp')) || res.data.data[0];
        if (defaultSvc) setSelectedService(defaultSvc);
      }
    } catch (err: any) {
      notify.apiError(err, 'Gagal mengambil layanan');
    } finally {
      setLoadingServices(false);
    }
  };

  const fetchCountries = async (serviceId: number) => {
    setLoadingCountries(true);
    setExpandedCountry(null);
    try {
      const res = await api.get(`/api/v1/orders/countries?service_id=${serviceId}`);
      if (res.data.success) {
        setCountries(res.data.data);
      }
    } catch (err: any) {
      notify.apiError(err, 'Gagal mengambil daftar negara');
    } finally {
      setLoadingCountries(false);
    }
  };

  const handleOrderClick = async (country: Country, server: PricelistItem) => {
    setPendingSelection({
      numberId: country.number_id,
      providerId: server.provider_id,
      price: server.price,
      countryName: country.name
    });
    
    // Fetch operators
    setLoadingOperators(true);
    setView('operators');
    try {
      const res = await api.get(`/api/v1/orders/operators?country=${country.name.toLowerCase()}&provider_id=${server.provider_id}`);
      if (res.data.success) {
        setOperators(res.data.data);
      }
    } catch (err: any) {
      notify.apiError(err, 'Gagal mengambil operator');
      setView('main');
    } finally {
      setLoadingOperators(false);
    }
  };

  const submitOrder = async (operatorId: number) => {
    if (!selectedService || !pendingSelection) return;
    
    setOrdering(true);
    try {
      const payload = {
        numberId: pendingSelection.numberId,
        providerId: pendingSelection.providerId,
        operatorId: operatorId,
        serviceCode: selectedService.service_code,
        serviceName: selectedService.service_name,
        serviceImg: selectedService.service_img,
        country: pendingSelection.countryName,
        providerPrice: pendingSelection.price
      };
      
      const res = await api.post('/api/v1/orders/create', payload);
      if (res.data.success) {
        notify.orderSuccess(selectedService.service_name, res.data.data?.phoneNumber || 'Nomor baru');
        onOrderSuccess();
        onClose();
      }
    } catch (err: any) {
      notify.apiError(err, 'Gagal membuat pesanan');
    } finally {
      setOrdering(false);
      setView('main');
    }
  };

  // Filter and Sort
  const filteredCountries = countries
    .filter(c => c.name.toLowerCase().includes(searchCountry.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'rate') return b.rate - a.rate;
      const minPriceA = Math.min(...a.pricelist.map(p => p.price));
      const minPriceB = Math.min(...b.pricelist.map(p => p.price));
      return minPriceA - minPriceB;
    });

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md bg-white dark:bg-[#15151c] rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-slate-100 dark:border-white/5 flex items-center justify-between sticky top-0 bg-white dark:bg-[#15151c] z-20">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Beli Nomor Virtual</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Pilih sebuah aplikasi dan negaranya</p>
            </div>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-white/5 transition-colors">
              <X className="w-5 h-5 text-slate-400" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 relative no-scrollbar">
            {view === 'main' && (
              <>
                {/* Service Selector */}
                <div 
                  onClick={() => setView('services')}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    {loadingServices ? (
                      <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-white/10 animate-pulse" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-white dark:bg-[#1a1a24] shadow-sm p-1.5 flex items-center justify-center">
                        <img src={selectedService?.service_img || '/images/otpyuk-logo.webp'} alt="Service" className="w-full h-full object-contain" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                        {selectedService?.service_name || 'Loading...'}
                      </h3>
                      <p className="text-[11px] text-slate-500 font-semibold">Aplikasi yang dipilih</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-400" />
                </div>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Cari nama negara..." 
                    value={searchCountry}
                    onChange={(e) => setSearchCountry(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                  />
                </div>

                {/* Tabs */}
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-50 dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/10">
                  <button 
                    onClick={() => setSortBy('rate')}
                    className={`py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${sortBy === 'rate' ? 'bg-white dark:bg-[#20202a] text-blue-500 shadow-sm' : 'text-slate-500'}`}
                  >
                    <Zap className="w-3.5 h-3.5" /> Rate
                  </button>
                  <button 
                    onClick={() => setSortBy('price')}
                    className={`py-2 text-xs font-bold rounded-lg transition-colors ${sortBy === 'price' ? 'bg-white dark:bg-[#20202a] text-slate-900 dark:text-white shadow-sm' : 'text-slate-500'}`}
                  >
                    Harga
                  </button>
                </div>

                {/* Country List */}
                <div className="space-y-2 pb-4">
                  {loadingCountries ? (
                    <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-amber-500" /></div>
                  ) : filteredCountries.length === 0 ? (
                    <div className="text-center p-8 text-sm text-slate-500">Negara tidak ditemukan</div>
                  ) : (
                    filteredCountries.map((country) => (
                      <div key={country.number_id} className="border border-slate-100 dark:border-white/5 rounded-2xl overflow-hidden bg-white dark:bg-[#15151c]">
                        <div 
                          onClick={() => setExpandedCountry(expandedCountry === country.number_id ? null : country.number_id)}
                          className="px-4 py-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <img src={country.img} alt={country.name} className="w-6 h-4 object-cover rounded-sm shadow-sm" />
                            <span className="text-sm font-bold text-slate-900 dark:text-white">{country.name}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            <span className="text-slate-500 font-medium">{country.prefix}</span>
                            <span className="text-slate-400 font-bold px-1.5 py-0.5 bg-slate-100 dark:bg-white/10 rounded uppercase">{country.iso_code}</span>
                            <span className="text-amber-600 dark:text-amber-500 font-bold">Mulai Rp{Math.min(...country.pricelist.map(p => p.price)).toLocaleString('id-ID')}</span>
                            <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${expandedCountry === country.number_id ? 'rotate-90' : ''}`} />
                          </div>
                        </div>

                        {/* Expanded Servers */}
                        <AnimatePresence>
                          {expandedCountry === country.number_id && (
                            <motion.div 
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="bg-slate-50 dark:bg-white/5 border-t border-slate-100 dark:border-white/5"
                            >
                              <div className="p-2 space-y-1.5">
                                {country.pricelist.map((server, idx) => (
                                  <div key={idx} className="flex items-center justify-between p-3 bg-white dark:bg-[#15151c] rounded-xl border border-slate-100 dark:border-white/5 hover:border-amber-200 dark:hover:border-amber-500/30 transition-colors group shadow-sm hover:shadow-md">
                                    <div className="flex flex-col gap-1.5">
                                      <div className="flex items-center gap-2">
                                        <span className="px-2 py-0.5 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 text-[10px] font-bold rounded-md tracking-wide">
                                          Server {server.server_id}.0
                                        </span>
                                        <span className="text-[10px] font-medium text-slate-400">ID: {server.provider_id}</span>
                                        {server.rate > 80 && server.stock > 10 && (
                                          <span className="px-1.5 py-0.5 bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-400 text-[9px] font-bold rounded uppercase tracking-wider flex items-center gap-0.5">
                                            <Zap className="w-2.5 h-2.5" /> Recom
                                          </span>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-3 text-[10px] font-medium pl-1">
                                        <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                                          <div className={`w-1.5 h-1.5 rounded-full ${server.stock > 10 ? 'bg-green-500' : 'bg-red-500'}`} />
                                          Stok: <span className="text-slate-700 dark:text-slate-300 font-bold">{server.stock}</span>
                                        </div>
                                        <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                            server.rate > 60 
                                              ? 'bg-green-50 text-green-600 dark:bg-green-500/10 dark:text-green-400' 
                                              : server.rate > 30 
                                                ? 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400'
                                                : 'bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-400'
                                          }`}>
                                            Rate: {server.rate}%
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div className="flex items-center gap-3">
                                      <span className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">{server.price_format}</span>
                                      <button 
                                        onClick={() => handleOrderClick(country, server)}
                                        className="px-4 py-1.5 bg-white dark:bg-[#1a1a24] border border-blue-200 dark:border-blue-500/30 text-blue-600 dark:text-blue-400 text-xs font-bold rounded-lg group-hover:bg-blue-500 group-hover:text-white group-hover:border-blue-500 transition-all shadow-sm"
                                      >
                                        Order
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}

            {view === 'services' && (
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <button onClick={() => setView('main')} className="p-2 -ml-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors">
                    <ChevronRight className="w-5 h-5 rotate-180" />
                  </button>
                  <div className="relative flex-1">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Cari nama aplikasi..." 
                      value={searchService}
                      onChange={(e) => setSearchService(e.target.value)}
                      className="w-full bg-white dark:bg-[#15151c] border border-slate-200 dark:border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50 shadow-sm"
                    />
                  </div>
                </div>

                {!searchService && (
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-sm">Aplikasi Populer</h3>
                    <div className="grid grid-cols-3 gap-3">
                      {services
                        .filter(s => ['whatsapp', 'kredito', 'any other', 'telegram', 'grab', 'dana'].includes(s.service_name.toLowerCase()))
                        .slice(0, 6)
                        .map(svc => (
                          <div 
                            key={svc.service_code}
                            onClick={() => { setSelectedService(svc); setView('main'); }}
                            className="bg-white dark:bg-[#1a1a24] border border-slate-100 dark:border-white/5 shadow-sm rounded-2xl p-4 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-amber-200 hover:bg-amber-50 dark:hover:border-amber-500/30 dark:hover:bg-amber-500/10 transition-all"
                          >
                            <img src={svc.service_img} alt={svc.service_name} className="w-10 h-10 object-contain drop-shadow-sm" />
                            <span className="font-bold text-[11px] text-slate-900 dark:text-white text-center line-clamp-1">{svc.service_name}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-sm">Semua Aplikasi</h3>
                  <div className="space-y-2 pb-4">
                    {services
                      .filter(s => s.service_name.toLowerCase().includes(searchService.toLowerCase()))
                      .map(svc => (
                        <div 
                          key={svc.service_code}
                          onClick={() => { setSelectedService(svc); setView('main'); }}
                          className="bg-white dark:bg-[#1a1a24] border border-slate-100 dark:border-white/5 shadow-sm rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:border-amber-200 hover:bg-amber-50 dark:hover:border-amber-500/30 dark:hover:bg-amber-500/10 transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <img src={svc.service_img} alt={svc.service_name} className="w-8 h-8 object-contain drop-shadow-sm" />
                            <span className="font-bold text-sm text-slate-900 dark:text-white">{svc.service_name}</span>
                          </div>
                          <ChevronRight className="w-5 h-5 text-slate-400" />
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            )}

            {view === 'operators' && (
              <div className="space-y-4">
                <button onClick={() => setView('main')} className="text-sm font-bold text-slate-500 flex items-center gap-1 hover:text-slate-900 dark:hover:text-white">
                  <ChevronRight className="w-4 h-4 rotate-180" /> Kembali
                </button>
                <h3 className="font-bold text-slate-900 dark:text-white">Pilih Operator Seluler</h3>
                
                {loadingOperators ? (
                  <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-amber-500" /></div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {operators.map(op => (
                      <div 
                        key={op.id}
                        onClick={() => submitOrder(op.id)}
                        className="p-4 border border-slate-200 dark:border-white/10 rounded-2xl flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-500/10 transition-all relative overflow-hidden group"
                      >
                        {ordering && <div className="absolute inset-0 bg-white/50 dark:bg-black/50 z-10" />}
                        <img src={op.image} alt={op.name} className="w-12 h-12 object-contain group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold text-slate-600 dark:text-slate-300 capitalize">{op.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
