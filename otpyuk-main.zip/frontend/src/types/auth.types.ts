/**
 * auth.types.ts — Auth-related types
 */

export interface User {
  id: string;
  userId: string;
  email: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  balance: number;
  role: 'USER' | 'RESELLER' | 'ADMIN';
  isVerified: boolean;
  isActive: boolean;
  twoFaEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface LoginPayload {
  email: string;
  password: string;
}

export interface RegisterPayload {
  email: string;
  username: string;
  password: string;
}

export interface LoginResponse {
  user: User;
  accessToken: string;
}

export interface TwoFaResponse {
  requires2fa: true;
  tempUserId: string;
}

export interface Session {
  id: string;
  device: string;
  ip: string;
  lastActive: string;
  createdAt: string;
}
