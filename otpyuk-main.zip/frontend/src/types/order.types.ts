/**
 * order.types.ts — Order-related types
 */

export type OrderStatus = 'WAITING' | 'RECEIVED' | 'COMPLETED' | 'CANCELED' | 'EXPIRED' | 'REFUNDED';

export interface Order {
  id: string;
  orderId: string;
  userId: string;
  providerId: number;
  serviceId: number;
  serviceName: string;
  serviceImg?: string;
  phoneNumber: string;
  country: string;
  operator: string;
  price: number;
  providerPrice: number;
  status: OrderStatus;
  otpCode?: string;
  otpMessage?: string;
  expiredAt: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateOrderPayload {
  serviceId: number;
  country: string;
  operator?: string;
}

export interface ProviderService {
  service_code: number;
  service_name: string;
  service_img: string;
}

export interface ProviderPricelist {
  provider_id: string;
  server_id: number;
  stock: number;
  rate: number;
  price: number;
  price_format: string;
  available: boolean;
}

export interface ProviderCountry {
  number_id: number;
  name: string;
  img: string;
  prefix: string;
  iso_code: string;
  rate: number;
  stock_total: number;
  pricelist: ProviderPricelist[];
}

export interface ProviderOperator {
  id: number;
  name: string;
  image: string;
}

export type DepositMethod = 'QRIS' | 'USDT_BEP20' | 'USDT_TRC20' | 'USDT_POLYGON' | 'USDT_ERC20';
export type DepositStatus = 'PENDING' | 'SUCCESS' | 'EXPIRED' | 'CANCELED';

export interface Deposit {
  id: string;
  depositId: string;
  userId: string;
  amount: number;
  received: number;
  method: DepositMethod;
  status: DepositStatus;
  providerDepositId?: number;
  qrString?: string;
  qrImage?: string;
  expiredAt: string;
  paidAt?: string;
  createdAt: string;
}
