/**
 * constants.ts — App Constants
 * Centralized configuration values used across the frontend.
 */

export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || 'otpyuk';
export const APP_TAGLINE = 'OTP Cepat, Gak Pake Drama';
export const APP_DESCRIPTION =
  'Semua jadi lebih gampang—OTP langsung masuk tanpa ribet. Support 1.700+ layanan di 100+ negara, aman & terpercaya. Dari WhatsApp sampai TikTok, semua bisa. Yuk mulai gratis sekarang!';
  
export const API_URL = process.env.NEXT_PUBLIC_API_URL || 'https://api.otpyuk.my.id';

/** Owner social links */
export const SOCIAL_LINKS = {
  telegram: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
  whatsapp: 'https://wa.me/628988106426',
  github: 'https://github.com/frkhnsptra__',
  email: 'cuyaan08@gmail.com',
} as const;

/** Navigation items for homepage */
export const NAV_ITEMS = [
  { label: 'Beranda', href: '/#hero' },
  { label: 'Layanan', href: '/#services' },
  { label: 'Harga', href: '/#pricing' },
  { label: 'API', href: '/developer/api' },
  { label: 'Support', href: '/#footer' },
] as const;

/** Dashboard navigation items */
export const DASHBOARD_NAV = [
  { label: 'Home', href: '/client/dashboard', icon: 'Home' },
  { label: 'Deposit', href: '/client/topup', icon: 'Wallet' },
  { label: 'Orders', href: '/client/virtual-number', icon: 'ShoppingCart' },
  { label: 'Activity', href: '/client/activity', icon: 'Activity' },
  { label: 'Profile', href: '/client/profile', icon: 'User' },
] as const;

/** Stats section data */
export const STATS_DATA = [
  { value: 1700, suffix: '+', label: 'Jenis Layanan', icon: 'Layers' },
  { value: 100, suffix: '+', label: 'Negara Tersedia', icon: 'Globe' },
  { value: 50000, suffix: '+', label: 'Pengguna Aktif', icon: 'Users' },
  { value: 99, suffix: '%', label: 'Deliver Rate', icon: 'Zap' },
] as const;

/** Service categories for filter */
export const SERVICE_CATEGORIES = [
  { id: 'all', label: 'Semua' },
  { id: 'social', label: 'Media Sosial' },
  { id: 'ecommerce', label: 'E-Commerce' },
  { id: 'fintech', label: 'Fintech' },
  { id: 'game', label: 'Game' },
  { id: 'other', label: 'Lainnya' },
] as const;

/** Popular services displayed on homepage */
export const POPULAR_SERVICES = [
  { name: 'WhatsApp', icon: '💬', category: 'social', price: 650 },
  { name: 'Telegram', icon: '✈️', category: 'social', price: 700 },
  { name: 'TikTok', icon: '🎵', category: 'social', price: 800 },
  { name: 'Instagram', icon: '📷', category: 'social', price: 750 },
  { name: 'Facebook', icon: '👤', category: 'social', price: 700 },
  { name: 'Twitter/X', icon: '🐦', category: 'social', price: 850 },
  { name: 'Google/Gmail', icon: '📧', category: 'social', price: 900 },
  { name: 'Shopee', icon: '🛒', category: 'ecommerce', price: 1200 },
  { name: 'Tokopedia', icon: '🏪', category: 'ecommerce', price: 1100 },
  { name: 'Gojek', icon: '🏍️', category: 'fintech', price: 1500 },
  { name: 'DANA', icon: '💳', category: 'fintech', price: 1300 },
  { name: 'OVO', icon: '💜', category: 'fintech', price: 1400 },
  { name: 'GoPay', icon: '💚', category: 'fintech', price: 1350 },
  { name: 'LINE', icon: '💚', category: 'social', price: 800 },
  { name: 'Discord', icon: '🎮', category: 'social', price: 750 },
  { name: 'Steam', icon: '🎮', category: 'game', price: 900 },
  { name: 'Kredivo', icon: '💰', category: 'fintech', price: 1600 },
  { name: 'Grab', icon: '🚗', category: 'fintech', price: 1500 },
  { name: 'LinkedIn', icon: '💼', category: 'social', price: 950 },
  { name: 'Any Other', icon: '📱', category: 'other', price: 650 },
] as const;

export const TESTIMONIALS = [
  { name: 'Andi S.', rating: 5, text: 'Gila sih, OTP masuk cuma hitungan detik. Sekali coba langsung ketagihan!' },
  { name: 'Budi R.', rating: 5, text: 'Stok aman terus, harga santai, support juga cepet. Udah paling nyaman di sini.' },
  { name: 'Citra M.', rating: 4, text: 'Integrasi API-nya gampang banget, bot Telegram gue langsung jalan tanpa ribet.' },
  { name: 'Dimas P.', rating: 5, text: 'OTP gak masuk? Langsung auto refund. No drama, mantap!' },
  { name: 'Eka W.', rating: 5, text: 'Udah pake berbulan-bulan, sejauh ini lancar terus. Jarang banget ada kendala.' },
  { name: 'Fara L.', rating: 4, text: 'Harga ramah, tapi kualitas nomor tetep fresh. Worth it banget.' },
  { name: 'Gilang H.', rating: 5, text: 'Dashboard simpel tapi keren, semua gampang dipahami. Enak dipakai.' },
  { name: 'Hana D.', rating: 5, text: 'Top up gampang, dari QRIS sampai e-wallet semua bisa. Praktis banget!' },
] as const;

export const FAQ_ITEMS = [
  {
    q: 'OTP virtual itu apaan sih?',
    a: 'Simpelnya, ini nomor sementara buat nerima kode OTP tanpa perlu kartu SIM fisik. Jadi lebih praktis & privasi tetap aman.',
  },
  {
    q: 'Biasanya OTP masuk berapa lama?',
    a: 'Cepet kok—rata-rata cuma 3–15 detik setelah order. Untuk layanan populer, tingkat keberhasilannya sampai 99%.',
  },
  {
    q: 'Nomornya bisa dipakai ulang gak?',
    a: 'Enggak ya. Semua nomor sekali pakai biar tetap aman dan gak bercampur sama user lain.',
  },
  {
    q: 'Cara isi saldo gimana?',
    a: 'Tinggal top up lewat QRIS (semua e-wallet & bank) atau crypto USDT. Minimal top up juga ringan, mulai dari Rp10.000 aja.',
  },
  {
    q: 'Kalau OTP gak masuk gimana?',
    a: 'Tenang, ada auto-refund. Jadi kalau OTP gagal masuk dalam waktu tertentu, saldo langsung balik otomatis.',
  },
  {
    q: 'Ada API buat developer gak?',
    a: 'Ada dong. Kita sediakan REST API lengkap + dokumentasi. Tinggal bikin API key di dashboard, langsung bisa dipakai.',
  },
  {
    q: 'Pembayarannya bisa pakai apa aja?',
    a: 'Saat ini support QRIS (semua bank & e-wallet Indonesia) dan USDT di berbagai jaringan.',
  },
  {
    q: 'Data gue aman gak?',
    a: 'Aman. Sistem pakai enkripsi, ada 2FA, dan OTP gak disimpan setelah transaksi selesai.',
  },
] as const;

/** Server status mock data */
export const SERVERS = [
  { name: 'Main Page', country: 'id' },
  { name: 'Main Page 2', country: 'id' },
  { name: 'Main Page 3', country: 'sg' },
  { name: 'Main Page 4', country: 'us' },
  { name: 'CDN Static', country: 'sg' },
  { name: 'CDN Assets', country: 'jp' },
  { name: 'Webhook', country: 'id' },
  { name: 'Workers', country: 'us' },
] as const;

/** World map connection dots */
export const WORLD_MAP_DOTS = [
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 3.1, lng: 101.7 } },   // ID → MY
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 13.7, lng: 100.5 } },  // ID → TH
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 14.6, lng: 121.0 } },  // ID → PH
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 1.35, lng: 103.8 } },  // ID → SG
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 38.9, lng: -77.0 } },  // ID → US
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 51.5, lng: -0.1 } },   // ID → UK
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 52.5, lng: 13.4 } },   // ID → DE
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: -15.8, lng: -47.9 } }, // ID → BR
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 28.6, lng: 77.2 } },   // ID → IN
  { start: { lat: -6.2, lng: 106.8 }, end: { lat: 35.7, lng: 139.7 } },  // ID → JP
] as const;
