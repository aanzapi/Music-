/**
 * api.ts — Axios HTTP Client Instance
 * Pre-configured Axios with base URL, interceptors, and auth token injection.
 */

import axios from 'axios';
import { API_URL } from './constants';

/**
 * Axios instance configured for the otpyuk backend API.
 */
const api = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  withCredentials: true, // Send cookies (refresh token)
  headers: {
    'Content-Type': 'application/json',
  },
});

/** 
 * Access token storage — uses sessionStorage so the token survives 
 * page refreshes within the same tab, but is cleared when the tab closes.
 * This prevents the 401 → refresh → 429 cascade that happens with pure in-memory storage.
 */
let accessToken: string | null = null;

// Restore token from sessionStorage on module init (survives page refresh)
if (typeof window !== 'undefined') {
  accessToken = sessionStorage.getItem('sf_access_token');
}

/**
 * Set the access token for subsequent requests.
 * @param token - JWT access token
 */
export function setAccessToken(token: string | null): void {
  accessToken = token;
  if (typeof window !== 'undefined') {
    if (token) {
      sessionStorage.setItem('sf_access_token', token);
    } else {
      sessionStorage.removeItem('sf_access_token');
    }
  }
}

/**
 * Get the current access token.
 */
export function getAccessToken(): string | null {
  return accessToken;
}

// ── Request Interceptor: Inject auth token ────────
api.interceptors.request.use(
  (config) => {
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor: Auto-refresh on 401 ────
let isRefreshing = false;
let failedQueue: Array<{
  resolve: (token: string) => void;
  reject: (error: unknown) => void;
}> = [];

function processQueue(error: unknown, token: string | null = null) {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else if (token) {
      prom.resolve(token);
    }
  });
  failedQueue = [];
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Don't retry on rate limit (429) — just reject immediately
    if (error.response?.status === 429) {
      return Promise.reject(error);
    }

    // If 401 and not already retrying, attempt token refresh
    // But skip if the failing request IS the refresh endpoint (prevents infinite loop)
    const isRefreshRequest = originalRequest?.url?.includes('/auth/refresh');
    if (error.response?.status === 401 && !originalRequest._retry && !isRefreshRequest) {
      if (isRefreshing) {
        // Queue this request until refresh completes
        return new Promise((resolve, reject) => {
          failedQueue.push({
            resolve: (token: string) => {
              originalRequest.headers.Authorization = `Bearer ${token}`;
              resolve(api(originalRequest));
            },
            reject,
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const { data } = await axios.post(
          `${API_URL}/api/v1/auth/refresh`,
          {},
          { withCredentials: true }
        );

        const newToken = data.data.accessToken;
        setAccessToken(newToken);
        processQueue(null, newToken);

        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        setAccessToken(null);

        // Redirect to login if refresh fails (only once, not in a loop)
        if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/login')) {
          window.location.href = '/login';
        }

        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

export default api;
