/**
 * recaptcha.ts — reCAPTCHA type declarations and shared helpers
 * Supports both reCAPTCHA v2 (checkbox) and v3 (invisible).
 */

declare global {
  interface Window {
    grecaptcha: {
      ready: (cb: () => void) => void;
      execute: (siteKey: string, options: { action: string }) => Promise<string>;
      render: (container: HTMLElement, options: {
        sitekey: string;
        callback: (token: string) => void;
        'expired-callback': () => void;
        theme?: 'light' | 'dark';
        size?: 'normal' | 'compact';
      }) => number;
      reset: (widgetId: number) => void;
    };
    onRecaptchaLoad?: () => void;
  }
}

const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || '';

/**
 * Execute reCAPTCHA v3 and return the token.
 * Returns empty string if reCAPTCHA is not configured.
 */
export async function executeRecaptcha(action: string): Promise<string> {
  if (!SITE_KEY || typeof window === 'undefined' || !window.grecaptcha) {
    return '';
  }

  return new Promise((resolve) => {
    window.grecaptcha.ready(async () => {
      try {
        const token = await window.grecaptcha.execute(SITE_KEY, { action });
        resolve(token);
      } catch {
        resolve('');
      }
    });
  });
}
