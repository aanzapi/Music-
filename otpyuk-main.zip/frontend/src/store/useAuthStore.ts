/**
 * useAuthStore.ts — Auth State Management (Zustand)
 */

import { create } from 'zustand';

interface User {
  id: string;
  userId: string;
  email: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  balance: number;
  role: string;
  isVerified: boolean;
  twoFaEnabled: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  updateBalance: (balance: number) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  setUser: (user) => set({ user, isAuthenticated: !!user }),
  updateBalance: (balance) =>
    set((state) => ({
      user: state.user ? { ...state.user, balance } : null,
    })),
  logout: () => set({ user: null, isAuthenticated: false }),
}));
