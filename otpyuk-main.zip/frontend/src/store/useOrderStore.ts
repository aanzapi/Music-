/**
 * useOrderStore.ts — Order State Management (Zustand)
 */

import { create } from 'zustand';

interface Order {
  id: string;
  orderId: string;
  serviceName: string;
  serviceImg?: string;
  phoneNumber: string;
  country: string;
  operator: string;
  price: number;
  status: string;
  otpCode?: string;
  otpMessage?: string;
  expiredAt: string;
  createdAt: string;
}

interface OrderState {
  activeOrders: Order[];
  setActiveOrders: (orders: Order[]) => void;
  updateOrder: (orderId: string, data: Partial<Order>) => void;
  removeOrder: (orderId: string) => void;
}

export const useOrderStore = create<OrderState>((set) => ({
  activeOrders: [],
  setActiveOrders: (orders) => set({ activeOrders: orders }),
  updateOrder: (orderId, data) =>
    set((state) => ({
      activeOrders: state.activeOrders.map((o) =>
        o.orderId === orderId ? { ...o, ...data } : o
      ),
    })),
  removeOrder: (orderId) =>
    set((state) => ({
      activeOrders: state.activeOrders.filter((o) => o.orderId !== orderId),
    })),
}));
