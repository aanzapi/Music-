/**
 * useOtpPolling.ts — Poll for OTP status updates
 * Auto-polls active orders every N seconds and updates state.
 */

'use client';

import { useEffect, useRef, useCallback } from 'react';
import api from '@/lib/api';
import { useOrderStore } from '@/store/useOrderStore';

interface UseOtpPollingOptions {
  enabled?: boolean;
  interval?: number; // ms
}

export function useOtpPolling({ enabled = true, interval = 5000 }: UseOtpPollingOptions = {}) {
  const { activeOrders, setActiveOrders, updateOrder } = useOrderStore();
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const poll = useCallback(async () => {
    const waitingOrders = activeOrders.filter(
      (o) => o.status === 'WAITING' || o.status === 'RECEIVED'
    );

    if (waitingOrders.length === 0) return;

    for (const order of waitingOrders) {
      try {
        const { data } = await api.get(`/api/v1/orders/${order.orderId}/status`);
        const updated = data.data;
        if (updated.status !== order.status || updated.otpCode !== order.otpCode) {
          updateOrder(order.orderId, updated);
        }
      } catch {
        // Silently fail individual polls
      }
    }
  }, [activeOrders, updateOrder]);

  useEffect(() => {
    if (!enabled) return;

    intervalRef.current = setInterval(poll, interval);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [enabled, interval, poll]);

  const fetchAll = useCallback(async () => {
    try {
      const { data } = await api.get('/api/v1/orders?status=WAITING,RECEIVED&limit=50');
      setActiveOrders(data.data || []);
    } catch { /* ignore */ }
  }, [setActiveOrders]);

  return { poll, fetchAll, activeOrders };
}
