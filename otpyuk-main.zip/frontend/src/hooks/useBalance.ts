/**
 * useBalance.ts — Real-time balance polling hook
 */

'use client';

import { useEffect, useCallback, useRef, useState } from 'react';
import api from '@/lib/api';
import { useAuthStore } from '@/store/useAuthStore';

interface UseBalanceOptions {
  enabled?: boolean;
  interval?: number; // ms
}

export function useBalance({ enabled = true, interval = 10000 }: UseBalanceOptions = {}) {
  const { updateBalance } = useAuthStore();
  const [balance, setBalance] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchBalance = useCallback(async () => {
    try {
      const { data } = await api.get('/api/v1/user/balance');
      const newBalance = data.data.balance;
      setBalance(newBalance);
      updateBalance(newBalance);
    } catch { /* ignore */ }
  }, [updateBalance]);

  useEffect(() => {
    if (!enabled) return;
    fetchBalance();
    intervalRef.current = setInterval(fetchBalance, interval);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [enabled, interval, fetchBalance]);

  return { balance, refetch: fetchBalance };
}
