# 🐤 otpyuk — Buyers Edition

> Platform jual beli OTP virtual dari 1.700+ layanan di 100+ negara.  
> Versi ini khusus untuk **Buyers** (pembeli lisensi). Tinggal deploy, atur env, langsung jalan.

---

## 📋 Daftar Isi

- [Apa Itu otpyuk?](#-apa-itu-otpyuk)
- [Tech Stack](#-tech-stack)
- [Struktur Folder](#-struktur-folder)
- [Cara Pasang (Step by Step)](#-cara-pasang-step-by-step)
- [Environment Variables](#-environment-variables)
- [Deploy ke Vercel](#-deploy-ke-vercel)
- [Cron Job](#-cron-job)
- [FAQ Troubleshooting](#-faq-troubleshooting)

---

## 🐣 Apa Itu otpyuk?

otpyuk adalah website marketplace OTP virtual. User bisa:
1. Daftar akun (email / Google / GitHub)
2. Top up saldo via QRIS, Dana, OVO, GoPay, BRI
3. Beli nomor virtual untuk terima OTP (WhatsApp, Telegram, TikTok, dll)
4. Nomor & OTP muncul otomatis di dashboard

**Buyers Edition** = versi yang kamu beli. Sudah siap pakai, tinggal konfigurasi.

---

## 🛠 Tech Stack

| Bagian | Teknologi |
|--------|-----------|
| **Frontend** | Next.js 16, React, TailwindCSS, Framer Motion |
| **Backend** | Express.js, TypeScript, Prisma ORM |
| **Database** | PostgreSQL (Supabase / Neon) |
| **Cache** | Upstash Redis |
| **Email** | SendGrid API |
| **Provider OTP** | RumahOTP v2 API |
| **Deploy** | Vercel (frontend + serverless backend) |

---

## 📁 Struktur Folder

```
otpyuk/
├── frontend/          ← Next.js (halaman web)
│   ├── src/
│   │   ├── app/       ← Halaman-halaman
│   │   ├── components/← Komponen UI
│   │   ├── lib/       ← Utils, API client
│   │   └── store/     ← State management
│   └── .env.example   ← Env frontend
│
├── src/               ← Backend Express
│   ├── config/        ← Database, env config
│   ├── controllers/   ← Handler request
│   ├── middleware/     ← Auth, rate limit, CORS
│   ├── routes/        ← API routes
│   ├── services/      ← Business logic
│   └── utils/         ← Helper functions
│
├── prisma/            ← Database schema
├── api/               ← Vercel serverless entry
├── vercel.json        ← Vercel routing config
├── .env.example       ← Env backend
└── package.json
```

---

## 🚀 Cara Pasang (Step by Step)

### Step 1: Clone Repository

```bash
git clone https://github.com/USERNAME/otpyuk-Buyyers.git
cd otpyuk-Buyyers
```

### Step 2: Install Dependencies

```bash
# Install backend
npm install

# Install frontend
cd frontend
npm install
cd ..
```

### Step 3: Buat Database

Pilih SALAH SATU:

**Opsi A — Supabase (Gratis)**
1. Buka https://supabase.com → bikin project baru
2. Pergi ke **Settings → Database**
3. Copy **Connection string (URI)** → taruh di `DATABASE_URL`
4. Copy **Direct connection** → taruh di `DIRECT_URL`

**Opsi B — Neon (Gratis)**
1. Buka https://neon.tech → bikin project baru
2. Copy connection string → taruh di `DATABASE_URL` dan `DIRECT_URL`

### Step 4: Buat Redis

1. Buka https://console.upstash.com
2. Bikin database Redis baru (pilih region terdekat)
3. Copy **REST URL** → taruh di `UPSTASH_REDIS_REST_URL`
4. Copy **REST Token** → taruh di `UPSTASH_REDIS_REST_TOKEN`

### Step 5: Setup SendGrid (Email)

1. Buka https://sendgrid.com → daftar gratis
2. Pergi ke **Settings → API Keys → Create API Key**
3. Copy API key → taruh di `SENDGRID_API_KEY`
4. Verifikasi email pengirim di **Sender Authentication**
5. Email yang diverifikasi → taruh di `EMAIL_FROM`

### Step 6: Buat File `.env`

```bash
# Di root folder (backend)
cp .env.example .env

# Di folder frontend
cp frontend/.env.example frontend/.env
```

Buka kedua file `.env`, isi semua value-nya. Lihat section [Environment Variables](#-environment-variables) di bawah.

### Step 7: Setup Database Schema

```bash
# Generate Prisma client
npx prisma generate

# Push schema ke database
npx prisma db push
```

### Step 8: Jalankan Lokal

Buka **2 terminal** terpisah:

**Terminal 1 — Backend:**
```bash
npm run dev
```
Backend jalan di `http://localhost:3001`

**Terminal 2 — Frontend:**
```bash
cd frontend
npm run dev
```
Frontend jalan di `http://localhost:3000`

Buka browser → `http://localhost:3000` → selesai! 🎉

---

## 🔑 Environment Variables

### Backend (`.env` di root)

| Variable | Wajib? | Contoh | Penjelasan |
|----------|--------|--------|------------|
| `NODE_ENV` | ✅ | `development` | `development` atau `production` |
| `PORT` | ✅ | `3001` | Port backend |
| `DATABASE_URL` | ✅ | `postgresql://...` | URL database PostgreSQL |
| `DIRECT_URL` | ✅ | `postgresql://...` | Direct URL database (tanpa pooler) |
| `UPSTASH_REDIS_REST_URL` | ✅ | `https://...upstash.io` | URL Redis dari Upstash |
| `UPSTASH_REDIS_REST_TOKEN` | ✅ | `AX...` | Token Redis dari Upstash |
| `JWT_ACCESS_SECRET` | ✅ | *(random string)* | Secret untuk JWT access token |
| `JWT_REFRESH_SECRET` | ✅ | *(random string)* | Secret untuk JWT refresh token |
| `RUMAHOTP_BASE_URL` | ✅ | `https://www.rumahotp.io/api` | URL API provider OTP |
| `RUMAHOTP_API_KEY` | ✅ | `rh_...` | API key dari RumahOTP |
| `SENDGRID_API_KEY` | ✅ | `SG....` | API key SendGrid |
| `EMAIL_FROM` | ✅ | `noreply@domain.com` | Email pengirim (harus verified) |
| `APP_URL` | ✅ | `http://localhost:3000` | URL frontend |
| `CORS_ORIGIN` | ✅ | `http://localhost:3000` | URL yang boleh akses API |
| `CRON_SECRET` | ✅ | *(random string)* | Secret untuk protect cron endpoint |
| `MARGIN_DEPOSIT` | ✅ | `350` | Fee flat per deposit (Rp). Contoh: 350 = tiap depo kena fee Rp350 |
| `MARGIN_ORDER` | ✅ | `250` | Fee flat per harga order (Rp). Contoh: 250 = harga asli + Rp250 |
| `GOOGLE_CLIENT_ID` | ❌ | `...apps.googleusercontent.com` | Untuk login Google |
| `GOOGLE_CLIENT_SECRET` | ❌ | `GOCSPX-...` | Secret Google OAuth |
| `GITHUB_CLIENT_ID` | ❌ | `Iv1...` | Untuk login GitHub |
| `GITHUB_CLIENT_SECRET` | ❌ | `ghs_...` | Secret GitHub OAuth |
| `RECAPTCHA_SECRET_KEY` | ❌ | `6Le...` | Secret key reCAPTCHA v3 |

> 💡 **Cara generate JWT secret:**
> ```bash
> node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
> ```

### Frontend (`frontend/.env`)

| Variable | Wajib? | Contoh | Penjelasan |
|----------|--------|--------|------------|
| `NEXT_PUBLIC_APP_NAME` | ✅ | `otpyuk` | Nama app |
| `NEXT_PUBLIC_APP_URL` | ✅ | `http://localhost:3000` | URL frontend |
| `NEXT_PUBLIC_SITE_URL` | ✅ | `https://otpyuk.markect.dev` | URL production |
| `NEXT_PUBLIC_API_URL` | ✅ | `http://localhost:3001` | URL backend API |
| `NEXTAUTH_URL` | ✅ | `http://localhost:3000` | URL NextAuth |
| `NEXTAUTH_SECRET` | ✅ | *(random string)* | Secret NextAuth |
| `GOOGLE_CLIENT_ID` | ❌ | `...apps.googleusercontent.com` | Google OAuth |
| `GOOGLE_CLIENT_SECRET` | ❌ | `GOCSPX-...` | Google OAuth secret |
| `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` | ❌ | `6Le...` | Site key reCAPTCHA |

---

## ☁️ Deploy ke Vercel

### Step 1: Push ke GitHub
```bash
git add -A
git commit -m "initial deploy"
git push origin master
```

### Step 2: Import di Vercel
1. Buka https://vercel.com → **Add New Project**
2. Import repository dari GitHub
3. **Root Directory**: biarkan kosong (jangan isi)
4. **Framework Preset**: pilih **Other**
5. Vercel akan otomatis baca `vercel.json`

### Step 3: Isi Environment Variables
Di halaman deploy Vercel, masukkan **SEMUA** env variable dari tabel di atas.

> ⚠️ **Penting untuk production:**
> - `NODE_ENV` = `production`
> - `APP_URL` = URL Vercel kamu (misal `https://demo-otpyuk.markect.dev`)
> - `CORS_ORIGIN` = sama dengan `APP_URL`
> - `NEXT_PUBLIC_API_URL` = sama dengan `APP_URL` (karena backend jadi serverless di path `/api`)
> - `NEXT_PUBLIC_APP_URL` = sama dengan `APP_URL`

### Step 4: Deploy!
Klik **Deploy** dan tunggu selesai. Biasanya 2-3 menit.

---

## ⏰ Cron Job

Backend butuh cron job untuk:
- Cek deposit yang sudah dibayar (auto credit saldo)
- Auto-refund order expired
- Auto-expire deposit yang lewat 15 menit
- Cleanup session expired

### Setup di cron-job.org (Gratis)

1. Buka https://cron-job.org → daftar
2. Buat cron baru:

**Cron 1 — Every Minute:**
- URL: `https://DOMAIN-KAMU/api/v1/cron/every-minute`
- Method: `GET`
- Schedule: `Every 1 minute`
- Header: `x-cron-secret: ISI_CRON_SECRET_KAMU`

**Cron 2 — Daily Cleanup:**
- URL: `https://DOMAIN-KAMU/api/v1/cron/daily`
- Method: `GET`
- Schedule: `Once a day (00:00)`
- Header: `x-cron-secret: ISI_CRON_SECRET_KAMU`

> Ganti `DOMAIN-KAMU` dengan URL Vercel kamu.  
> Ganti `ISI_CRON_SECRET_KAMU` dengan value `CRON_SECRET` di env.

---

## 🆘 FAQ Troubleshooting

### ❓ Build error "Cannot find module"
Pastikan sudah `npm install` di **kedua** folder (root + frontend).

### ❓ Error "ENOENT: logs"
Logger sudah diperbaiki. Pastikan kamu pakai versi terbaru.

### ❓ Deposit dibayar tapi saldo tidak masuk
- Pastikan cron job aktif dan jalan setiap menit
- Cek log Vercel untuk error pada cron endpoint
- Deposit akan otomatis dicek setiap 5 detik saat user di halaman topup

### ❓ Email tidak terkirim
- Pastikan `SENDGRID_API_KEY` benar
- Pastikan email di `EMAIL_FROM` sudah diverifikasi di SendGrid
- Cek quota pengiriman SendGrid (free tier: 100/hari)

### ❓ RumahOTP error 502
Provider sedang down. Ini bukan error dari sistem kita. Halaman landing akan otomatis tampilkan data fallback.

### ❓ Login Google/GitHub tidak bisa
- Pastikan `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET` terisi
- Di Google Console, tambahkan **Authorized redirect URI**: `https://DOMAIN-KAMU/api/v1/auth/google/callback`
- Di GitHub Settings → OAuth Apps, set callback URL: `https://DOMAIN-KAMU/api/v1/auth/github/callback`

### ❓ Favicon masih logo Vercel
Clear browser cache atau buka incognito mode.

---

## 📄 Lisensi

Proyek ini **TIDAK open source**. Lihat [LICENSE](./LICENSE) untuk detail.

## 👥 Kontributor

Lihat [CONTRIBUTORS.md](./CONTRIBUTORS.md)

---

<div align="center">

**Dibuat dengan ❤️ oleh Tim otpyuk**

🐤 *Otpyuk says: "OTP cepat, hidup tenang!"*

</div>
