#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# install.sh — otpyuk 1-Click VPS Setup
# Tested on: Ubuntu 22.04 LTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

set -e

# ── Colors ─────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

echo -e "${YELLOW}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🐤 otpyuk — VPS Installation Script"
echo "  OTP Super Cepat, Instan & Terpercaya"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${NC}"

# ── Check root ─────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Error: Please run as root (sudo ./install.sh)${NC}"
  exit 1
fi

# ── Gather inputs ─────────────────────────────────
echo -e "${CYAN}Configuration Setup${NC}"
echo "────────────────────────────────────────────"

read -p "Domain name (e.g., api.otpyuk.com): " DOMAIN
read -p "Database password: " DB_PASSWORD
read -p "JWT Access Secret (min 32 chars): " JWT_ACCESS
read -p "JWT Refresh Secret (min 32 chars): " JWT_REFRESH
read -p "RumahOTP API Key: " RUMAHOTP_KEY
read -p "Upstash Redis REST URL: " UPSTASH_URL
read -p "Upstash Redis REST Token: " UPSTASH_TOKEN
read -p "Google OAuth Client ID: " GOOGLE_ID
read -p "Google OAuth Client Secret: " GOOGLE_SECRET
read -p "reCAPTCHA Secret Key: " RECAPTCHA_KEY
read -p "SendGrid API Key: " SENDGRID_KEY
read -p "Frontend URL (e.g., https://otpyuk.com): " FRONTEND_URL

echo ""
echo -e "${GREEN}Starting installation...${NC}"

# ── Step 1: System update ─────────────────────────
echo -e "${CYAN}[1/8] Updating system...${NC}"
apt-get update -y && apt-get upgrade -y
apt-get install -y curl git wget gnupg2 software-properties-common apt-transport-https ca-certificates lsb-release

# ── Step 2: Install Docker ────────────────────────
echo -e "${CYAN}[2/8] Installing Docker...${NC}"
if ! command -v docker &> /dev/null; then
  curl -fsSL https://get.docker.com | sh
  systemctl enable docker
  systemctl start docker
fi

# Install Docker Compose plugin
if ! docker compose version &> /dev/null; then
  apt-get install -y docker-compose-plugin
fi

echo -e "${GREEN}Docker version: $(docker --version)${NC}"

# ── Step 3: Install Certbot ───────────────────────
echo -e "${CYAN}[3/8] Installing Certbot...${NC}"
apt-get install -y certbot

# ── Step 4: Generate .env file ────────────────────
echo -e "${CYAN}[4/8] Generating .env file...${NC}"

cat > .env << EOF
NODE_ENV=production
PORT=3001

# Database
DATABASE_URL=postgresql://otpyuk:${DB_PASSWORD}@postgres:5432/otpyuk
DB_PASSWORD=${DB_PASSWORD}

# Upstash Redis (serverless)
UPSTASH_REDIS_REST_URL=${UPSTASH_URL}
UPSTASH_REDIS_REST_TOKEN=${UPSTASH_TOKEN}

# JWT
JWT_ACCESS_SECRET=${JWT_ACCESS}
JWT_REFRESH_SECRET=${JWT_REFRESH}
JWT_ACCESS_EXPIRE=15m
JWT_REFRESH_EXPIRE=7d

# RumahOTP
RUMAHOTP_BASE_URL=https://www.rumahotp.io/api
RUMAHOTP_API_KEY=${RUMAHOTP_KEY}

# Google OAuth
GOOGLE_CLIENT_ID=${GOOGLE_ID}
GOOGLE_CLIENT_SECRET=${GOOGLE_SECRET}

# reCAPTCHA
RECAPTCHA_SECRET_KEY=${RECAPTCHA_KEY}

# Email
SENDGRID_API_KEY=${SENDGRID_KEY}
EMAIL_FROM=noreply@${DOMAIN}

# App
APP_URL=https://${DOMAIN}
CORS_ORIGIN=${FRONTEND_URL}

# Pricing
PRICE_MARKUP_PERCENT=20
EOF

echo -e "${GREEN}.env file created${NC}"

# ── Step 5: Setup SSL ─────────────────────────────
echo -e "${CYAN}[5/8] Setting up SSL certificates...${NC}"
mkdir -p nginx/ssl

# Stop nginx temporarily if running
docker compose down nginx 2>/dev/null || true

# Get SSL certificate
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos --email "admin@${DOMAIN}" || {
  echo -e "${YELLOW}Warning: SSL setup failed. Using self-signed cert for now.${NC}"
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout nginx/ssl/privkey.pem \
    -out nginx/ssl/fullchain.pem \
    -subj "/CN=${DOMAIN}"
}

# Copy certs if certbot succeeded
if [ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ]; then
  cp /etc/letsencrypt/live/${DOMAIN}/fullchain.pem nginx/ssl/
  cp /etc/letsencrypt/live/${DOMAIN}/privkey.pem nginx/ssl/
fi

# ── Step 6: Update nginx config ───────────────────
echo -e "${CYAN}[6/8] Configuring Nginx...${NC}"
sed -i "s/server_name _;/server_name ${DOMAIN};/g" nginx/nginx.conf

# ── Step 7: Build & start containers ──────────────
echo -e "${CYAN}[7/8] Building and starting containers...${NC}"
docker compose -f docker-compose.yml -f docker-compose.prod.yml build
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Wait for database to be ready
echo "Waiting for database..."
sleep 10

# Run Prisma migrations
docker compose exec backend npx prisma migrate deploy

# ── Step 8: Setup auto-renewal ────────────────────
echo -e "${CYAN}[8/8] Setting up SSL auto-renewal...${NC}"
(crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet --post-hook 'docker compose -f $(pwd)/docker-compose.yml restart nginx'") | crontab -

# ── Summary ───────────────────────────────────────
echo ""
echo -e "${GREEN}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🐤 otpyuk — Installation Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  API URL   : https://${DOMAIN}"
echo "  API Docs  : https://${DOMAIN}/api-docs"
echo "  Database  : PostgreSQL (inside Docker)"
echo "  Cache     : Upstash Redis (serverless)"
echo ""
echo "  Container Status:"
docker compose ps
echo ""
echo "  Useful commands:"
echo "    docker compose logs -f backend   # View backend logs"
echo "    docker compose exec backend npx prisma studio  # DB GUI"
echo "    docker compose restart           # Restart all services"
echo ""
echo -e "${NC}"
