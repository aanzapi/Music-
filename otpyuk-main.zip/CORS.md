# 🔒 CORS — Cross-Origin Resource Sharing

## Apa itu CORS?

CORS (Cross-Origin Resource Sharing) adalah mekanisme keamanan browser yang mengontrol **siapa yang boleh mengakses API backend kamu**.

Tanpa CORS, browser akan **memblokir** request dari domain lain ke API kamu.

---

## Cara Kerja di otpyuk

### Konfigurasi

CORS diatur melalui environment variable:

```env
CORS_ORIGIN=http://localhost:3000
```

Variable ini menentukan **domain mana** yang boleh mengakses API backend.

### Contoh Pengaturan

**Development (lokal):**
```env
CORS_ORIGIN=http://localhost:3000
```

**Production (single domain):**
```env
CORS_ORIGIN=https://otpyuk.markect.dev
```

**Production (custom domain):**
```env
CORS_ORIGIN=https://demo-otpyuk.markect.dev
```

---

## Penjelasan Simple

```
Browser (Frontend)               Backend API
http://localhost:3000      →     http://localhost:3001
        ↓                               ↓
   "Halo, aku dari                "Hmm, cek CORS_ORIGIN...
    localhost:3000,                localhost:3000 boleh!
    mau ambil data"               Ini datanya ✅"
```

Kalau domain **TIDAK cocok** dengan `CORS_ORIGIN`:

```
Browser (Frontend)               Backend API
https://hacker-site.com   →     http://localhost:3001
        ↓                               ↓
   "Halo, aku dari                "Hmm, cek CORS_ORIGIN...
    hacker-site.com,              hacker-site.com TIDAK
    mau ambil data"               boleh! DITOLAK ❌"
```

---

## Headers yang Dikirim

Backend otpyuk mengirim header CORS berikut:

| Header | Value | Fungsi |
|--------|-------|--------|
| `Access-Control-Allow-Origin` | Dari `CORS_ORIGIN` env | Domain yang diizinkan |
| `Access-Control-Allow-Methods` | `GET, POST, PUT, DELETE, PATCH` | HTTP methods yang boleh |
| `Access-Control-Allow-Headers` | `Content-Type, Authorization, x-api-key` | Header yang boleh dikirim |
| `Access-Control-Allow-Credentials` | `true` | Izinkan kirim cookie |

---

## Implementasi

CORS dikonfigurasi di middleware Express (`src/middleware/cors.middleware.ts`):

```typescript
import cors from 'cors';

const corsOptions = {
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-api-key'],
};

app.use(cors(corsOptions));
```

---

## Troubleshooting

### ❌ Error: "CORS policy: No 'Access-Control-Allow-Origin'"

**Penyebab:** `CORS_ORIGIN` di backend tidak sama dengan URL frontend.

**Solusi:**
1. Cek URL frontend kamu (perhatikan `http` vs `https`, ada/tidaknya `/` di akhir)
2. Set `CORS_ORIGIN` di env backend **persis sama** dengan URL frontend
3. **JANGAN** pakai `*` (asterisk) — tidak aman dan cookie tidak akan terkirim

### ❌ Error: "CORS policy: credentials"

**Penyebab:** Frontend mengirim cookie tapi CORS tidak mengizinkan credentials.

**Solusi:** Pastikan `credentials: true` ada di konfigurasi CORS backend.

### ❌ Preflight request gagal

**Penyebab:** Browser kirim request OPTIONS (preflight) sebelum request asli.

**Solusi:** Backend harus respond ke OPTIONS request — sudah ditangani otomatis oleh package `cors`.

---

## Catatan Penting

> ⚠️ **JANGAN** set `CORS_ORIGIN=*` di production!  
> Ini akan membuka API kamu ke **semua website di internet**.  
> Selalu gunakan domain spesifik.

> 💡 Di Vercel, frontend dan backend ada di domain yang sama,  
> jadi set `CORS_ORIGIN` = URL Vercel kamu (misal `https://demo-otpyuk.markect.dev`).

---

<div align="center">

*CORS itu bodyguard API kamu. Jangan matikan.* 🛡️

</div>
