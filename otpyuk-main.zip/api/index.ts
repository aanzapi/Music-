/**
 * Vercel Serverless Entry Point
 * Exposes the Express app as a serverless function.
 */

import { app } from '../src/app';

// Vercel Serverless Functions need to export the app instance.
export default app;
