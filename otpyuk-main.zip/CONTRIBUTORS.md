# 👥 Contributors

Terima kasih kepada semua orang yang telah berkontribusi pada proyek **otpyuk**!

---

## 🏗️ Core Team

### 🟡 RumahOTP
**Peran:** Provider API & Infrastruktur OTP  
Platform penyedia nomor virtual OTP yang menjadi backbone layanan otpyuk. Menyediakan akses ke 1.700+ layanan di 100+ negara melalui API v2 yang stabil dan cepat.

- 🌐 Website: [rumahotp.io](https://www.rumahotp.io)
- 📡 API Documentation: RumahOTP v2 API

---

### 🟢 frkhnsptra__
**Peran:** Lead Developer & System Architect  
Bertanggung jawab atas seluruh arsitektur sistem, pengembangan backend (Express + TypeScript + Prisma), frontend (Next.js), integrasi API provider, sistem autentikasi, dan deployment pipeline.

- 🐙 GitHub: [@frkhnsptra__](https://github.com/frkhnsptra__)

---

### 🔵 Radit
**Peran:** UI/UX Designer  
Merancang tampilan visual dan pengalaman pengguna platform otpyuk. Termasuk desain landing page, dashboard, sistem warna, dan komponen interaktif yang responsif di semua perangkat.

---

### 🟣 Neomi
**Peran:** Asset Creator & Illustrator  
Menyediakan semua aset visual termasuk maskot Otpyuk (si burung kuning), ilustrasi step-by-step, gambar hero, dan aset grafis lainnya yang digunakan di seluruh platform.

---

## 🤝 Cara Berkontribusi

Proyek ini bersifat **private/commercial**. Jika kamu adalah pembeli lisensi dan ingin melaporkan bug atau memberikan saran, hubungi kami melalui:

- 📧 Email: cuyaan08@gmail.com
- 💬 Telegram: [@otpyuk](https://t.me/otpyuk)

---

<div align="center">

*Setiap kontribusi, sekecil apapun, sangat berarti bagi kami.* 🐤

</div>
