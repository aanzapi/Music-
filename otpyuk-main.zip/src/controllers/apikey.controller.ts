/**
 * apikey.controller.ts — API Key Management Handlers
 */

import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { generateApiKey, hashApiKey, maskApiKey } from '../utils/crypto';
import { sendSuccess, sendError, AppError } from '../utils/response';

/** GET /api/v1/apikey — List user's API keys */
export async function listApiKeys(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const keys = await prisma.apiKey.findMany({
    where: { userId: req.user.id },
    select: {
      id: true, name: true, key: true, whitelist: true,
      canNumber: true, canDeposit: true, canH2h: true,
      isActive: true, lastUsed: true, createdAt: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  // Mask keys for display
  const masked = keys.map((k: { key: string; id: string; name: string; whitelist: string[]; canNumber: boolean; canDeposit: boolean; canH2h: boolean; isActive: boolean; lastUsed: Date | null; createdAt: Date }) => ({ ...k, key: maskApiKey(k.key) }));
  sendSuccess(res, masked, 'Daftar API key');
}

/** POST /api/v1/apikey/create — Create new API key */
export async function createApiKey(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const { name, whitelist, canNumber, canDeposit, canH2h } = req.body;

  // Generate plain key (shown once) and hash for storage
  const plainKey = generateApiKey();
  const hashedKey = hashApiKey(plainKey);

  const apiKey = await prisma.apiKey.create({
    data: {
      userId: req.user.id,
      name: name || 'My API Key',
      key: hashedKey,
      whitelist: whitelist || [],
      canNumber: canNumber || false,
      canDeposit: canDeposit || false,
      canH2h: canH2h || false,
    },
  });

  // Return plain key ONCE — it won't be shown again
  sendSuccess(res, {
    id: apiKey.id,
    name: apiKey.name,
    key: plainKey, // Only time plain key is shown
    whitelist: apiKey.whitelist,
    canNumber: apiKey.canNumber,
    canDeposit: apiKey.canDeposit,
    canH2h: apiKey.canH2h,
  }, 'API key berhasil dibuat. Simpan key ini, tidak akan ditampilkan lagi!', 201);
}

/** PATCH /api/v1/apikey/:id — Update API key */
export async function updateApiKey(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const key = await prisma.apiKey.findFirst({
    where: { id: req.params.id as string, userId: req.user.id },
  });
  if (!key) throw new AppError('API key tidak ditemukan', 404, 'APIKEY_NOT_FOUND');

  const updated = await prisma.apiKey.update({
    where: { id: key.id },
    data: {
      name: req.body.name ?? key.name,
      whitelist: req.body.whitelist ?? key.whitelist,
      canNumber: req.body.canNumber ?? key.canNumber,
      canDeposit: req.body.canDeposit ?? key.canDeposit,
      canH2h: req.body.canH2h ?? key.canH2h,
    },
  });
  sendSuccess(res, { ...updated, key: maskApiKey(updated.key) }, 'API key diperbarui');
}

/** DELETE /api/v1/apikey/:id — Delete API key */
export async function deleteApiKey(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const key = await prisma.apiKey.findFirst({
    where: { id: req.params.id as string, userId: req.user.id },
  });
  if (!key) throw new AppError('API key tidak ditemukan', 404, 'APIKEY_NOT_FOUND');
  await prisma.apiKey.delete({ where: { id: key.id } });
  sendSuccess(res, null, 'API key dihapus');
}

/** POST /api/v1/apikey/:id/toggle — Toggle API key active status */
export async function toggleApiKey(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const key = await prisma.apiKey.findFirst({
    where: { id: req.params.id as string, userId: req.user.id },
  });
  if (!key) throw new AppError('API key tidak ditemukan', 404, 'APIKEY_NOT_FOUND');
  const updated = await prisma.apiKey.update({
    where: { id: key.id },
    data: { isActive: !key.isActive },
  });
  sendSuccess(res, { isActive: updated.isActive }, `API key ${updated.isActive ? 'diaktifkan' : 'dinonaktifkan'}`);
}
