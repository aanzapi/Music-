/**
 * order.controller.ts — Order Request Handlers
 */

import { Request, Response } from 'express';
import * as orderService from '../services/order.service';
import * as provider from '../services/rumahotp.service';
import { env } from '../config/env';
import { sendSuccess, sendPaginated, sendError } from '../utils/response';

/** POST /api/v1/orders/create */
export async function createOrder(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.createOrder(req.user.id, req.body);
  sendSuccess(res, order, 'Pesanan berhasil dibuat', 201);
}

/** GET /api/v1/orders */
export async function getOrders(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const { orders, meta } = await orderService.getUserOrders(req.user.id, req.query as Record<string, string>);
  sendPaginated(res, orders, meta, 'Daftar pesanan');
}

/** GET /api/v1/orders/:orderId */
export async function getOrderDetail(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.checkOrderStatus(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Detail pesanan');
}

/** GET /api/v1/orders/:orderId/status */
export async function checkStatus(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.checkOrderStatus(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Status pesanan');
}

/** PATCH /api/v1/orders/:orderId/cancel */
export async function cancelOrder(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.cancelOrder(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Pesanan berhasil dibatalkan');
}

/** PATCH /api/v1/orders/:orderId/done */
export async function completeOrder(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.completeOrder(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Pesanan selesai');
}

/** PATCH /api/v1/orders/:orderId/resend */
export async function resendOrder(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.resendOrder(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Permintaan ulang kode berhasil dikirim');
}



/** POST /api/v1/orders/:orderId/buy-again */
export async function buyAgain(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const order = await orderService.buyAgain(req.params.orderId as string, req.user.id);
  sendSuccess(res, order, 'Pesanan ulang berhasil dibuat');
}

/** GET /api/v1/orders/services */
export async function getServices(_req: Request, res: Response): Promise<void> {
  const services = await provider.getServices();
  sendSuccess(res, services, 'Daftar layanan');
}

/** GET /api/v1/orders/countries */
export async function getCountries(req: Request, res: Response): Promise<void> {
  const serviceId = parseInt(req.query.service_id as string, 10);
  if (!serviceId) { sendError(res, 'service_id diperlukan', 400); return; }
  const countries = await provider.getCountries(serviceId);
  const marginOrder = env.MARGIN_ORDER;

  const markedUpCountries = countries.map(c => ({
    ...c,
    pricelist: c.pricelist.map(p => {
      const markedPrice = p.price + marginOrder;
      return {
        ...p,
        price: markedPrice,
        price_format: `Rp ${markedPrice.toLocaleString('id-ID')}`
      };
    })
  }));

  sendSuccess(res, markedUpCountries, 'Daftar negara');
}

/** GET /api/v1/orders/operators */
export async function getOperators(req: Request, res: Response): Promise<void> {
  const country = req.query.country as string;
  const providerId = parseInt(req.query.provider_id as string, 10);
  if (!country || !providerId) { sendError(res, 'country & provider_id diperlukan', 400); return; }
  const operators = await provider.getOperators(country, providerId);
  sendSuccess(res, operators, 'Daftar operator');
}
