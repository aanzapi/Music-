/**
 * deposit.controller.ts — Deposit Request Handlers
 */

import { Request, Response } from 'express';
import * as depositService from '../services/deposit.service';
import { sendSuccess, sendPaginated, sendError } from '../utils/response';

/** POST /api/v1/deposit/create */
export async function createDeposit(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const deposit = await depositService.createDeposit(req.user.id, req.body.amount, req.body.method);
  sendSuccess(res, deposit, 'Deposit berhasil dibuat', 201);
}

/** GET /api/v1/deposit */
export async function getDeposits(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const { deposits, meta } = await depositService.getUserDeposits(req.user.id, req.query as Record<string, string>);
  sendPaginated(res, deposits, meta, 'Riwayat deposit');
}

/** GET /api/v1/deposit/:depositId */
export async function getDepositDetail(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const deposit = await depositService.checkDepositStatus(req.params.depositId as string, req.user.id);
  sendSuccess(res, deposit, 'Detail deposit');
}

/** GET /api/v1/deposit/:depositId/status */
export async function checkDepositStatus(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const deposit = await depositService.checkDepositStatus(req.params.depositId as string, req.user.id);
  sendSuccess(res, deposit, 'Status deposit');
}

/** POST /api/v1/deposit/:depositId/cancel */
export async function cancelDeposit(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const deposit = await depositService.cancelDepositById(req.params.depositId as string, req.user.id);
  sendSuccess(res, deposit, 'Deposit dibatalkan');
}

/** POST /webhook/payment/callback */
export async function paymentCallback(req: Request, res: Response): Promise<void> {
  const { reference_id } = req.body;
  if (reference_id) {
    await depositService.handlePaymentCallback(String(reference_id));
  }
  sendSuccess(res, null, 'Callback processed');
}
