/**
 * user.controller.ts — User Profile Request Handlers
 */

import { Request, Response } from 'express';
import * as userService from '../services/user.service';
import { sendSuccess, sendPaginated, sendError } from '../utils/response';
import { verifyRecaptcha } from '../services/recaptcha.service';

/** GET /api/v1/user/profile */
export async function getProfile(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const profile = await userService.getProfile(req.user.id);
  sendSuccess(res, profile, 'Profil user');
}

/** PATCH /api/v1/user/profile */
export async function updateProfile(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const updated = await userService.updateProfile(req.user.id, req.body);
  sendSuccess(res, updated, 'Profil berhasil diperbarui');
}

/** POST /api/v1/user/avatar */
export async function uploadAvatar(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  if (!req.file) { sendError(res, 'File avatar diperlukan', 400); return; }
  const result = await userService.updateAvatar(req.user.id, `/uploads/avatars/${req.file.filename}`);
  sendSuccess(res, result, 'Avatar berhasil diupload');
}

/** GET /api/v1/user/balance */
export async function getBalance(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const balance = await userService.getBalance(req.user.id);
  sendSuccess(res, balance, 'Saldo user');
}

/** PATCH /api/v1/user/password */
export async function changePassword(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }

  const isHuman = await verifyRecaptcha(req.body.recaptchaToken);
  if (!isHuman) {
    sendError(res, 'reCAPTCHA verification failed', 403, 'RECAPTCHA_FAILED');
    return;
  }

  await userService.changePassword(req.user.id, req.body.currentPassword, req.body.newPassword);
  sendSuccess(res, null, 'Password berhasil diubah');
}

/** GET /api/v1/user/sessions */
export async function getSessions(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const sessions = await userService.getUserSessions(req.user.id);
  sendSuccess(res, sessions, 'Daftar session');
}

/** DELETE /api/v1/user/sessions/:id */
export async function deleteSession(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  await userService.deleteSession(req.params.id as string, req.user.id);
  sendSuccess(res, null, 'Session dihapus');
}

/** DELETE /api/v1/user/sessions */
export async function revokeAllSessions(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  await userService.revokeAllSessions(req.user.id);
  sendSuccess(res, null, 'Semua session dicabut');
}

/** GET /api/v1/activity */
export async function getActivities(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const { activities, meta } = await userService.getUserActivities(req.user.id, req.query as Record<string, string>);
  sendPaginated(res, activities, meta, 'Riwayat aktivitas');
}
