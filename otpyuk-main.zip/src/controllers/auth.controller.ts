/**
 * auth.controller.ts — Auth Request Handlers (Buyers Edition)
 * No WhatsApp linking, no OTP 2-step registration, no set-password.
 */

import { Request, Response } from 'express';
import * as authService from '../services/auth.service';
import { sendSuccess, sendError } from '../utils/response';
import { env } from '../config/env';
import { verifyRecaptcha } from '../services/recaptcha.service';

const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: env.NODE_ENV === 'production',
  sameSite: 'strict' as const,
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: '/',
  ...(env.NODE_ENV === 'production' && env.APP_URL
    ? { domain: new URL(env.APP_URL).hostname }
    : {}),
};

// ── Registration (Direct) ─────────────────────────

/** POST /api/v1/auth/register */
export async function register(req: Request, res: Response): Promise<void> {
  const isHuman = await verifyRecaptcha(req.body.recaptchaToken);
  if (!isHuman) { sendError(res, 'reCAPTCHA verification failed', 403, 'RECAPTCHA_FAILED'); return; }

  const { user, tokens } = await authService.registerRequest(req.body);
  res.cookie('refreshToken', tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  sendSuccess(res, { user, accessToken: tokens.accessToken }, 'Registrasi berhasil', 201);
}

// ── Login ─────────────────────────────────────────

/** POST /api/v1/auth/login */
export async function login(req: Request, res: Response): Promise<void> {
  const isHuman = await verifyRecaptcha(req.body.recaptchaToken);
  if (!isHuman) { sendError(res, 'reCAPTCHA verification failed', 403, 'RECAPTCHA_FAILED'); return; }

  const result = await authService.loginUser(req.body, req.ip, req.headers['user-agent']);

  if ('requires2fa' in result && result.requires2fa) {
    sendSuccess(res, { requires2fa: true, tempToken: result.tempToken, channel: result.channel }, '2FA verification required');
    return;
  }

  const { tokens, user } = result as { tokens: { accessToken: string; refreshToken: string }; user: unknown };
  res.cookie('refreshToken', tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  sendSuccess(res, { user, accessToken: tokens.accessToken }, 'Login berhasil');
}

/** POST /api/v1/auth/login/verify-2fa */
export async function loginVerify2fa(req: Request, res: Response): Promise<void> {
  const { token, code } = req.body;
  const result = await authService.verify2faLogin(token, code, req.ip, req.headers['user-agent']);

  res.cookie('refreshToken', result.tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  sendSuccess(res, { user: result.user, accessToken: result.tokens.accessToken }, 'Login berhasil');
}

// ── Logout & Refresh ──────────────────────────────

/** POST /api/v1/auth/logout */
export async function logout(req: Request, res: Response): Promise<void> {
  const refreshToken = req.cookies?.refreshToken;
  if (refreshToken) await authService.logoutUser(refreshToken);
  res.clearCookie('refreshToken', { ...REFRESH_COOKIE_OPTIONS, maxAge: undefined });
  sendSuccess(res, null, 'Logout berhasil');
}

/** POST /api/v1/auth/refresh */
export async function refresh(req: Request, res: Response): Promise<void> {
  const refreshToken = req.cookies?.refreshToken;
  if (!refreshToken) { sendError(res, 'Refresh token tidak ditemukan', 401, 'NO_REFRESH_TOKEN'); return; }

  try {
    const tokens = await authService.refreshAccessToken(refreshToken);
    res.cookie('refreshToken', tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
    sendSuccess(res, { accessToken: tokens.accessToken }, 'Token refreshed');
  } catch (err: any) {
    res.clearCookie('refreshToken', { ...REFRESH_COOKIE_OPTIONS, maxAge: undefined });
    sendError(res, err.message || 'Gagal refresh token', 401, 'INVALID_REFRESH_TOKEN');
  }
}

// ── Password Reset ────────────────────────────────

/** POST /api/v1/auth/forgot-password */
export async function forgotPassword(req: Request, res: Response): Promise<void> {
  try { await authService.createPasswordReset(req.body.email); } catch { /* silent */ }
  sendSuccess(res, null, 'Jika email terdaftar, link reset password akan dikirim');
}

/** POST /api/v1/auth/reset-password */
export async function resetPassword(req: Request, res: Response): Promise<void> {
  await authService.resetPassword(req.body.token, req.body.password);
  sendSuccess(res, null, 'Password berhasil direset');
}

// ── 2FA Management ────────────────────────────────

/** POST /api/v1/auth/2fa/enable */
export async function enable2fa(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const result = await authService.enable2faRequest(req.user.id);
  sendSuccess(res, result, 'Kode OTP telah dikirim ke email Anda');
}

/** POST /api/v1/auth/2fa/enable/confirm */
export async function enable2faConfirm(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  await authService.enable2faConfirm(req.user.id, req.body.token, req.body.code);
  sendSuccess(res, null, '2FA berhasil diaktifkan');
}

/** POST /api/v1/auth/2fa/disable */
export async function disable2fa(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const result = await authService.disable2faRequest(req.user.id);
  sendSuccess(res, result, 'Kode OTP telah dikirim ke email Anda');
}

/** POST /api/v1/auth/2fa/disable/confirm */
export async function disable2faConfirm(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  await authService.disable2faConfirm(req.user.id, req.body.token, req.body.code);
  sendSuccess(res, null, '2FA berhasil dinonaktifkan');
}

// ── OAuth Handlers ────────────────────────────────

/** GET /api/v1/auth/google */
export async function googleRedirect(_req: Request, res: Response): Promise<void> {
  const backendUrl = env.NODE_ENV === 'production' ? env.APP_URL : `http://localhost:${env.PORT}`;
  const redirectUri = `${backendUrl}/api/v1/auth/google/callback`;
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID || '', redirect_uri: redirectUri,
    response_type: 'code', scope: 'openid email profile', access_type: 'offline', prompt: 'consent',
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
}

/** GET /api/v1/auth/google/callback */
export async function googleCallback(req: Request, res: Response): Promise<void> {
  try {
    const code = req.query.code as string;
    if (!code) { res.redirect(`${env.APP_URL}/login?error=google_no_code`); return; }

    const backendUrl = env.NODE_ENV === 'production' ? env.APP_URL : `http://localhost:${env.PORT}`;
    const redirectUri = `${backendUrl}/api/v1/auth/google/callback`;
    const { tokens } = await authService.loginWithGoogle(code, redirectUri, req.ip, req.headers['user-agent']);

    res.cookie('refreshToken', tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
    res.redirect(`${env.APP_URL}/client/dashboard?token=${tokens.accessToken}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'OAuth error';
    res.redirect(`${env.APP_URL}/login?error=${encodeURIComponent(message)}`);
  }
}

/** GET /api/v1/auth/github */
export async function githubRedirect(_req: Request, res: Response): Promise<void> {
  const params = new URLSearchParams({ client_id: env.GITHUB_CLIENT_ID || '', scope: 'read:user user:email' });
  res.redirect(`https://github.com/login/oauth/authorize?${params.toString()}`);
}

/** GET /api/v1/auth/github/callback */
export async function githubCallback(req: Request, res: Response): Promise<void> {
  try {
    const code = req.query.code as string;
    if (!code) { res.redirect(`${env.APP_URL}/login?error=github_no_code`); return; }

    const { tokens } = await authService.loginWithGithub(code, req.ip, req.headers['user-agent']);
    res.cookie('refreshToken', tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
    res.redirect(`${env.APP_URL}/client/dashboard?token=${tokens.accessToken}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'OAuth error';
    res.redirect(`${env.APP_URL}/login?error=${encodeURIComponent(message)}`);
  }
}
