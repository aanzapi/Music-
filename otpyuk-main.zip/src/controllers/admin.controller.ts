/**
 * admin.controller.ts — Admin Panel Handlers
 */

import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { sendSuccess, sendPaginated, AppError } from '../utils/response';

/** GET /api/v1/admin/dashboard/stats */
export async function getDashboardStats(_req: Request, res: Response): Promise<void> {
  const [totalUsers, totalOrders, totalDeposits, totalRevenue] = await Promise.all([
    prisma.user.count(),
    prisma.order.count(),
    prisma.deposit.count({ where: { status: 'SUCCESS' } }),
    prisma.deposit.aggregate({ where: { status: 'SUCCESS' }, _sum: { received: true } }),
  ]);

  const activeOrders = await prisma.order.count({ where: { status: { in: ['WAITING', 'RECEIVED'] } } });
  const pendingDeposits = await prisma.deposit.count({ where: { status: 'PENDING' } });

  sendSuccess(res, {
    totalUsers,
    totalOrders,
    activeOrders,
    totalDeposits,
    pendingDeposits,
    totalRevenue: totalRevenue._sum.received || 0,
  }, 'Dashboard stats');
}

/** GET /api/v1/admin/users */
export async function getUsers(req: Request, res: Response): Promise<void> {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const skip = (page - 1) * limit;

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      select: {
        id: true, userId: true, username: true, email: true,
        firstName: true, lastName: true, balance: true, role: true,
        isActive: true, isVerified: true, createdAt: true,
        _count: { select: { orders: true, deposits: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.user.count(),
  ]);

  sendPaginated(res, users, { total, page, limit, totalPages: Math.ceil(total / limit) }, 'Daftar user');
}

/** GET /api/v1/admin/users/:id */
export async function getUserDetail(req: Request, res: Response): Promise<void> {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id as string },
    include: {
      _count: { select: { orders: true, deposits: true, apiKeys: true } },
    },
  });
  if (!user) throw new AppError('User tidak ditemukan', 404);

  // Remove password from response
  const { password: _, twoFaSecret: __, ...safeUser } = user;
  sendSuccess(res, safeUser, 'Detail user');
}

/** PATCH /api/v1/admin/users/:id/balance */
export async function adjustBalance(req: Request, res: Response): Promise<void> {
  const { amount, description } = req.body;
  const user = await prisma.user.findUnique({ where: { id: req.params.id as string } });
  if (!user) throw new AppError('User tidak ditemukan', 404);

  const numAmount = parseFloat(amount);
  const [updated] = await prisma.$transaction([
    prisma.user.update({
      where: { id: user.id },
      data: { balance: { increment: numAmount } },
      select: { balance: true },
    }),
    prisma.activity.create({
      data: {
        userId: user.id,
        type: numAmount > 0 ? 'BONUS' : 'DEDUCTION',
        description: description || `Admin balance adjustment: ${numAmount > 0 ? '+' : ''}${numAmount}`,
        amount: numAmount,
        balance: user.balance + numAmount,
      },
    }),
  ]);
  sendSuccess(res, updated, 'Saldo berhasil diubah');
}

/** PATCH /api/v1/admin/users/:id/status */
export async function toggleUserStatus(req: Request, res: Response): Promise<void> {
  const user = await prisma.user.findUnique({ where: { id: req.params.id as string } });
  if (!user) throw new AppError('User tidak ditemukan', 404);

  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { isActive: !user.isActive },
    select: { userId: true, isActive: true },
  });
  sendSuccess(res, updated, `User ${updated.isActive ? 'diaktifkan' : 'dinonaktifkan'}`);
}

/** 
 * PATCH /api/v1/admin/users/:id/role 
 * Update user role (USER, ADMIN, RESELLER)
 */
export async function updateUserRole(req: Request, res: Response): Promise<void> {
  const { role } = req.body;
  const { id } = req.params;

  // Validasi role yang diperbolehkan
  const allowedRoles = ['USER', 'ADMIN', 'RESELLER'];
  if (!role || !allowedRoles.includes(role)) {
    throw new AppError('Role tidak valid. Pilih: USER, ADMIN, atau RESELLER', 400);
  }

  // Cek user apakah ada
  const user = await prisma.user.findUnique({ 
    where: { id },
    select: { id: true, email: true, role: true }
  });
  
  if (!user) {
    throw new AppError('User tidak ditemukan', 404);
  }

  // Cegah admin mengubah role sendiri menjadi non-admin
  if (req.user?.id === id && role !== 'ADMIN') {
    throw new AppError('Anda tidak dapat mengubah role sendiri menjadi non-admin', 403);
  }

  // Update role
  const updated = await prisma.user.update({
    where: { id },
    data: { role: role as any },
    select: {
      id: true,
      email: true,
      userId: true,
      username: true,
      role: true,
      updatedAt: true
    }
  });

  // Catat aktivitas
  await prisma.activity.create({
    data: {
      userId: req.user?.id || '',
      type: 'BONUS',
      description: `Admin mengubah role user ${user.email} dari ${user.role} menjadi ${role}`,
      amount: 0,
      balance: 0,
    },
  });

  sendSuccess(res, updated, `Role user berhasil diubah menjadi ${role}`);
}

/** GET /api/v1/admin/orders */
export async function getAllOrders(req: Request, res: Response): Promise<void> {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const skip = (page - 1) * limit;

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      include: { user: { select: { userId: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.order.count(),
  ]);
  sendPaginated(res, orders, { total, page, limit, totalPages: Math.ceil(total / limit) }, 'Semua pesanan');
}

/** GET /api/v1/admin/deposits */
export async function getAllDeposits(req: Request, res: Response): Promise<void> {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const skip = (page - 1) * limit;

  const [deposits, total] = await Promise.all([
    prisma.deposit.findMany({
      include: { user: { select: { userId: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.deposit.count(),
  ]);
  sendPaginated(res, deposits, { total, page, limit, totalPages: Math.ceil(total / limit) }, 'Semua deposit');
      }
