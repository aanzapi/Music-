/**
 * webhook.controller.ts — Webhook Management Handlers
 */

import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { sendSuccess, sendError, AppError } from '../utils/response';
import { logger } from '../utils/logger';
import axios from 'axios';

/** GET /api/v1/webhook — List user's webhooks */
export async function listWebhooks(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const webhooks = await prisma.webhook.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
  });
  sendSuccess(res, webhooks, 'Daftar webhook');
}

/** POST /api/v1/webhook/create — Create webhook */
export async function createWebhook(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const { url, requestedId } = req.body;

  const webhook = await prisma.webhook.create({
    data: {
      userId: req.user.id,
      url,
      requestedId: requestedId || null,
    },
  });
  sendSuccess(res, webhook, 'Webhook berhasil dibuat', 201);
}

/** DELETE /api/v1/webhook/:id — Delete webhook */
export async function deleteWebhook(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const wh = await prisma.webhook.findFirst({
    where: { id: req.params.id as string, userId: req.user.id },
  });
  if (!wh) throw new AppError('Webhook tidak ditemukan', 404);
  await prisma.webhook.delete({ where: { id: wh.id } });
  sendSuccess(res, null, 'Webhook dihapus');
}

/** POST /api/v1/webhook/:id/test — Test webhook with sample payload */
export async function testWebhook(req: Request, res: Response): Promise<void> {
  if (!req.user) { sendError(res, 'Unauthorized', 401); return; }
  const wh = await prisma.webhook.findFirst({
    where: { id: req.params.id as string, userId: req.user.id },
  });
  if (!wh) throw new AppError('Webhook tidak ditemukan', 404);

  try {
    const testPayload = {
      event: 'test',
      data: { message: 'This is a test webhook from otpyuk', timestamp: new Date().toISOString() },
    };
    const response = await axios.post(wh.url, testPayload, {
      timeout: 5000,
      headers: { 'Content-Type': 'application/json', 'X-Requested-Id': wh.requestedId || '' },
    });
    sendSuccess(res, { status: response.status, statusText: response.statusText }, 'Webhook test berhasil');
  } catch (error) {
    logger.warn(`Webhook test failed for ${wh.url}`);
    sendError(res, 'Webhook test gagal. Pastikan URL dapat menerima POST request.', 400);
  }
}
