/**
 * service.controller.ts — Service Listing Handlers
 */

import { Request, Response } from 'express';
import { prisma } from '../config/database';
import * as provider from '../services/rumahotp.service';
import { sendSuccess } from '../utils/response';
import { logger } from '../utils/logger';

/** GET /api/v1/services — List services from local DB */
export async function getServices(_req: Request, res: Response): Promise<void> {
  const services = await prisma.service.findMany({
    where: { isActive: true },
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  });
  sendSuccess(res, services, 'Daftar layanan');
}

/** GET /api/v1/services/public — List services from RumahOTP v2 (no auth, for landing page) */
export async function getServicesPublic(_req: Request, res: Response): Promise<void> {
  try {
    const services = await provider.getServices();
    sendSuccess(res, services, 'Daftar layanan');
  } catch (err) {
    logger.error('Failed to fetch services from provider:', err);
    // Return empty array — frontend has its own static fallback
    sendSuccess(res, [], 'Layanan tidak tersedia sementara (provider offline)');
  }
}

/** GET /api/v1/services/trending — Get trending services */
export async function getTrending(_req: Request, res: Response): Promise<void> {
  const services = await prisma.service.findMany({
    where: { isActive: true, isTrending: true },
    orderBy: { sortOrder: 'asc' },
    take: 12,
  });
  sendSuccess(res, services, 'Layanan trending');
}

/** POST /api/v1/admin/services/sync — Sync from provider */
export async function syncServices(_req: Request, res: Response): Promise<void> {
  const providerServices = await provider.getServices();

  let created = 0;
  let updated = 0;

  for (const svc of providerServices) {
    const existing = await prisma.service.findUnique({
      where: { serviceCode: svc.service_code },
    });

    if (existing) {
      await prisma.service.update({
        where: { serviceCode: svc.service_code },
        data: { name: svc.service_name, img: svc.service_img },
      });
      updated++;
    } else {
      await prisma.service.create({
        data: {
          serviceCode: svc.service_code,
          name: svc.service_name,
          img: svc.service_img,
          category: 'other',
        },
      });
      created++;
    }
  }

  logger.info(`Services synced: ${created} created, ${updated} updated`);
  sendSuccess(res, { created, updated, total: providerServices.length }, 'Layanan berhasil disinkronkan');
}
