/**
 * cron.controller.ts — Vercel Cron Handlers
 */

import { Request, Response } from 'express';
import { prisma } from '../config/database';
import { logger } from '../utils/logger';
import { sendSuccess } from '../utils/response';
import { checkDepositStatus } from '../services/deposit.service';

export async function everyMinuteCron(_req: Request, res: Response): Promise<void> {
  logger.info('Cron [every-minute] starting...');

  // 1. Check Orders
  try {
    const expiredOrders = await prisma.order.findMany({
      where: {
        status: { in: ['WAITING', 'RECEIVED'] },
        expiredAt: { lte: new Date() },
        refunded: false,
      },
      include: { user: true },
    });

    for (const order of expiredOrders) {
      // Auto-refund expired orders
      await prisma.$transaction([
        prisma.order.update({
          where: { id: order.id },
          data: { status: 'CANCELED', refunded: true },
        }),
        prisma.user.update({
          where: { id: order.userId },
          data: { balance: { increment: order.price } },
        }),
        prisma.activity.create({
          data: {
            userId: order.userId,
            type: 'REFUND',
            description: `Auto-refund order ${order.orderId} (expired)`,
            amount: order.price,
            balance: order.user.balance + order.price,
          },
        }),
      ]);

      logger.info(`Auto-refunded expired order ${order.orderId}, amount: ${order.price}`);
    }
  } catch (error) {
    logger.error('Cron [check-orders] error:', error);
  }

  // 2. Check Deposits
  try {
    const pendingDeposits = await prisma.deposit.findMany({
      where: { status: 'PENDING' },
    });

    for (const deposit of pendingDeposits) {
      try {
        // Sync status with payment provider (auto-credits balance if paid)
        const updatedDeposit = await checkDepositStatus(deposit.depositId, deposit.userId);

        // If provider still says PENDING, but our 15-minute timer has expired, expire it locally
        if (updatedDeposit.status === 'PENDING' && new Date(updatedDeposit.expiredAt) <= new Date()) {
          await prisma.deposit.update({
            where: { id: updatedDeposit.id },
            data: { status: 'EXPIRED' },
          });
          logger.info(`Expired deposit locally (timeout): ${updatedDeposit.depositId}`);
        }
      } catch (checkErr) {
        logger.error(`Cron failed to check deposit ${deposit.depositId}:`, checkErr);
        // FORCE EXPIRE IF LOCALLY EXPIRED EVEN IF PROVIDER CHECK FAILS
        if (new Date(deposit.expiredAt) <= new Date()) {
          await prisma.deposit.update({
            where: { id: deposit.id },
            data: { status: 'EXPIRED' },
          });
          logger.info(`Force expired old deposit locally (provider check failed): ${deposit.depositId}`);
        }
      }
    }
  } catch (error) {
    logger.error('Cron [check-deposits] error:', error);
  }

  sendSuccess(res, null, 'Every minute cron executed');
}

export async function dailyCron(_req: Request, res: Response): Promise<void> {
  logger.info('Cron [daily] starting...');

  try {
    // Delete expired sessions
    const deletedSessions = await prisma.session.deleteMany({
      where: { expiresAt: { lte: new Date() } },
    });
    logger.info(`Cleanup: deleted ${deletedSessions.count} expired sessions`);

    // Delete activity logs older than 90 days
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    const deletedActivities = await prisma.activity.deleteMany({
      where: { createdAt: { lte: ninetyDaysAgo } },
    });
    logger.info(`Cleanup: deleted ${deletedActivities.count} old activities`);
  } catch (error) {
    logger.error('Cron [daily-cleanup] error:', error);
  }

  sendSuccess(res, null, 'Daily cron executed');
}
