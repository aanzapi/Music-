/**
 * logger.ts — Winston Logger Configuration
 * Centralized logging with console transport.
 * File transport only in development (Vercel serverless is read-only).
 */

import winston from 'winston';
import path from 'path';
import { env } from '../config/env';

const { combine, timestamp, printf, colorize, errors } = winston.format;

/** Custom log format for file output */
const fileFormat = printf(({ level, message, timestamp: ts, stack }) => {
  return `${ts} [${level.toUpperCase()}]: ${stack || message}`;
});

/** Custom log format for console output */
const consoleFormat = printf(({ level, message, timestamp: ts, stack }) => {
  return `${ts} ${level}: ${stack || message}`;
});

// Build transports array — always include console
const transports: winston.transport[] = [
  new winston.transports.Console({
    format: combine(colorize(), consoleFormat),
  }),
];

// Add file transports only in development (Vercel/serverless has read-only filesystem)
if (env.NODE_ENV === 'development') {
  const logsDir = path.join(process.cwd(), 'logs');
  transports.push(
    new winston.transports.File({
      filename: path.join(logsDir, 'error.log'),
      level: 'error',
      format: fileFormat,
      maxsize: 5 * 1024 * 1024,
      maxFiles: 5,
    }),
    new winston.transports.File({
      filename: path.join(logsDir, 'combined.log'),
      format: fileFormat,
      maxsize: 10 * 1024 * 1024,
      maxFiles: 5,
    })
  );
}

/**
 * Winston logger instance.
 * - Development: debug level, colored console + file output
 * - Production: info level, console only (Vercel-compatible)
 */
export const logger = winston.createLogger({
  level: env.NODE_ENV === 'development' ? 'debug' : 'info',
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    errors({ stack: true })
  ),
  defaultMeta: { service: 'otpyuk' },
  transports,
});

/** Morgan stream adapter for HTTP request logging */
export const morganStream = {
  write: (message: string) => {
    logger.info(message.trim());
  },
};
