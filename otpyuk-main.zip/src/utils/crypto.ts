/**
 * crypto.ts — Encryption & Hashing Helpers
 * Utility functions for password hashing, API key generation, and token creation.
 */

import bcrypt from 'bcryptjs';
import crypto from 'crypto';

const BCRYPT_ROUNDS = 12;

/**
 * Hash a password using bcrypt with 12 rounds.
 * @param password - Plain text password
 * @returns Hashed password string
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

/**
 * Compare a plain text password against a bcrypt hash.
 * @param password - Plain text password to verify
 * @param hash - Stored bcrypt hash
 * @returns true if password matches
 */
export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Generate a random API key in format: sfk-xxxx-xxxx-xxxx
 * @returns Generated API key string
 */
export function generateApiKey(): string {
  const segments = Array.from({ length: 3 }, () =>
    crypto.randomBytes(4).toString('hex').slice(0, 4)
  );
  return `sfk-${segments.join('-')}`;
}

/**
 * Hash an API key using SHA-256 for secure storage.
 * @param apiKey - Plain API key
 * @returns SHA-256 hash of the key
 */
export function hashApiKey(apiKey: string): string {
  return crypto.createHash('sha256').update(apiKey).digest('hex');
}

/**
 * Generate a random token (for email verification, password reset, etc.)
 * @param length - Byte length (default: 32, produces 64-char hex string)
 * @returns Random hex token
 */
export function generateToken(length = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

/**
 * Generate a sequential user ID in format: SFO0001731
 * @param sequence - Numeric sequence counter
 * @returns Formatted user ID
 */
export function generateUserId(sequence: number): string {
  return `SFO${String(sequence).padStart(7, '0')}`;
}

/**
 * Generate a sequential order ID in format: SFO0004647717
 * @param sequence - Numeric sequence counter
 * @returns Formatted order ID
 */
export function generateOrderId(sequence: number): string {
  return `SFO${String(sequence).padStart(10, '0')}`;
}

/**
 * Generate a deposit ID in format: SFO20260401072942
 * Based on current timestamp for uniqueness.
 * @returns Formatted deposit ID
 */
export function generateDepositId(): string {
  const now = new Date();
  const pad = (n: number, len = 2) => String(n).padStart(len, '0');
  const ts =
    `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}` +
    `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  const rand = crypto.randomBytes(2).toString('hex');
  return `SFO${ts}${rand}`;
}

/**
 * Mask an API key for display: sfk-dev-2q•••3aZ
 * @param key - Full API key
 * @returns Masked API key string
 */
export function maskApiKey(key: string): string {
  if (key.length <= 10) return '•••';
  return `${key.slice(0, 8)}•••${key.slice(-3)}`;
}

/**
 * Generate HMAC signature for webhook payloads.
 * @param payload - JSON string payload
 * @param secret - Webhook secret key
 * @returns HMAC-SHA256 hex signature
 */
export function generateHmacSignature(payload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}
