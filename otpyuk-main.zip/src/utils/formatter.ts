/**
 * formatter.ts — Formatting Utility Functions
 * Helper functions for formatting currency, dates, and display strings.
 */

/**
 * Format a number as Indonesian Rupiah currency.
 * @param amount - Numeric amount
 * @returns Formatted string, e.g. "Rp76.424"
 */
export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Format a date to Indonesian locale string.
 * @param date - Date object or ISO string
 * @returns Formatted date string, e.g. "20 April 2026, 13:45"
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Asia/Jakarta',
  }).format(d);
}

/**
 * Format a date to short format for table displays.
 * @param date - Date object or ISO string
 * @returns Formatted string, e.g. "20/04/2026 13:45"
 */
export function formatDateShort(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Asia/Jakarta',
  }).format(d);
}

/**
 * Calculate markup price from provider price.
 * @param providerPrice - Original price from RumahOTP
 * @param markupPercent - Markup percentage (e.g. 20 for 20%)
 * @returns Price after markup, rounded up to nearest integer
 */
export function calculateMarkupPrice(providerPrice: number, markupPercent: number): number {
  return Math.ceil(providerPrice * (1 + markupPercent / 100));
}

/**
 * Format a phone number for display with country flag hint.
 * @param phone - Phone number string
 * @returns Formatted phone number
 */
export function formatPhoneNumber(phone: string): string {
  // Remove any non-digit characters except +
  const cleaned = phone.replace(/[^\d+]/g, '');
  if (cleaned.startsWith('+62')) {
    return `+62 ${cleaned.slice(3, 6)} ${cleaned.slice(6, 10)} ${cleaned.slice(10)}`.trim();
  }
  return cleaned;
}

/**
 * Truncate a string with ellipsis.
 * @param str - Input string
 * @param maxLen - Maximum length before truncation
 * @returns Truncated string with "..." if exceeded
 */
export function truncate(str: string, maxLen: number): string {
  if (str.length <= maxLen) return str;
  return `${str.slice(0, maxLen - 3)}...`;
}
