/**
 * response.ts — Standardized API Response Helpers
 * All API responses use a consistent format:
 *   Success: { success: true, data: {...}, message: "..." }
 *   Error:   { success: false, error: { message: "...", code: "..." } }
 *   Paginated: { success: true, data: [...], meta: { total, page, limit, totalPages } }
 */

import { Response } from 'express';

/** Pagination metadata */
interface PaginationMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

/**
 * Send a success response.
 * @param res - Express Response object
 * @param data - Response payload
 * @param message - Optional success message
 * @param statusCode - HTTP status code (default: 200)
 */
export function sendSuccess<T>(
  res: Response,
  data: T,
  message = 'Success',
  statusCode = 200
): void {
  res.status(statusCode).json({
    success: true,
    data,
    message,
  });
}

/**
 * Send a paginated success response.
 * @param res - Express Response object
 * @param data - Array of items
 * @param meta - Pagination metadata
 * @param message - Optional success message
 */
export function sendPaginated<T>(
  res: Response,
  data: T[],
  meta: PaginationMeta,
  message = 'Success'
): void {
  res.status(200).json({
    success: true,
    data,
    meta,
    message,
  });
}

/**
 * Send an error response.
 * @param res - Express Response object
 * @param message - Error message
 * @param statusCode - HTTP status code (default: 400)
 * @param code - Machine-readable error code
 */
export function sendError(
  res: Response,
  message: string,
  statusCode = 400,
  code?: string
): void {
  res.status(statusCode).json({
    success: false,
    error: {
      message,
      code: code || `ERR_${statusCode}`,
    },
  });
}

/**
 * Custom application error class.
 * Extends Error with HTTP status code and error code.
 */
export class AppError extends Error {
  public statusCode: number;
  public code: string;
  public isOperational: boolean;

  constructor(message: string, statusCode = 400, code?: string) {
    super(message);
    this.statusCode = statusCode;
    this.code = code || `ERR_${statusCode}`;
    this.isOperational = true;
    Object.setPrototypeOf(this, AppError.prototype);
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Calculate pagination metadata from total count and query params.
 * @param total - Total number of records
 * @param page - Current page number (1-indexed)
 * @param limit - Items per page
 */
export function calculatePagination(total: number, page: number, limit: number): PaginationMeta {
  return {
    total,
    page,
    limit,
    totalPages: Math.ceil(total / limit),
  };
}
