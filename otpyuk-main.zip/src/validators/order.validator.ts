/**
 * order.validator.ts — Order Request Validation Schemas
 */

import { z } from 'zod';

export const createOrderSchema = z.object({
  numberId: z.number().int().positive('numberId harus bilangan positif'),
  providerId: z.number().int().positive('providerId harus bilangan positif'),
  operatorId: z.number().int().positive('operatorId harus bilangan positif'),
  serviceCode: z.number().int().positive(),
  serviceName: z.string().min(1, 'serviceName wajib diisi'),
  serviceImg: z.string().optional(),
  country: z.string().min(1, 'country wajib diisi'),
  providerPrice: z.number().positive('providerPrice harus positif'),
});

export const orderFilterSchema = z.object({
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
  status: z.enum(['WAITING', 'RECEIVED', 'COMPLETED', 'CANCELED', 'EXPIRING']).optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;
