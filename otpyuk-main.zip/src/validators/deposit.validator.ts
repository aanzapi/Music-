/**
 * deposit.validator.ts — Deposit Request Validation Schemas
 */

import { z } from 'zod';

export const createDepositSchema = z.object({
  amount: z.number().min(3000, 'Minimum deposit Rp3.000'),
  method: z.enum(['QRIS', 'USDT_BEP20', 'USDT_TRC20', 'USDT_POLYGON', 'USDT_ERC20'], {
    errorMap: () => ({ message: 'Metode pembayaran tidak valid' }),
  }),
});

export const depositFilterSchema = z.object({
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
  status: z.enum(['PENDING', 'SUCCESS', 'CANCEL', 'EXPIRED']).optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export type CreateDepositInput = z.infer<typeof createDepositSchema>;
