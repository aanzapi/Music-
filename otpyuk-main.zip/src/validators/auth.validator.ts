/**
 * auth.validator.ts — Auth Request Validation Schemas
 * Zod schemas for all authentication-related request payloads.
 */

import { z } from 'zod';

export const registerSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z
    .string()
    .min(8, 'Password minimal 8 karakter')
    .regex(/[A-Z]/, 'Password harus mengandung huruf besar')
    .regex(/[0-9]/, 'Password harus mengandung angka'),
  confirmPassword: z.string(),
  firstName: z.string().min(1, 'Nama depan wajib diisi').max(50),
  lastName: z.string().max(50).optional(),
  recaptchaToken: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Konfirmasi password tidak cocok',
  path: ['confirmPassword'],
});

export const loginSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(1, 'Password wajib diisi'),
  recaptchaToken: z.string().optional(),
});

export const googleAuthSchema = z.object({
  idToken: z.string().min(1, 'Google ID token required'),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email('Email tidak valid'),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, 'Token required'),
  password: z
    .string()
    .min(8, 'Password minimal 8 karakter')
    .regex(/[A-Z]/, 'Password harus mengandung huruf besar')
    .regex(/[0-9]/, 'Password harus mengandung angka'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Konfirmasi password tidak cocok',
  path: ['confirmPassword'],
});

export const verifyEmailSchema = z.object({
  token: z.string().min(1, 'Token required'),
});

export const enable2faSchema = z.object({
  password: z.string().min(1, 'Password wajib diisi untuk mengaktifkan 2FA'),
  recaptchaToken: z.string().optional(),
});

export const verify2faSchema = z.object({
  code: z.string().length(6, 'Kode 2FA harus 6 digit'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Password saat ini wajib diisi'),
  newPassword: z
    .string()
    .min(8, 'Password minimal 8 karakter')
    .regex(/[A-Z]/, 'Password harus mengandung huruf besar')
    .regex(/[0-9]/, 'Password harus mengandung angka'),
  confirmPassword: z.string(),
  recaptchaToken: z.string().optional(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: 'Konfirmasi password tidak cocok',
  path: ['confirmPassword'],
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type GoogleAuthInput = z.infer<typeof googleAuthSchema>;
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;
export type Enable2faInput = z.infer<typeof enable2faSchema>;
export type Verify2faInput = z.infer<typeof verify2faSchema>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

// Alias for routes compatibility
export const verifyOtpSchema = verify2faSchema;
