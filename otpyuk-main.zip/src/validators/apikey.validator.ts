/**
 * apikey.validator.ts — API Key Request Validation Schemas
 */

import { z } from 'zod';

export const createApiKeySchema = z.object({
  name: z.string().min(1, 'Nama API key wajib diisi').max(50),
  whitelist: z.array(z.string().ip({ message: 'Format IP tidak valid' })).optional(),
  canNumber: z.boolean().optional(),
  canDeposit: z.boolean().optional(),
  canH2h: z.boolean().optional(),
});

export const updateApiKeySchema = z.object({
  name: z.string().min(1).max(50).optional(),
  whitelist: z.array(z.string()).optional(),
  canNumber: z.boolean().optional(),
  canDeposit: z.boolean().optional(),
  canH2h: z.boolean().optional(),
});

export const createWebhookSchema = z.object({
  url: z.string().url('URL webhook tidak valid'),
  requestedId: z.string().optional(),
});

export type CreateApiKeyInput = z.infer<typeof createApiKeySchema>;
export type CreateWebhookInput = z.infer<typeof createWebhookSchema>;
