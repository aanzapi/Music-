/**
 * recaptcha.service.ts — Google reCAPTCHA v3 Verification
 * Verifies reCAPTCHA tokens server-side against Google's API.
 */

import { env } from '../config/env';
import { logger } from '../utils/logger';

interface RecaptchaResponse {
  success: boolean;
  score: number;
  action: string;
  challenge_ts: string;
  hostname: string;
  'error-codes'?: string[];
}

/**
 * Verify a reCAPTCHA v3 token with Google's API.
 * Returns true if verification passes (score >= 0.3).
 * Returns true if no secret key is configured (graceful skip).
 */
export async function verifyRecaptcha(token?: string): Promise<boolean> {
  // If reCAPTCHA is not configured, skip verification
  if (!env.RECAPTCHA_SECRET_KEY) {
    return true;
  }

  // If no token provided but reCAPTCHA is configured, fail
  if (!token) {
    logger.warn('[RECAPTCHA] No token provided');
    return false;
  }

  try {
    const res = await fetch('https://www.google.com/recaptcha/api/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `secret=${env.RECAPTCHA_SECRET_KEY}&response=${token}`,
    });

    const data = await res.json() as RecaptchaResponse;

    if (!data.success) {
      logger.warn(`[RECAPTCHA] Verification failed: ${JSON.stringify(data['error-codes'])}`);
      return false;
    }

    // reCAPTCHA v3 returns a score from 0.0 to 1.0
    // 0.0 = very likely a bot, 1.0 = very likely a human
    if (data.score < 0.3) {
      logger.warn(`[RECAPTCHA] Low score: ${data.score} for action: ${data.action}`);
      return false;
    }

    return true;
  } catch (error) {
    logger.error('[RECAPTCHA] Verification error:', error);
    // Fail open: if Google's API is down, let the request through
    return true;
  }
}
