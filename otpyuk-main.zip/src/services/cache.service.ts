/**
 * cache.service.ts
 * Redis caching helper menggunakan Upstash Redis
 * Semua method async, kompatibel dengan Upstash REST API
 */

import { getRedisClient } from '../config/redis';

const DEFAULT_TTL = 300; // 5 menit dalam detik

export class CacheService {
  private get redis() {
    return getRedisClient();
  }

  /**
   * Ambil data dari cache
   * @returns Data parsed atau null jika tidak ada / expired
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      const data = await this.redis.get<T>(key);
      return data;
    } catch (error) {
      console.error(`[Cache] GET error for key "${key}":`, error);
      return null;
    }
  }

  /**
   * Simpan data ke cache dengan TTL
   * @param ttl Time-to-live dalam detik (default: 5 menit)
   */
  async set(key: string, value: unknown, ttl: number = DEFAULT_TTL): Promise<void> {
    try {
      await this.redis.set(key, JSON.stringify(value), { ex: ttl });
    } catch (error) {
      console.error(`[Cache] SET error for key "${key}":`, error);
    }
  }

  /**
   * Hapus satu atau lebih key dari cache
   */
  async del(...keys: string[]): Promise<void> {
    try {
      if (keys.length > 0) {
        await this.redis.del(...keys);
      }
    } catch (error) {
      console.error(`[Cache] DEL error:`, error);
    }
  }

  /**
   * Cek apakah key ada di cache
   */
  async exists(key: string): Promise<boolean> {
    try {
      const result = await this.redis.exists(key);
      return result === 1;
    } catch (error) {
      console.error(`[Cache] EXISTS error for key "${key}":`, error);
      return false;
    }
  }

  /**
   * Cache dengan pattern: ambil dari cache dulu, jika tidak ada
   * jalankan fetcher, simpan hasilnya, return data
   */
  async getOrSet<T>(
    key: string,
    fetcher: () => Promise<T>,
    ttl: number = DEFAULT_TTL
  ): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) return cached;

    const fresh = await fetcher();
    await this.set(key, fresh, ttl);
    return fresh;
  }

  /**
   * Set TTL baru untuk key yang ada
   */
  async expire(key: string, ttl: number): Promise<void> {
    try {
      await this.redis.expire(key, ttl);
    } catch (error) {
      console.error(`[Cache] EXPIRE error for key "${key}":`, error);
    }
  }

  /**
   * Tambah nilai numerik (untuk counter, rate limit, dll)
   */
  async incr(key: string): Promise<number> {
    try {
      return await this.redis.incr(key);
    } catch (error) {
      console.error(`[Cache] INCR error for key "${key}":`, error);
      return 0;
    }
  }

  /**
   * Flush semua cache dengan prefix tertentu
   * Gunakan dengan hati-hati di production
   */
  async flushByPattern(pattern: string): Promise<void> {
    try {
      let cursor = 0;
      do {
        const [newCursor, keys] = await this.redis.scan(cursor, {
          match: pattern,
          count: 100,
        });
        cursor = Number(newCursor);
        if (keys.length > 0) {
          await this.redis.del(...(keys as string[]));
        }
      } while (cursor !== 0);
    } catch (error) {
      console.error(`[Cache] FLUSH PATTERN error:`, error);
    }
  }
}

// Cache key constants
export const CACHE_KEYS = {
  SERVICES_LIST: 'services:list',
  COUNTRIES: (serviceId: number) => `countries:${serviceId}`,
  OPERATORS: (country: string, providerId: number) => `operators:${country}:${providerId}`,
  USER_BALANCE: (userId: string) => `balance:${userId}`,
  SERVER_STATUS: 'server:status',
  TRENDING_SERVICES: 'services:trending',
} as const;

// Cache TTL constants dalam detik
export const CACHE_TTL = {
  SERVICES: 300,      // 5 menit
  COUNTRIES: 120,     // 2 menit
  OPERATORS: 120,     // 2 menit
  USER_BALANCE: 30,   // 30 detik
  SERVER_STATUS: 10,  // 10 detik
  TRENDING: 60,       // 1 menit
} as const;

export const cacheService = new CacheService();
