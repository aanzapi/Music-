/**
 * auth.service.ts — Authentication Business Logic (Buyers Edition)
 * Handles registration (direct), login, JWT, OAuth, simple 2FA, password reset.
 * No WhatsApp/Fonnte/OTP service — buyers version is email-only.
 */

import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/database';
import { env } from '../config/env';
import { hashPassword, comparePassword, generateToken, generateUserId } from '../utils/crypto';
import { AppError } from '../utils/response';
import { logger } from '../utils/logger';
import * as emailService from './email.service';
import type { RegisterInput, LoginInput } from '../validators/auth.validator';

interface TokenPair { accessToken: string; refreshToken: string; }

function generateTokenPair(userId: string, role: string): TokenPair {
  const accessToken = jwt.sign({ userId, role }, env.JWT_ACCESS_SECRET, { expiresIn: env.JWT_ACCESS_EXPIRE } as jwt.SignOptions);
  const refreshToken = jwt.sign({ userId, role, type: 'refresh' }, env.JWT_REFRESH_SECRET, { expiresIn: env.JWT_REFRESH_EXPIRE } as jwt.SignOptions);
  return { accessToken, refreshToken };
}

// ── Registration (Direct) ─────────────────────────

export async function registerRequest(input: RegisterInput) {
  const existing = await prisma.user.findUnique({ where: { email: input.email } });
  if (existing) {
    throw new AppError('Email sudah terdaftar', 409, 'EMAIL_EXISTS');
  }

  const hashedPassword = await hashPassword(input.password);
  const userCount = await prisma.user.count();
  const userId = generateUserId(userCount + 1);

  const user = await prisma.user.create({
    data: {
      userId,
      email: input.email,
      password: hashedPassword,
      firstName: input.firstName,
      lastName: input.lastName || null,
      avatar: '/images/otpyuk-mascot-happy.webp',
      isVerified: true,
    },
    select: { id: true, userId: true, email: true, firstName: true, lastName: true, role: true, balance: true, isVerified: true, avatar: true, createdAt: true },
  });

  const tokens = generateTokenPair(user.id, user.role);
  await prisma.session.create({ data: { userId: user.id, token: tokens.refreshToken, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });
  await prisma.activity.create({ data: { userId: user.id, type: 'BONUS', description: 'Akun baru dibuat', amount: 0, balance: 0 } });

  emailService.sendWelcomeEmail(user.email, user.firstName || 'User').catch(() => {});
  logger.info(`New user registered: ${user.userId} (${user.email})`);

  return { user, tokens };
}

// ── Login ─────────────────────────────────────────

const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_LOCKOUT_SECONDS = 15 * 60;

export async function loginUser(input: LoginInput, ip?: string, userAgent?: string) {
  const { redis } = await import('../config/redis');
  const lockoutKey = `login_lockout:${input.email}`;
  const failedKey = `login_failed:${input.email}`;

  const isLocked = await redis.get(lockoutKey);
  if (isLocked) {
    throw new AppError('Akun terkunci sementara karena terlalu banyak percobaan gagal. Coba lagi dalam 15 menit.', 429, 'ACCOUNT_LOCKED');
  }

  const user = await prisma.user.findUnique({
    where: { email: input.email },
    select: {
      id: true, userId: true, email: true, password: true, firstName: true, lastName: true,
      role: true, balance: true, isActive: true, isVerified: true, twoFaEnabled: true,
      twoFaSecret: true, avatar: true,
    },
  });

  if (!user || !user.password) throw new AppError('Email atau password salah', 401, 'INVALID_CREDENTIALS');
  if (!user.isActive) throw new AppError('Akun telah dinonaktifkan', 403, 'ACCOUNT_SUSPENDED');

  const isValid = await comparePassword(input.password, user.password);
  if (!isValid) {
    const attempts = ((await redis.get<number>(failedKey)) || 0) + 1;
    await redis.set(failedKey, attempts, { ex: LOGIN_LOCKOUT_SECONDS });

    if (attempts >= MAX_LOGIN_ATTEMPTS) {
      await redis.set(lockoutKey, '1', { ex: LOGIN_LOCKOUT_SECONDS });
      await redis.del(failedKey);
      logger.warn(`[AUTH] Account locked: ${input.email} (IP: ${ip})`);
      throw new AppError('Akun terkunci sementara karena terlalu banyak percobaan gagal.', 429, 'ACCOUNT_LOCKED');
    }

    throw new AppError('Email atau password salah', 401, 'INVALID_CREDENTIALS');
  }

  await redis.del(failedKey);
  await redis.del(lockoutKey);

  // Simple 2FA check — if enabled, require code via email
  if (user.twoFaEnabled) {
    const code = String(crypto.randomInt(100000, 999999));
    const tempToken = crypto.randomBytes(32).toString('hex');

    // Store 2FA temp data in Redis (5 min TTL)
    await redis.set(`2fa:${tempToken}`, JSON.stringify({ userId: user.id, code }), { ex: 300 });

    // Send code via email
    emailService.sendOtpEmail(user.email, code, 'login_2fa').catch(() => {});

    return { requires2fa: true, tempToken, channel: 'email' as const };
  }

  const tokens = generateTokenPair(user.id, user.role);
  await prisma.session.create({ data: { userId: user.id, token: tokens.refreshToken, ip: ip || null, userAgent: userAgent || null, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });

  emailService.sendLoginAlertEmail(user.email, { ip, userAgent, time: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }), firstName: user.firstName || undefined }).catch(() => {});

  const { password: _, twoFaSecret: _s, ...safeUser } = user;
  logger.info(`User logged in: ${user.userId}`);
  return { user: safeUser, tokens };
}

// ── Verify 2FA ────────────────────────────────────

export async function verify2faLogin(token: string, code: string, ip?: string, userAgent?: string) {
  const { redis } = await import('../config/redis');
  const raw = await redis.get<string>(`2fa:${token}`);
  if (!raw) throw new AppError('Token 2FA tidak valid atau expired', 400, 'INVALID_2FA_TOKEN');

  const data = JSON.parse(raw) as { userId: string; code: string };
  if (data.code !== code) throw new AppError('Kode 2FA salah', 400, 'WRONG_2FA_CODE');

  await redis.del(`2fa:${token}`);

  const user = await prisma.user.findUnique({
    where: { id: data.userId },
    select: { id: true, userId: true, email: true, firstName: true, lastName: true, role: true, balance: true, isActive: true, isVerified: true, twoFaEnabled: true, avatar: true },
  });
  if (!user) throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');

  const tokens = generateTokenPair(user.id, user.role);
  await prisma.session.create({ data: { userId: user.id, token: tokens.refreshToken, ip: ip || null, userAgent: userAgent || null, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });

  logger.info(`User logged in (2FA): ${user.userId}`);
  return { user, tokens };
}

// ── Token Management ──────────────────────────────

export async function refreshAccessToken(refreshToken: string) {
  try {
    const decoded = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as { userId: string; role: string; type: string };
    if (decoded.type !== 'refresh') throw new AppError('Invalid token type', 401, 'INVALID_TOKEN_TYPE');

    const session = await prisma.session.findUnique({ where: { token: refreshToken } });
    if (!session) throw new AppError('Session tidak valid', 401, 'SESSION_INVALID');

    const user = await prisma.user.findUnique({ where: { id: decoded.userId }, select: { id: true, role: true, isActive: true } });
    if (!user || !user.isActive) throw new AppError('Akun tidak aktif', 403, 'ACCOUNT_INACTIVE');

    const tokens = generateTokenPair(user.id, user.role);
    await prisma.session.delete({ where: { id: session.id } });
    await prisma.session.create({ data: { userId: user.id, token: tokens.refreshToken, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });

    return tokens;
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError('Token refresh gagal', 401, 'REFRESH_FAILED');
  }
}

export async function logoutUser(refreshToken: string): Promise<void> {
  await prisma.session.deleteMany({ where: { token: refreshToken } });
}

// ── 2FA Enable/Disable (Simple Email OTP) ─────────

export async function enable2faRequest(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { email: true, twoFaEnabled: true } });
  if (!user) throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');
  if (user.twoFaEnabled) throw new AppError('2FA sudah aktif', 400, '2FA_ALREADY_ENABLED');

  const { redis } = await import('../config/redis');
  const code = String(crypto.randomInt(1000, 9999));
  const token = crypto.randomBytes(32).toString('hex');
  await redis.set(`2fa_enable:${token}`, JSON.stringify({ userId, code }), { ex: 300 });

  emailService.sendOtpEmail(user.email, code, 'enable_2fa').catch(() => {});
  return { token };
}

export async function enable2faConfirm(userId: string, token: string, code: string) {
  const { redis } = await import('../config/redis');
  const raw = await redis.get<string>(`2fa_enable:${token}`);
  if (!raw) throw new AppError('Token tidak valid', 400, 'INVALID_TOKEN');

  const data = JSON.parse(raw) as { userId: string; code: string };
  if (data.userId !== userId || data.code !== code) throw new AppError('Kode salah', 400, 'WRONG_CODE');

  await redis.del(`2fa_enable:${token}`);
  await prisma.user.update({ where: { id: userId }, data: { twoFaEnabled: true } });
  emailService.send2faStatusEmail((await prisma.user.findUnique({ where: { id: userId }, select: { email: true } }))!.email, true).catch(() => {});
}

export async function disable2faRequest(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { email: true, twoFaEnabled: true } });
  if (!user) throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');
  if (!user.twoFaEnabled) throw new AppError('2FA belum aktif', 400, '2FA_NOT_ENABLED');

  const { redis } = await import('../config/redis');
  const code = String(crypto.randomInt(1000, 9999));
  const token = crypto.randomBytes(32).toString('hex');
  await redis.set(`2fa_disable:${token}`, JSON.stringify({ userId, code }), { ex: 300 });

  emailService.sendOtpEmail(user.email, code, 'disable_2fa').catch(() => {});
  return { token };
}

export async function disable2faConfirm(userId: string, token: string, code: string) {
  const { redis } = await import('../config/redis');
  const raw = await redis.get<string>(`2fa_disable:${token}`);
  if (!raw) throw new AppError('Token tidak valid', 400, 'INVALID_TOKEN');

  const data = JSON.parse(raw) as { userId: string; code: string };
  if (data.userId !== userId || data.code !== code) throw new AppError('Kode salah', 400, 'WRONG_CODE');

  await redis.del(`2fa_disable:${token}`);
  await prisma.user.update({ where: { id: userId }, data: { twoFaEnabled: false, twoFaSecret: null } });
  emailService.send2faStatusEmail((await prisma.user.findUnique({ where: { id: userId }, select: { email: true } }))!.email, false).catch(() => {});
}

// ── Password Reset ────────────────────────────────

export async function createPasswordReset(email: string): Promise<string> {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new AppError('Jika email terdaftar, link reset akan dikirim', 200, 'RESET_SENT');

  const resetToken = generateToken();
  await prisma.session.create({ data: { userId: user.id, token: `reset_${resetToken}`, expiresAt: new Date(Date.now() + 60 * 60 * 1000) } });
  emailService.sendPasswordResetEmail(email, resetToken).catch(() => {});

  return resetToken;
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  const session = await prisma.session.findUnique({ where: { token: `reset_${token}` } });
  if (!session || session.expiresAt < new Date()) throw new AppError('Token reset tidak valid atau sudah expired', 400, 'INVALID_RESET_TOKEN');

  const hashedPassword = await hashPassword(newPassword);
  const user = await prisma.user.findUnique({ where: { id: session.userId }, select: { email: true } });

  await prisma.$transaction([
    prisma.user.update({ where: { id: session.userId }, data: { password: hashedPassword } }),
    prisma.session.delete({ where: { id: session.id } }),
  ]);

  if (user) emailService.sendPasswordChangedEmail(user.email).catch(() => {});
}

// ── OAuth ─────────────────────────────────────────

async function oauthLoginOrRegister(
  profile: { email: string; firstName: string; lastName?: string; avatar?: string; googleId?: string; githubId?: string },
  ip?: string, userAgent?: string
) {
  let user = profile.googleId
    ? await prisma.user.findUnique({ where: { googleId: profile.googleId } })
    : profile.githubId ? await prisma.user.findUnique({ where: { githubId: profile.githubId } }) : null;

  if (!user) {
    user = await prisma.user.findUnique({ where: { email: profile.email } });
    if (user) {
      const linkData: Record<string, string> = {};
      if (profile.googleId) linkData.googleId = profile.googleId;
      if (profile.githubId) linkData.githubId = profile.githubId;
      if (profile.avatar) linkData.avatar = profile.avatar;
      user = await prisma.user.update({ where: { id: user.id }, data: linkData });
    }
  }

  let isNewUser = false;
  if (!user) {
    isNewUser = true;
    const userCount = await prisma.user.count();
    const userId = generateUserId(userCount + 1);
    user = await prisma.user.create({
      data: {
        userId, email: profile.email, firstName: profile.firstName,
        lastName: profile.lastName || null, avatar: profile.avatar || null,
        googleId: profile.googleId || null, githubId: profile.githubId || null, isVerified: true,
      },
    });
    await prisma.activity.create({ data: { userId: user.id, type: 'BONUS', description: `Akun baru via ${profile.googleId ? 'Google' : 'GitHub'}`, amount: 0, balance: 0 } });
    logger.info(`New OAuth user: ${user.userId} (${user.email})`);
  }

  if (profile.avatar && user.avatar !== profile.avatar) {
    user = await prisma.user.update({ where: { id: user.id }, data: { avatar: profile.avatar } });
  }
  if (!user.isActive) throw new AppError('Akun telah dinonaktifkan', 403, 'ACCOUNT_SUSPENDED');

  const tokens = generateTokenPair(user.id, user.role);
  await prisma.session.create({ data: { userId: user.id, token: tokens.refreshToken, ip: ip || null, userAgent: userAgent || null, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });

  if (isNewUser) {
    emailService.sendWelcomeEmail(user.email, user.firstName || 'User').catch(() => {});
  }

  logger.info(`OAuth login: ${user.userId}`);
  return { user, tokens };
}

export async function loginWithGoogle(code: string, redirectUri: string, ip?: string, userAgent?: string) {
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code, client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET, redirect_uri: redirectUri, grant_type: 'authorization_code' }),
  });
  const tokenData = await tokenRes.json() as { access_token?: string };
  if (!tokenRes.ok || !tokenData.access_token) throw new AppError('Google login gagal', 400, 'GOOGLE_TOKEN_ERROR');

  const userRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', { headers: { Authorization: `Bearer ${tokenData.access_token}` } });
  const g = await userRes.json() as { id: string; email: string; given_name?: string; name?: string; family_name?: string; picture?: string };
  if (!userRes.ok || !g.email) throw new AppError('Google login gagal', 400, 'GOOGLE_USER_ERROR');

  return oauthLoginOrRegister({ email: g.email, firstName: g.given_name || g.name || 'User', lastName: g.family_name, avatar: g.picture, googleId: String(g.id) }, ip, userAgent);
}

export async function loginWithGithub(code: string, ip?: string, userAgent?: string) {
  const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ client_id: env.GITHUB_CLIENT_ID, client_secret: env.GITHUB_CLIENT_SECRET, code }),
  });
  const tokenData = await tokenRes.json() as { access_token?: string };
  if (!tokenRes.ok || !tokenData.access_token) throw new AppError('GitHub login gagal', 400, 'GITHUB_TOKEN_ERROR');

  const userRes = await fetch('https://api.github.com/user', { headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: 'application/vnd.github+json' } });
  const gh = await userRes.json() as { id: number; email?: string; name?: string; login?: string; avatar_url?: string };
  if (!userRes.ok || !gh.id) throw new AppError('GitHub login gagal', 400, 'GITHUB_USER_ERROR');

  let email = gh.email;
  if (!email) {
    const emailsRes = await fetch('https://api.github.com/user/emails', { headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: 'application/vnd.github+json' } });
    const emails = await emailsRes.json() as Array<{ primary: boolean; verified: boolean; email: string }>;
    email = emails.find(e => e.primary && e.verified)?.email || emails[0]?.email;
  }
  if (!email) throw new AppError('GitHub login gagal: email tidak ditemukan', 400, 'GITHUB_NO_EMAIL');

  return oauthLoginOrRegister({ email, firstName: gh.name || gh.login || 'User', avatar: gh.avatar_url, githubId: String(gh.id) }, ip, userAgent);
}
