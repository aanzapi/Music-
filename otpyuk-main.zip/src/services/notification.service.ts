/**
 * notification.service.ts — Buyers Notification (Email Only)
 * No WhatsApp/Fonnte. Simple email notifications via email.service.
 */

import { prisma } from '../config/database';
import { logger } from '../utils/logger';
import * as emailService from './email.service';

export async function notifyDeposit(
  userId: string,
  event: 'created' | 'success',
  deposit: { depositId: string; amount: number; fee: number; received: number; method: string; brandName?: string }
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { email: true, firstName: true, userId: true },
    });
    if (!user) return;

    if (event === 'success') {
      emailService.sendDepositSuccessEmail(user.email, deposit).catch(() => {});
    }
  } catch (error) {
    logger.error(`[NOTIF] Failed deposit notification for ${userId}:`, error);
  }
}

export async function notifyOrder(
  userId: string,
  event: 'placed' | 'received' | 'cancelled',
  order: { orderId: string; serviceName: string; phoneNumber: string; country: string; price: number; otpCode?: string }
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { email: true, userId: true },
    });
    if (!user) return;

    const status = event === 'placed' ? 'WAITING' : event === 'received' ? 'RECEIVED' : 'CANCELED';

    if (event === 'received' || event === 'cancelled') {
      emailService.sendOrderEmail(user.email, { ...order, status, otpCode: order.otpCode }).catch(() => {});
    }
  } catch (error) {
    logger.error(`[NOTIF] Failed order notification for ${userId}:`, error);
  }
}

export async function notifyLoginAlert(
  email: string,
  details: { ip?: string; userAgent?: string; firstName?: string }
): Promise<void> {
  try {
    const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    emailService.sendLoginAlertEmail(email, { ...details, time }).catch(() => {});
  } catch (error) {
    logger.error(`[NOTIF] Failed login alert for ${email}:`, error);
  }
}
