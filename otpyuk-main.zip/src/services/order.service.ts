/**
 * order.service.ts — Order Business Logic
 * Handles OTP number ordering, status polling, cancellation, and refunds.
 */

import { prisma } from '../config/database';
import * as provider from './rumahotp.service';
import { AppError } from '../utils/response';
import { generateOrderId } from '../utils/crypto';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import * as notificationService from './notification.service';

/**
 * Create a new OTP number order.
 * Deducts user balance, calls provider API, creates order record.
 * Auto-refunds on provider failure.
 * @param userId - User's database ID
 * @param params - Order parameters (numberId, providerId, operatorId, serviceCode, serviceName, country, price)
 */
export async function createOrder(
  userId: string,
  params: {
    numberId: number;
    providerId: number;
    operatorId: number;
    serviceCode: number;
    serviceName: string;
    serviceImg?: string;
    country: string;
    providerPrice: number;
  }
) {
  // Price is now passed fully calculated from the frontend (including margin)
  const price = params.providerPrice;

  // Check user balance
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, balance: true },
  });

  if (!user) {
    throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');
  }

  if (user.balance < price) {
    throw new AppError(
      `Saldo tidak cukup. Dibutuhkan Rp${price.toLocaleString('id-ID')}, saldo Rp${user.balance.toLocaleString('id-ID')}`,
      400,
      'INSUFFICIENT_BALANCE'
    );
  }

  // Generate local order ID fallback (though we'll use provider's order_id if possible)
  const orderCount = await prisma.order.count();
  let orderId = generateOrderId(orderCount + 1);

  // Deduct balance first
  await prisma.user.update({
    where: { id: userId },
    data: { balance: { decrement: price } },
  });

  try {
    // Call provider API to create the order
    const providerOrder = await provider.createOrder({
      numberId: params.numberId,
      providerId: params.providerId,
      operatorId: params.operatorId,
    });

    // Use provider's order ID as our primary order ID
    orderId = providerOrder.order_id || orderId;

    // Create order record
    const order = await prisma.order.create({
      data: {
        orderId,
        userId,
        serviceCode: params.serviceCode,
        serviceName: params.serviceName,
        serviceImg: params.serviceImg || null,
        country: params.country,
        phoneNumber: providerOrder.phone_number,
        operator: providerOrder.operator,
        server: `v${params.providerId}.0`,
        price,
        status: 'WAITING',
        numberIdRef: params.numberId,
        providerIdRef: params.providerId,
        operatorIdRef: params.operatorId,
        expiredAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
      },
    });

    // Log activity
    await prisma.activity.create({
      data: {
        userId,
        type: 'PAYMENT',
        description: `Pembelian ${params.serviceName} (${order.phoneNumber})`,
        amount: -price,
        balance: user.balance - price,
      },
    });

    logger.info(`Order created: ${orderId} for user ${userId}`);

    // Notify user about order (fire-and-forget)
    notificationService.notifyOrder(userId, 'placed', {
      orderId, serviceName: params.serviceName, phoneNumber: providerOrder.phone_number,
      country: params.country, price,
    }).catch(() => {});

    return order;
  } catch (error) {
    // Rollback: refund balance on provider failure
    await prisma.user.update({
      where: { id: userId },
      data: { balance: { increment: price } },
    });

    logger.error(`Order creation failed, balance refunded for user ${userId}:`, error);

    if (error instanceof AppError) throw error;
    throw new AppError('Gagal membuat pesanan. Saldo telah dikembalikan.', 500, 'ORDER_FAILED');
  }
}

/**
 * Check OTP status for an order by polling the provider.
 * Updates local DB if OTP is received.
 * @param orderId - Local order ID (SFO format)
 * @param userId - User's database ID (for authorization)
 */
export async function checkOrderStatus(orderId: string, userId: string) {
  const order = await prisma.order.findFirst({
    where: { orderId, userId },
  });

  if (!order) {
    throw new AppError('Pesanan tidak ditemukan', 404, 'ORDER_NOT_FOUND');
  }

  if (order.status === 'COMPLETED' || order.status === 'CANCELED') {
    return order;
  }

  // Auto cancel if expired (after 15-20 minutes)
  if (order.status === 'WAITING' && Date.now() > new Date(order.expiredAt).getTime()) {
    try {
      return await cancelOrder(orderId, userId);
    } catch (err) {
      logger.error(`Failed to auto-cancel expired order ${orderId}:`, err);
    }
  }

  // Poll provider for status update using provider order_id (which is stored in orderId)
  const status = await provider.getOrderStatus(order.orderId);

  // Update local order if OTP received and is valid
  if (status.otp_code && status.otp_code !== '-' && status.otp_code.trim() !== '') {
    const updated = await prisma.order.update({
      where: { id: order.id },
      data: {
        status: 'RECEIVED',
        otpCode: status.otp_code,
        otpMessage: status.otp_msg || '',
      },
    });

    // Notify user OTP received
    notificationService.notifyOrder(userId, 'received', {
      orderId: order.orderId, serviceName: order.serviceName,
      phoneNumber: order.phoneNumber, country: order.country,
      price: order.price, otpCode: status.otp_code,
    }).catch(() => {});

    return updated;
  }

  return order;
}

/**
 * Cancel an active order and refund the user.
 * @param orderId - Local order ID
 * @param userId - User's database ID
 */
export async function cancelOrder(orderId: string, userId: string) {
  const order = await prisma.order.findFirst({
    where: { orderId, userId },
  });

  if (!order) {
    throw new AppError('Pesanan tidak ditemukan', 404, 'ORDER_NOT_FOUND');
  }

  if (order.status !== 'WAITING') {
    throw new AppError('Hanya pesanan dengan status WAITING yang bisa dibatalkan', 400, 'CANCEL_NOT_ALLOWED');
  }

  // Cancel on provider side using provider order_id (which is stored in orderId)
  await provider.setOrderStatus(order.orderId, 'cancel');

  // Refund and update order
  const [updated] = await prisma.$transaction([
    prisma.order.update({
      where: { id: order.id },
      data: { status: 'CANCELED', refunded: true },
    }),
    prisma.user.update({
      where: { id: userId },
      data: { balance: { increment: order.price } },
    }),
    prisma.activity.create({
      data: {
        userId,
        type: 'REFUND',
        description: `Refund cancel ${order.serviceName} (${order.phoneNumber})`,
        amount: order.price,
      },
    }),
  ]);

  logger.info(`Order cancelled & refunded: ${orderId}`);

  // Notify user about cancellation/refund
  notificationService.notifyOrder(userId, 'cancelled', {
    orderId: order.orderId, serviceName: order.serviceName,
    phoneNumber: order.phoneNumber, country: order.country, price: order.price,
  }).catch(() => {});

  return updated;
}

/**
 * Mark order as completed (done).
 * @param orderId - Local order ID
 * @param userId - User's database ID
 */
export async function completeOrder(orderId: string, userId: string) {
  const order = await prisma.order.findFirst({
    where: { orderId, userId },
  });

  if (!order) {
    throw new AppError('Pesanan tidak ditemukan', 404, 'ORDER_NOT_FOUND');
  }

  if (order.status !== 'RECEIVED') {
    throw new AppError('Hanya pesanan dengan OTP yang sudah diterima bisa diselesaikan', 400, 'COMPLETE_NOT_ALLOWED');
  }

  await provider.setOrderStatus(order.orderId, 'done');

  const updated = await prisma.order.update({
    where: { id: order.id },
    data: { status: 'COMPLETED' },
  });

  return updated;
}

/**
 * Resend OTP code for an active order.
 * @param orderId - Local order ID
 * @param userId - User's database ID
 */
export async function resendOrder(orderId: string, userId: string) {
  const order = await prisma.order.findFirst({
    where: { orderId, userId },
  });

  if (!order) {
    throw new AppError('Pesanan tidak ditemukan', 404, 'ORDER_NOT_FOUND');
  }

  if (order.status !== 'WAITING') {
    throw new AppError('Hanya pesanan aktif yang bisa di-resend', 400, 'RESEND_NOT_ALLOWED');
  }

  // Set resend on provider side using provider order_id
  await provider.setOrderStatus(order.orderId, 'resend');

  return order;
}

/**
 * Buy again an existing order.
 * @param orderId - Local order ID
 * @param userId - User's database ID
 */
export async function buyAgain(orderId: string, userId: string) {
  const order = await prisma.order.findFirst({
    where: { orderId, userId },
  });

  if (!order) {
    throw new AppError('Pesanan tidak ditemukan', 404, 'ORDER_NOT_FOUND');
  }

  // Re-calculate provider price backward from the old order price
  // Subtract the flat margin to get the original provider price
  const providerPrice = order.price - env.MARGIN_ORDER;

  return createOrder(userId, {
    numberId: order.numberIdRef,
    providerId: order.providerIdRef,
    operatorId: order.operatorIdRef,
    serviceCode: order.serviceCode,
    serviceName: order.serviceName,
    serviceImg: order.serviceImg || undefined,
    country: order.country,
    providerPrice,
  });
}

/**
 * Get user's orders with pagination and filtering.
 * @param userId - User's database ID
 * @param params - Filter and pagination params
 */
export async function getUserOrders(
  userId: string,
  params: { page?: number; limit?: number; status?: string; startDate?: string; endDate?: string }
) {
  const page = Number(params.page) || 1;
  const limit = Number(params.limit) || 20;
  const skip = (page - 1) * limit;

  const where: Record<string, unknown> = { userId };

  if (params.status) {
    where.status = params.status;
  }

  if (params.startDate || params.endDate) {
    where.createdAt = {};
    if (params.startDate) (where.createdAt as Record<string, Date>).gte = new Date(params.startDate);
    if (params.endDate) (where.createdAt as Record<string, Date>).lte = new Date(params.endDate);
  }

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.order.count({ where }),
  ]);

  // Auto cancel any expired orders
  const now = Date.now();
  const updatedOrders = await Promise.all(orders.map(async (order: any) => {
    if (order.status === 'WAITING') {
      if (now > new Date(order.expiredAt).getTime()) {
        try {
          return await cancelOrder(order.orderId, userId);
        } catch (err) {
          logger.error(`Failed to auto-cancel expired order ${order.orderId}:`, err);
          return order;
        }
      } else {
        // Auto-sync status with provider for active WAITING orders
        try {
          return await checkOrderStatus(order.orderId, userId);
        } catch (err) {
          return order; // fail silently, return db state
        }
      }
    }
    return order;
  }));

  return {
    orders: updatedOrders,
    meta: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    },
  };
}
