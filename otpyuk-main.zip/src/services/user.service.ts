/**
 * user.service.ts — User Profile Business Logic
 * Handles profile updates, avatar upload, session management, and balance queries.
 */

import { prisma } from '../config/database';
import { AppError } from '../utils/response';
import { hashPassword, comparePassword } from '../utils/crypto';
import { logger } from '../utils/logger';

/**
 * Get full user profile by database ID.
 * @param userId - User's database ID
 */
export async function getProfile(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      userId: true,
      username: true,
      email: true,
      firstName: true,
      lastName: true,
      avatar: true,
      balance: true,
      role: true,
      isVerified: true,
      isActive: true,
      twoFaEnabled: true,
      googleId: true,
      telegramId: true,
      whatsappId: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  if (!user) {
    throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');
  }

  return user;
}

/**
 * Update user profile fields.
 * @param userId - User's database ID
 * @param data - Fields to update
 */
export async function updateProfile(
  userId: string,
  data: { firstName?: string; lastName?: string; username?: string }
) {
  // Check username uniqueness if being changed
  if (data.username) {
    const existing = await prisma.user.findFirst({
      where: { username: data.username, id: { not: userId } },
    });
    if (existing) {
      throw new AppError('Username sudah digunakan', 409, 'USERNAME_EXISTS');
    }
  }

  const updated = await prisma.user.update({
    where: { id: userId },
    data: {
      firstName: data.firstName,
      lastName: data.lastName,
      username: data.username,
    },
    select: {
      id: true,
      userId: true,
      username: true,
      email: true,
      firstName: true,
      lastName: true,
      avatar: true,
      balance: true,
      role: true,
    },
  });

  return updated;
}

/**
 * Update user avatar path.
 * @param userId - User's database ID
 * @param avatarPath - Path to uploaded avatar
 */
export async function updateAvatar(userId: string, avatarPath: string) {
  return prisma.user.update({
    where: { id: userId },
    data: { avatar: avatarPath },
    select: { avatar: true },
  });
}

/**
 * Change user password.
 * @param userId - User's database ID
 * @param currentPassword - Current password for verification
 * @param newPassword - New password
 */
export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { password: true },
  });

  if (!user?.password) {
    throw new AppError('Akun ini menggunakan login Google, tidak bisa ganti password', 400, 'NO_PASSWORD');
  }

  const isValid = await comparePassword(currentPassword, user.password);
  if (!isValid) {
    throw new AppError('Password saat ini salah', 401, 'WRONG_PASSWORD');
  }

  const hashed = await hashPassword(newPassword);
  await prisma.user.update({
    where: { id: userId },
    data: { password: hashed },
  });

  logger.info(`Password changed for user ${userId}`);
}

/**
 * Get user balance.
 * @param userId - User's database ID
 */
export async function getBalance(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { balance: true },
  });

  if (!user) {
    throw new AppError('User tidak ditemukan', 404, 'USER_NOT_FOUND');
  }

  return { balance: user.balance };
}

/**
 * Get user's active sessions.
 * @param userId - User's database ID
 */
export async function getUserSessions(userId: string) {
  return prisma.session.findMany({
    where: { userId, expiresAt: { gt: new Date() } },
    select: {
      id: true,
      userAgent: true,
      ip: true,
      lastActive: true,
      createdAt: true,
    },
    orderBy: { lastActive: 'desc' },
  });
}

/**
 * Delete a specific session.
 * @param sessionId - Session ID
 * @param userId - User's database ID (authorization)
 */
export async function deleteSession(sessionId: string, userId: string) {
  const session = await prisma.session.findFirst({
    where: { id: sessionId, userId },
  });

  if (!session) {
    throw new AppError('Session tidak ditemukan', 404, 'SESSION_NOT_FOUND');
  }

  await prisma.session.delete({ where: { id: sessionId } });
}

/**
 * Revoke all sessions for a user.
 * @param userId - User's database ID
 */
export async function revokeAllSessions(userId: string) {
  const result = await prisma.session.deleteMany({ where: { userId } });
  logger.info(`Revoked ${result.count} sessions for user ${userId}`);
  return result;
}

/**
 * Get user activities with pagination.
 * @param userId - User's database ID
 * @param params - Filter params
 */
export async function getUserActivities(
  userId: string,
  params: { page?: number; limit?: number; type?: string; startDate?: string; endDate?: string }
) {
  const page = params.page || 1;
  const limit = params.limit || 50;
  const skip = (page - 1) * limit;

  const where: Record<string, unknown> = { userId };
  if (params.type) where.type = params.type;
  if (params.startDate || params.endDate) {
    where.createdAt = {};
    if (params.startDate) (where.createdAt as Record<string, Date>).gte = new Date(params.startDate);
    if (params.endDate) (where.createdAt as Record<string, Date>).lte = new Date(params.endDate);
  }

  const [activities, total] = await Promise.all([
    prisma.activity.findMany({ where, orderBy: { createdAt: 'desc' }, skip, take: limit }),
    prisma.activity.count({ where }),
  ]);

  return {
    activities,
    meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
  };
}
