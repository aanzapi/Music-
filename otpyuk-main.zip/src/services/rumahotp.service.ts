/**
 * rumahotp.service.ts — RumahOTP Provider API Wrapper
 * Wraps all 12 RumahOTP API endpoints with typed responses,
 * error handling, and Redis caching.
 */

import axios, { AxiosInstance } from 'axios';
import http from 'http';
import https from 'https';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import { AppError } from '../utils/response';
import { cacheService } from './cache.service';
import type {
  ProviderResponse,
  ProviderService,
  ProviderCountry,
  ProviderOperator,
  ProviderOrderResponse,
  ProviderOrderStatus,
  ProviderDepositResponse,
  ProviderDepositStatus,
} from '../types/api.types';

/** Persistent HTTP/HTTPS agents to prevent socket exhaustion and memory leaks */
const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 50 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 50 });

/** RumahOTP API client singleton */
const client: AxiosInstance = axios.create({
  baseURL: env.RUMAHOTP_BASE_URL,
  timeout: 15000,
  headers: {
    'x-apikey': env.RUMAHOTP_API_KEY,
    'Content-Type': 'application/json',
  },
  httpAgent,
  httpsAgent,
});

// Log all provider API calls
client.interceptors.response.use(
  (response) => {
    logger.debug(`RumahOTP API [${response.config.url}]: ${response.status}`);
    return response;
  },
  (error) => {
    logger.error(`RumahOTP API Error [${error.config?.url}]: ${error.message}`);
    throw new AppError(
      `Provider API error: ${error.response?.data?.message || error.message}`,
      502,
      'PROVIDER_ERROR'
    );
  }
);

// ── 1. Get Provider Balance ───────────────────────

/**
 * GET /v1/user/balance — Check provider account balance.
 * @returns Provider balance data
 */
export async function getProviderBalance(): Promise<{ balance: number }> {
  const { data } = await client.get<ProviderResponse<{ balance: number }>>('/v1/user/balance');
  return data.data;
}

// ── 2. Get Services ───────────────────────────────

/**
 * GET /v2/services — List all available services.
 * Cached for 5 minutes in Redis.
 * @returns Array of services
 */
export async function getServices(): Promise<ProviderService[]> {
  return cacheService.getOrSet<ProviderService[]>(
    'provider:services',
    async () => {
      const { data } = await client.get<ProviderResponse<ProviderService[]>>('/v2/services');
      return data.data;
    },
    300 // 5 minutes
  );
}

// ── 3. Get Countries ──────────────────────────────

/**
 * GET /v2/countries?service_id=X — List countries for a service.
 * Cached for 2 minutes per service.
 * @param serviceId - Service ID
 * @returns Array of country options
 */
export async function getCountries(serviceId: number): Promise<ProviderCountry[]> {
  return cacheService.getOrSet<ProviderCountry[]>(
    `provider:countries:${serviceId}`,
    async () => {
      const { data } = await client.get<ProviderResponse<ProviderCountry[]>>(
        `/v2/countries?service_id=${serviceId}`
      );
      return data.data;
    },
    120 // 2 minutes
  );
}

// ── 4. Get Operators ──────────────────────────────

/**
 * GET /v2/operators?country=X&provider_id=X — List operators.
 * @param country - Country code
 * @param providerId - Provider ID
 * @returns Array of operator options
 */
export async function getOperators(country: string, providerId: number): Promise<ProviderOperator[]> {
  return cacheService.getOrSet<ProviderOperator[]>(
    `provider:operators:${country}:${providerId}`,
    async () => {
      const { data } = await client.get<ProviderResponse<ProviderOperator[]>>(
        `/v2/operators?country=${country}&provider_id=${providerId}`
      );
      return data.data;
    },
    120
  );
}

// ── 5. Create Order ───────────────────────────────

/**
 * GET /v2/orders?number_id=X&provider_id=X&operator_id=X — Place a new order.
 * NOT cached — always hits provider.
 * @param params - Order parameters
 * @returns Order response with phone number
 */
export async function createOrder(params: {
  numberId: number;
  providerId: number;
  operatorId: number;
}): Promise<ProviderOrderResponse> {
  const { data } = await client.get<ProviderResponse<ProviderOrderResponse>>(
    `/v2/orders?number_id=${params.numberId}&provider_id=${params.providerId}&operator_id=${params.operatorId}`
  );

  if (data.success === false || data.status === false) {
    let errorMsg = data.message || (data as any).msg || (data as any).error || 'Gagal membuat pesanan';
    if (typeof errorMsg === 'object') {
      errorMsg = JSON.stringify(errorMsg);
    }
    throw new AppError(errorMsg as string, 400, 'ORDER_CREATE_FAILED');
  }

  return data.data;
}

// ── 6. Get Order Status ───────────────────────────

/**
 * GET /v1/orders/get_status?order_id=X — Check order OTP status.
 * @param orderId - Provider order ID
 * @returns Order status with SMS/OTP code
 */
export async function getOrderStatus(orderId: string): Promise<ProviderOrderStatus> {
  const { data } = await client.get<ProviderResponse<ProviderOrderStatus>>(
    `/v1/orders/get_status?order_id=${orderId}`
  );
  return data.data;
}

// ── 7. Set Order Status ───────────────────────────

/**
 * GET /v1/orders/set_status?order_id=X&status=X — Update order status.
 * @param orderId - Provider order ID
 * @param status - New status (e.g. 'cancel', 'done')
 * @returns Updated status
 */
export async function setOrderStatus(orderId: string, status: string): Promise<{ status: string }> {
  const { data } = await client.get<ProviderResponse<{ status: string }>>(
    `/v1/orders/set_status?order_id=${orderId}&status=${status}`
  );
  return data.data;
}

// ── 8. Create Deposit (v2) ────────────────────────

/**
 * GET /v2/deposit/create?amount=X&payment_id=X — Create deposit.
 * @param amount - Deposit amount in IDR
 * @param paymentId - Payment method string (qris, usdt-bep-20, etc.)
 * @returns Deposit response with QR code, currency breakdown
 */
export async function createDeposit(amount: number, paymentId: string): Promise<ProviderDepositResponse> {
  const { data } = await client.get<ProviderResponse<ProviderDepositResponse>>(
    `/v2/deposit/create?amount=${amount}&payment_id=${paymentId}`
  );

  if (data.success === false || data.status === false) {
    throw new AppError(data.message || 'Gagal membuat deposit', 400, 'DEPOSIT_CREATE_FAILED');
  }

  return data.data;
}

// ── 9. Get Deposit Status (v2) ────────────────────

/**
 * GET /v2/deposit/get_status?deposit_id=X — Check deposit status with brand info.
 * @param depositId - Provider deposit ID string (e.g. RO20260401072942170310)
 * @returns Full status with brand, reference, amounts
 */
export async function getDepositStatus(depositId: string): Promise<ProviderDepositStatus> {
  const { data } = await client.get<ProviderResponse<ProviderDepositStatus>>(
    `/v2/deposit/get_status?deposit_id=${depositId}`
  );
  return data.data;
}

// ── 10. Cancel Deposit ────────────────────────────

/**
 * GET /v1/deposit/cancel?deposit_id=X — Cancel a pending deposit.
 * @param depositId - Provider deposit ID string
 * @returns Cancellation result
 */
export async function cancelDeposit(depositId: string): Promise<{ id: string }> {
  const { data } = await client.get<ProviderResponse<{ id: string }>>(
    `/v1/deposit/cancel?deposit_id=${depositId}`
  );
  return data.data;
}
