/**
 * email.service.ts — Email Service (SendGrid)
 * Buyers edition — uses SendGrid API, no SMTP/Nodemailer.
 */

import { env } from '../config/env';
import { logger } from '../utils/logger';

// ── Design Tokens ─────────────────────────────────

const BRAND = {
  primary: '#f59e0b',
  primaryDark: '#d97706',
  text: '#111827',
  textSecondary: '#6b7280',
  textMuted: '#9ca3af',
  bgPage: '#f9fafb',
  bgCard: '#ffffff',
  bgSubtle: '#f3f4f6',
  border: '#e5e7eb',
  success: '#059669',
  successBg: '#ecfdf5',
  danger: '#dc2626',
  dangerBg: '#fef2f2',
  warning: '#d97706',
  warningBg: '#fffbeb',
};

// ── User-Agent Parser ─────────────────────────────

function parseDevice(ua?: string): { browser: string; os: string } {
  if (!ua) return { browser: 'Unknown', os: 'Unknown' };

  let browser = 'Unknown';
  if (ua.includes('Edg/')) browser = 'Microsoft Edge';
  else if (ua.includes('OPR/') || ua.includes('Opera')) browser = 'Opera';
  else if (ua.includes('Chrome/') && !ua.includes('Edg/')) browser = 'Google Chrome';
  else if (ua.includes('Firefox/')) browser = 'Mozilla Firefox';
  else if (ua.includes('Safari/') && !ua.includes('Chrome')) browser = 'Safari';
  else browser = 'Other';

  let os = 'Unknown';
  if (ua.includes('Windows NT 10')) os = 'Windows 10/11';
  else if (ua.includes('Windows NT')) os = 'Windows';
  else if (ua.includes('Mac OS X')) os = 'macOS';
  else if (ua.includes('Android')) os = 'Android';
  else if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';
  else if (ua.includes('Linux')) os = 'Linux';

  return { browser, os };
}

function formatIP(ip?: string): string {
  if (!ip || ip === '::1' || ip === '127.0.0.1' || ip === '::ffff:127.0.0.1') return 'Localhost (Dev)';
  if (ip.startsWith('::ffff:')) return ip.slice(7);
  return ip;
}

// ── Base HTML Template ────────────────────────────

function emailWrapper(content: string): string {
  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>otpyuk</title>
</head>
<body style="margin:0;padding:0;background:${BRAND.bgPage};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;-webkit-font-smoothing:antialiased;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${BRAND.bgPage};padding:48px 20px;">
    <tr><td align="center">
      <table role="presentation" width="520" cellpadding="0" cellspacing="0" style="max-width:520px;width:100%;">
        <tr>
          <td style="padding:24px;text-align:center;background:${BRAND.primary};border-radius:12px 12px 0 0;">
            <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:bold;letter-spacing:-0.5px;">otpyuk</h1>
          </td>
        </tr>
        <tr>
          <td style="background:${BRAND.bgCard};border-radius:0 0 12px 12px;border:1px solid ${BRAND.border};border-top:3px solid ${BRAND.primary};overflow:hidden;">
            ${content}
          </td>
        </tr>
        <tr>
          <td style="padding:24px 0 0;text-align:center;">
            <p style="margin:0;color:${BRAND.textMuted};font-size:12px;line-height:20px;">
              © ${new Date().getFullYear()} otpyuk
            </p>
            <p style="margin:4px 0 0;color:${BRAND.textMuted};font-size:11px;">
              Email ini dikirim otomatis. Tidak perlu membalas.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

// ── Reusable Components ───────────────────────────

function infoRow(label: string, value: string, isLast = false): string {
  return `<tr>
    <td style="padding:12px 24px;color:${BRAND.textSecondary};font-size:13px;border-bottom:${isLast ? 'none' : `1px solid ${BRAND.border}`};">${label}</td>
    <td style="padding:12px 24px;color:${BRAND.text};font-size:13px;font-weight:600;text-align:right;border-bottom:${isLast ? 'none' : `1px solid ${BRAND.border}`};">${value}</td>
  </tr>`;
}

function alertBox(text: string, type: 'warning' | 'danger' | 'success' = 'warning'): string {
  const colors = {
    warning: { bg: BRAND.warningBg, border: BRAND.warning, text: '#92400e' },
    danger: { bg: BRAND.dangerBg, border: BRAND.danger, text: '#991b1b' },
    success: { bg: BRAND.successBg, border: BRAND.success, text: '#065f46' },
  };
  const c = colors[type];
  return `<div style="margin:0 24px 24px;padding:12px 16px;background:${c.bg};border-left:3px solid ${c.border};border-radius:6px;">
    <p style="margin:0;color:${c.text};font-size:13px;line-height:20px;">${text}</p>
  </div>`;
}

function ctaButton(text: string, url: string, color = BRAND.primary): string {
  return `<div style="padding:0 24px 24px;text-align:center;">
    <a href="${url}" style="display:inline-block;padding:12px 28px;background:${color};color:#fff;text-decoration:none;border-radius:8px;font-weight:600;font-size:14px;">${text}</a>
  </div>`;
}

// ── Core Send Function (SendGrid) ─────────────────

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(options: EmailOptions): Promise<void> {
  if (!env.SENDGRID_API_KEY) {
    logger.warn(`[EMAIL] SendGrid not configured, skip: ${options.subject} → ${options.to}`);
    return;
  }

  try {
    const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${env.SENDGRID_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: options.to }] }],
        from: { email: env.EMAIL_FROM, name: 'otpyuk' },
        subject: options.subject,
        content: [
          { type: 'text/plain', value: options.text || options.html.replace(/<[^>]*>/g, '') },
          { type: 'text/html', value: options.html },
        ],
      }),
    });

    if (!res.ok) {
      const errorText = await res.text();
      logger.error(`[EMAIL] SendGrid error (${res.status}): ${errorText}`);
    } else {
      logger.info(`[EMAIL] Sent: ${options.subject} → ${options.to}`);
    }
  } catch (error) {
    logger.error(`[EMAIL] Failed to send to ${options.to}:`, error);
  }
}

// ── Template Functions ────────────────────────────

export async function sendOtpEmail(email: string, otpCode: string, type: string, directLink?: string): Promise<void> {
  const typeLabels: Record<string, string> = {
    register: 'Verifikasi Akun', login_2fa: 'Verifikasi Login',
    enable_2fa: 'Aktifkan 2FA', disable_2fa: 'Nonaktifkan 2FA', forgot_password: 'Reset Password',
  };
  const label = typeLabels[type] || 'Verifikasi';
  const digits = otpCode.split('');
  const otpBoxes = digits.map(d =>
    `<td style="width:44px;height:52px;background:${BRAND.bgSubtle};border:1px solid ${BRAND.border};border-radius:8px;text-align:center;font-size:24px;font-weight:700;color:${BRAND.text};font-family:monospace;">${d}</td>`
  ).join('<td style="width:6px;"></td>');

  const directLinkHtml = directLink
    ? `${ctaButton('Verifikasi Langsung', directLink)}
       <p style="text-align:center;color:${BRAND.textMuted};font-size:12px;padding:0 24px;">Atau masukkan kode OTP secara manual.</p>`
    : '';

  await sendEmail({
    to: email,
    subject: `${otpCode} — Kode ${label} | otpyuk`,
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">${label}</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 24px;line-height:22px;">Gunakan kode di bawah ini. Berlaku <strong>5 menit</strong>.</p>
        <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto 24px;">
          <tr>${otpBoxes}</tr>
        </table>
      </div>
      ${directLinkHtml}
      ${alertBox('Jangan pernah memberikan kode ini kepada siapapun.')}
    `),
  });
}

export async function sendLoginAlertEmail(
  email: string,
  details: { ip?: string; userAgent?: string; time: string; firstName?: string }
): Promise<void> {
  const device = parseDevice(details.userAgent);
  const ip = formatIP(details.ip);

  await sendEmail({
    to: email,
    subject: 'Login baru terdeteksi — otpyuk',
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Login Baru Terdeteksi</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 24px;line-height:22px;">Halo ${details.firstName || 'User'}, kami mendeteksi login baru ke akun Anda.</p>
      </div>
      <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid ${BRAND.border};">
        ${infoRow('Waktu', details.time)}
        ${infoRow('Perangkat', `${device.browser} di ${device.os}`)}
        ${infoRow('Alamat IP', ip, true)}
      </table>
      <div style="height:24px;"></div>
      ${alertBox('Jika ini bukan Anda, segera ganti password.', 'danger')}
      ${ctaButton('Amankan Akun', `${env.APP_URL}/client/profile`, BRAND.danger)}
    `),
  });
}

export async function sendWelcomeEmail(email: string, name: string): Promise<void> {
  await sendEmail({
    to: email,
    subject: 'Selamat datang di otpyuk',
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Selamat Datang, ${name}!</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 24px;line-height:22px;">Akun Anda berhasil dibuat. Mulai gunakan layanan OTP virtual sekarang.</p>
      </div>
      ${ctaButton('Masuk ke Dashboard', `${env.APP_URL}/login`)}
    `),
  });
}

export async function sendDepositSuccessEmail(
  email: string,
  deposit: { depositId: string; received: number; method: string; brandName?: string }
): Promise<void> {
  await sendEmail({
    to: email,
    subject: `Deposit ${deposit.depositId} berhasil — otpyuk`,
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Deposit Berhasil</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 24px;line-height:22px;">Saldo Anda telah ditambahkan.</p>
      </div>
      <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid ${BRAND.border};">
        ${infoRow('ID Deposit', deposit.depositId)}
        ${infoRow('Nominal', `Rp ${deposit.received.toLocaleString('id-ID')}`)}
        ${infoRow('Metode', deposit.brandName || deposit.method, true)}
      </table>
      <div style="height:24px;"></div>
      ${ctaButton('Lihat Saldo', `${env.APP_URL}/client/dashboard`)}
    `),
  });
}

export async function sendOrderEmail(
  email: string,
  order: { orderId: string; serviceName: string; phoneNumber: string; country: string; price: number; otpCode?: string; status: string }
): Promise<void> {
  const isReceived = order.status === 'RECEIVED' && order.otpCode;
  const isCancelled = order.status === 'CANCELED';
  const title = isReceived ? 'OTP Diterima' : isCancelled ? 'Order Dibatalkan' : 'Order Dibuat';

  let otpSection = '';
  if (isReceived && order.otpCode) {
    const digits = order.otpCode.split('');
    const boxes = digits.map(d =>
      `<td style="width:40px;height:48px;background:${BRAND.successBg};border:1px solid #a7f3d0;border-radius:8px;text-align:center;font-size:22px;font-weight:700;color:${BRAND.success};font-family:monospace;">${d}</td>`
    ).join('<td style="width:5px;"></td>');
    otpSection = `
      <div style="padding:20px 24px;text-align:center;background:${BRAND.bgSubtle};border-top:1px solid ${BRAND.border};">
        <p style="color:${BRAND.textSecondary};font-size:12px;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px;font-weight:600;">Kode OTP</p>
        <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto;"><tr>${boxes}</tr></table>
      </div>`;
  }

  const refundSection = isCancelled
    ? alertBox(`Refund sebesar Rp ${order.price.toLocaleString('id-ID')} telah dikembalikan ke saldo Anda.`, 'success')
    : '';

  await sendEmail({
    to: email,
    subject: `${title}: ${order.serviceName} — otpyuk`,
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">${title}</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 24px;line-height:22px;">${isReceived ? 'Kode OTP telah diterima.' : isCancelled ? 'Order dibatalkan.' : 'Order baru telah dibuat.'}</p>
      </div>
      <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid ${BRAND.border};">
        ${infoRow('Invoice', order.orderId)}
        ${infoRow('Layanan', order.serviceName)}
        ${infoRow('Nomor', order.phoneNumber)}
        ${infoRow('Negara', order.country)}
        ${infoRow('Harga', `Rp ${order.price.toLocaleString('id-ID')}`, true)}
      </table>
      ${otpSection}
      <div style="height:${refundSection ? '0' : '24'}px;"></div>
      ${refundSection}
    `),
  });
}

export async function sendPasswordChangedEmail(email: string): Promise<void> {
  const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  await sendEmail({
    to: email,
    subject: 'Password diubah — otpyuk',
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Password Diubah</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 8px;line-height:22px;">Password Anda diubah pada ${time}.</p>
      </div>
      ${alertBox('Jika bukan Anda, segera amankan akun.', 'danger')}
      ${ctaButton('Amankan Akun', `${env.APP_URL}/client/profile`, BRAND.danger)}
    `),
  });
}

export async function send2faStatusEmail(email: string, enabled: boolean): Promise<void> {
  const status = enabled ? 'diaktifkan' : 'dinonaktifkan';
  await sendEmail({
    to: email,
    subject: `Verifikasi 2 langkah ${status} — otpyuk`,
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Verifikasi 2 Langkah ${enabled ? 'Aktif' : 'Nonaktif'}</h2>
      </div>
      ${enabled
        ? alertBox('Akun Anda sekarang lebih aman.', 'success')
        : alertBox('2FA dinonaktifkan. Kami sarankan mengaktifkannya kembali.', 'warning')
      }
    `),
  });
}

export async function sendPasswordResetEmail(email: string, token: string): Promise<void> {
  const resetUrl = `${env.APP_URL}/reset-password?token=${token}`;
  await sendEmail({
    to: email,
    subject: 'Reset password — otpyuk',
    html: emailWrapper(`
      <div style="padding:32px 24px 24px;">
        <h2 style="margin:0 0 8px;color:${BRAND.text};font-size:20px;font-weight:700;">Reset Password</h2>
        <p style="color:${BRAND.textSecondary};font-size:14px;margin:0 0 8px;line-height:22px;">Klik tombol di bawah. Berlaku 1 jam.</p>
      </div>
      ${ctaButton('Reset Password', resetUrl)}
      <p style="text-align:center;color:${BRAND.textMuted};font-size:12px;padding:0 24px 24px;">Jika bukan Anda, abaikan email ini.</p>
    `),
  });
}
