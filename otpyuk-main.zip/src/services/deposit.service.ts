/**
 * deposit.service.ts — Deposit Business Logic (v2)
 * Handles balance top-up via QRIS/USDT, status checking, and cancellation.
 * Uses RumahOTP v2 API endpoints for full brand/currency metadata.
 */

import { prisma } from '../config/database';
import * as provider from './rumahotp.service';
import { AppError } from '../utils/response';
import { generateDepositId } from '../utils/crypto';
import { env } from '../config/env';
import { logger } from '../utils/logger';

// Payment method type matching Prisma enum
type PaymentMethod = 'QRIS' | 'USDT_BEP20' | 'USDT_TRC20' | 'USDT_POLYGON' | 'USDT_ERC20';

/** Payment method mapping to provider payment_id string (v2 API) */
const PAYMENT_METHOD_MAP: Record<string, string> = {
  QRIS: 'qris',
  USDT_BEP20: 'usdt-bep-20',
  USDT_TRC20: 'usdt-trc-20',
  USDT_POLYGON: 'usdt-polygon',
  USDT_ERC20: 'usdt-erc-20',
};

/**
 * Create a new deposit/top-up request via v2 API.
 * @param userId - User's database ID
 * @param amount - Deposit amount in IDR (what user wants to receive)
 * @param method - Payment method enum
 */
export async function createDeposit(userId: string, amount: number, method: PaymentMethod) {
  if (amount < 3000) {
    throw new AppError('Minimum deposit Rp3.000', 400, 'MIN_DEPOSIT');
  }

  const paymentId = PAYMENT_METHOD_MAP[method];
  if (!paymentId) {
    throw new AppError('Metode pembayaran tidak valid', 400, 'INVALID_PAYMENT_METHOD');
  }

  // Flat margin fee for deposit (owner profit)
  const depositFee = env.MARGIN_DEPOSIT;
  
  // Requested amount = user amount + our fee
  const requestedAmount = amount + depositFee;

  // Create deposit on provider side (v2)
  const res = await provider.createDeposit(requestedAmount, paymentId);

  const depositId = generateDepositId();

  // v2 response has currency breakdown: { total, fee, diterima }
  const totalAmount = res.currency?.total || res.amount || requestedAmount;
  const providerFee = res.currency?.fee || 0;
  
  // Total fee shown to user includes provider fee + our markup
  const fee = providerFee + depositFee;
  
  // User will receive exactly what they requested
  const received = amount;

  // Create local deposit record
  const deposit = await prisma.deposit.create({
    data: {
      depositId,
      userId,
      amount: totalAmount,
      fee,
      received,
      method,
      status: 'PENDING',
      qrString: res.qr_string || null,
      qrImage: res.qr_image || null,
      brandName: null,   // brand info comes from status check
      brandIcon: null,
      referenceId: res.id, // v2 returns string ID like "RO20260401072942170310"
      expiredAt: new Date(res.expired || Date.now() + 15 * 60 * 1000),
    },
  });

  logger.info(`Deposit created: ${depositId} (ref: ${res.id}) for user ${userId}, total: ${totalAmount}, fee: ${fee}, received: ${received}`);

  return deposit;
}

/**
 * Check deposit payment status via v2 API.
 * If paid, credits user balance and saves brand info.
 * @param depositId - Local deposit ID
 * @param userId - User's database ID
 */
export async function checkDepositStatus(depositId: string, userId: string) {
  const deposit = await prisma.deposit.findFirst({
    where: { depositId, userId },
  });

  if (!deposit) {
    throw new AppError('Deposit tidak ditemukan', 404, 'DEPOSIT_NOT_FOUND');
  }

  if (deposit.status !== 'PENDING') {
    return deposit;
  }

  // Poll provider v2 with string deposit ID
  const refId = deposit.referenceId;
  if (!refId) return deposit;

  const statusRes = await provider.getDepositStatus(refId);

  // Update brand info if available (v2 provides brand on every status check)
  const brandUpdate: Record<string, string | null> = {};
  if (statusRes && statusRes.brand) {
    brandUpdate.brandName = statusRes.brand.name || null;
    brandUpdate.brandIcon = statusRes.brand.icon || null;
  }

  if (statusRes && statusRes.status === 'success') {
    // Credit user balance strictly based on what they requested (excluding fees)
    const creditAmount = deposit.received;
    const [updated] = await prisma.$transaction([
      prisma.deposit.update({
        where: { id: deposit.id },
        data: {
          status: 'SUCCESS',
          paidAt: statusRes.created_at ? new Date(statusRes.created_at) : new Date(),
          ...brandUpdate,
        },
      }),
      prisma.user.update({
        where: { id: userId },
        data: { balance: { increment: creditAmount } },
      }),
      prisma.activity.create({
        data: {
          userId,
          type: 'DEPOSIT',
          description: `Top up saldo via ${statusRes.brand?.name || deposit.method} (${deposit.depositId})`,
          amount: creditAmount,
        },
      }),
    ]);

    logger.info(`Deposit paid: ${depositId}, credited Rp${creditAmount} via ${statusRes.brand?.name || 'unknown'}`);


    return updated;
  }

  if (statusRes && (statusRes.status === 'cancel' || statusRes.status === 'expired')) {
    const updated = await prisma.deposit.update({
      where: { id: deposit.id },
      data: {
        status: statusRes.status === 'cancel' ? 'CANCEL' : 'EXPIRED',
        ...brandUpdate,
      },
    });
    return updated;
  }

  // Still pending — save brand info if we got it
  if (Object.keys(brandUpdate).length > 0) {
    await prisma.deposit.update({
      where: { id: deposit.id },
      data: brandUpdate,
    });
  }

  return { ...deposit, ...brandUpdate };
}

/**
 * Cancel a pending deposit.
 * @param depositId - Local deposit ID
 * @param userId - User's database ID
 */
export async function cancelDepositById(depositId: string, userId: string) {
  const deposit = await prisma.deposit.findFirst({
    where: { depositId, userId },
  });

  if (!deposit) {
    throw new AppError('Deposit tidak ditemukan', 404, 'DEPOSIT_NOT_FOUND');
  }

  if (deposit.status !== 'PENDING') {
    throw new AppError('Hanya deposit PENDING yang bisa dibatalkan', 400, 'CANCEL_NOT_ALLOWED');
  }

  // Cancel on provider side using string reference ID
  const refId = deposit.referenceId;
  if (refId) {
    await provider.cancelDeposit(refId);
  }

  const updated = await prisma.deposit.update({
    where: { id: deposit.id },
    data: { status: 'CANCEL' },
  });

  logger.info(`Deposit cancelled: ${depositId}`);
  return updated;
}

/**
 * Get user's deposits with pagination.
 * @param userId - User's database ID
 * @param params - Filter and pagination params
 */
export async function getUserDeposits(
  userId: string,
  params: { page?: number; limit?: number; status?: string; startDate?: string; endDate?: string }
) {
  const page = params.page || 1;
  const limit = params.limit || 20;
  const skip = (page - 1) * limit;

  const where: Record<string, unknown> = { userId };

  if (params.status) {
    where.status = params.status;
  }

  if (params.startDate || params.endDate) {
    where.createdAt = {};
    if (params.startDate) (where.createdAt as Record<string, Date>).gte = new Date(params.startDate);
    if (params.endDate) (where.createdAt as Record<string, Date>).lte = new Date(params.endDate);
  }

  const [deposits, total] = await Promise.all([
    prisma.deposit.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.deposit.count({ where }),
  ]);

  return {
    deposits,
    meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
  };
}

/**
 * Handle payment webhook callback.
 * Called when provider confirms payment.
 * @param referenceId - Provider deposit reference ID (string)
 */
export async function handlePaymentCallback(referenceId: string) {
  const deposit = await prisma.deposit.findFirst({
    where: { referenceId, status: 'PENDING' },
  });

  if (!deposit) {
    logger.warn(`Payment callback for unknown deposit ref: ${referenceId}`);
    return;
  }

  // Get full status info from v2 to get brand
  let brandName: string = deposit.method;
  let brandIcon: string | null = null;
  try {
    const statusRes = await provider.getDepositStatus(referenceId);
    if (statusRes.brand) {
      brandName = statusRes.brand.name || deposit.method;
      brandIcon = statusRes.brand.icon || null;
    }
  } catch { /* continue without brand info */ }

  // Credit balance
  await prisma.$transaction([
    prisma.deposit.update({
      where: { id: deposit.id },
      data: {
        status: 'SUCCESS',
        paidAt: new Date(),
        brandName,
        brandIcon,
      },
    }),
    prisma.user.update({
      where: { id: deposit.userId },
      data: { balance: { increment: deposit.received } },
    }),
    prisma.activity.create({
      data: {
        userId: deposit.userId,
        type: 'DEPOSIT',
        description: `Top up saldo via ${brandName} (webhook)`,
        amount: deposit.received,
      },
    }),
  ]);


  logger.info(`Payment webhook processed: ${deposit.depositId} via ${brandName}`);
}
