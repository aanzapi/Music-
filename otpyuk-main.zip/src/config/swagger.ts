/**
 * swagger.ts — Swagger/OpenAPI Configuration
 * Generates API documentation from JSDoc comments on route handlers.
 */

import swaggerJsdoc from 'swagger-jsdoc';
import { env } from './env';

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'otpyuk API',
      version: '1.0.0',
      description:
        'REST API untuk platform OTP virtual number marketplace otpyuk. ' +
        'Menyediakan layanan pembelian nomor virtual OTP otomatis dari 1.700+ layanan & 100+ negara.',
      contact: {
        name: 'otpyuk Support',
        email: 'cuyaan08@gmail.com',
        url: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
      },
      license: {
        name: 'Proprietary',
      },
    },
    servers: [
      {
        url: `http://localhost:${env.PORT}`,
        description: 'Development Server',
      },
      {
        url: env.APP_URL,
        description: 'Production Server',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'JWT access token dari login',
        },
        apiKeyAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'x-apikey',
          description: 'API key untuk developer access',
        },
      },
    },
    tags: [
      { name: 'Auth', description: 'Authentication & registration' },
      { name: 'User', description: 'User profile management' },
      { name: 'Orders', description: 'OTP number ordering' },
      { name: 'Deposit', description: 'Balance top-up & payments' },
      { name: 'Activity', description: 'Activity & transaction logs' },
      { name: 'API Keys', description: 'Developer API key management' },
      { name: 'Webhooks', description: 'Webhook configuration' },
      { name: 'Admin', description: 'Admin panel endpoints' },
      { name: 'Developer', description: 'Public developer API (via x-apikey)' },
    ],
  },
  apis: ['./src/routes/*.ts'],
};

export const swaggerSpec = swaggerJsdoc(options);
