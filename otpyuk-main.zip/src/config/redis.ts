/**
 * redis.ts
 * Konfigurasi Upstash Redis client (serverless, no Docker needed)
 * Docs: https://docs.upstash.com/redis/sdks/ts/getstarted
 */

import { Redis } from '@upstash/redis';
import { env } from './env';
import { logger } from '../utils/logger';

let redis: Redis;

/**
 * Singleton Redis client menggunakan Upstash REST API
 * Tidak perlu koneksi TCP, bekerja di environment serverless
 */
export const getRedisClient = (): Redis => {
  if (!redis) {
    redis = new Redis({
      url: env.UPSTASH_REDIS_REST_URL,
      token: env.UPSTASH_REDIS_REST_TOKEN,
    });
    logger.info('✅ Upstash Redis client initialized');
  }
  return redis;
};

// Eagerly initialize for backward compatibility
try {
  redis = new Redis({
    url: process.env.UPSTASH_REDIS_REST_URL || '',
    token: process.env.UPSTASH_REDIS_REST_TOKEN || '',
  });
} catch {
  // Will be initialized later via getRedisClient()
}

export { redis };
export default getRedisClient;
