/**
 * error.middleware.ts — Global Error Handler
 * Catches all errors thrown by controllers/services and returns a consistent response.
 * Never leaks stack traces to the client in production.
 */

import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/response';
import { logger } from '../utils/logger';
import { env } from '../config/env';

/**
 * Express async handler wrapper.
 * Wraps async route handlers to catch rejected promises automatically.
 * @param fn - Async Express request handler
 */
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * 404 Not Found handler.
 * Catches requests that don't match any route.
 */
export function notFoundHandler(_req: Request, _res: Response, next: NextFunction): void {
  next(new AppError('Route not found', 404, 'ROUTE_NOT_FOUND'));
}

/**
 * Global error handler middleware.
 * Must be registered LAST in the middleware chain.
 */
export function globalErrorHandler(
  err: Error | AppError,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Default values
  let statusCode = 500;
  let message = 'Internal server error';
  let code = 'ERR_500';

  // Handle known operational errors
  if (err instanceof AppError) {
    statusCode = err.statusCode;
    message = err.message;
    code = err.code;
  }

  // Log the error
  if (statusCode >= 500) {
    logger.error(`[${code}] ${err.message}`, {
      stack: err.stack,
      statusCode,
    });
  } else {
    logger.warn(`[${code}] ${err.message}`);
  }

  // Send response
  res.status(statusCode).json({
    success: false,
    error: {
      message,
      code,
      // Only include stack trace in development
      ...(env.NODE_ENV === 'development' && { stack: err.stack }),
    },
  });
}
