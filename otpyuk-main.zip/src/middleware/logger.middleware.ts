/**
 * logger.middleware.ts — HTTP Request Logging
 * Morgan-based request logging with custom format.
 */

import morgan from 'morgan';
import { morganStream } from '../utils/logger';
import { env } from '../config/env';

/**
 * HTTP request logger middleware.
 * - Development: colored 'dev' format to console
 * - Production: 'combined' format to Winston file logger
 */
export const requestLogger = env.NODE_ENV === 'development'
  ? morgan('dev')
  : morgan('combined', { stream: morganStream });
