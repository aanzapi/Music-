/**
 * admin.middleware.ts — Admin Role Authorization
 * Checks that the authenticated user has ADMIN role.
 * Must be used AFTER requireAuth middleware.
 */

import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/response';

/**
 * Middleware: Require ADMIN role.
 * Throws 403 if user is not an admin.
 */
export function requireAdmin(req: Request, _res: Response, next: NextFunction): void {
  if (!req.user) {
    return next(new AppError('Unauthorized', 401, 'AUTH_REQUIRED'));
  }

  if (req.user.role !== 'ADMIN') {
    return next(new AppError('Forbidden: Admin access required', 403, 'ADMIN_REQUIRED'));
  }

  next();
}

/**
 * Middleware: Require ADMIN or RESELLER role.
 */
export function requireAdminOrReseller(req: Request, _res: Response, next: NextFunction): void {
  if (!req.user) {
    return next(new AppError('Unauthorized', 401, 'AUTH_REQUIRED'));
  }

  if (req.user.role !== 'ADMIN' && req.user.role !== 'RESELLER') {
    return next(new AppError('Forbidden: Insufficient permissions', 403, 'INSUFFICIENT_ROLE'));
  }

  next();
}
