/**
 * auth.middleware.ts — JWT Authentication Middleware
 * Verifies JWT access tokens from Authorization header or httpOnly cookies.
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { prisma } from '../config/database';
import { AppError } from '../utils/response';

/** JWT payload structure */
interface JwtPayload {
  userId: string;
  role: string;
  iat: number;
  exp: number;
}

/**
 * Middleware: Require valid JWT access token.
 * Attaches user data to req.user on success.
 */
export async function requireAuth(req: Request, _res: Response, next: NextFunction): Promise<void> {
  try {
    // Extract token from Bearer header or cookie
    let token: string | undefined;

    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      token = authHeader.slice(7);
    } else if (req.cookies?.accessToken) {
      token = req.cookies.accessToken;
    }

    if (!token) {
      throw new AppError('Unauthorized: No token provided', 401, 'AUTH_NO_TOKEN');
    }

    // Verify JWT
    const decoded = jwt.verify(token, env.JWT_ACCESS_SECRET) as JwtPayload;

    // Fetch user from database
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        userId: true,
        email: true,
        username: true,
        firstName: true,
        lastName: true,
        role: true,
        balance: true,
        isActive: true,
        isVerified: true,
        avatar: true,
      },
    });

    if (!user) {
      throw new AppError('Unauthorized: User not found', 401, 'AUTH_USER_NOT_FOUND');
    }

    if (!user.isActive) {
      throw new AppError('Account has been suspended', 403, 'AUTH_ACCOUNT_SUSPENDED');
    }

    // Attach user to request
    req.user = user;
    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      next(new AppError('Token expired', 401, 'AUTH_TOKEN_EXPIRED'));
    } else if (error instanceof jwt.JsonWebTokenError) {
      next(new AppError('Invalid token', 401, 'AUTH_TOKEN_INVALID'));
    } else {
      next(error);
    }
  }
}

/**
 * Middleware: Optionally attach user if token is present.
 * Does NOT throw if no token — allows public + authenticated access.
 */
export async function optionalAuth(req: Request, _res: Response, next: NextFunction): Promise<void> {
  try {
    let token: string | undefined;
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      token = authHeader.slice(7);
    } else if (req.cookies?.accessToken) {
      token = req.cookies.accessToken;
    }

    if (token) {
      const decoded = jwt.verify(token, env.JWT_ACCESS_SECRET) as JwtPayload;
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          userId: true,
          email: true,
          username: true,
          firstName: true,
          lastName: true,
          role: true,
          balance: true,
          isActive: true,
          isVerified: true,
          avatar: true,
        },
      });
      if (user?.isActive) {
        req.user = user;
      }
    }
  } catch {
    // Silently ignore token errors for optional auth
  }
  next();
}
