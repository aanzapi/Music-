/**
 * cron.middleware.ts
 * Validates the Vercel cron request using the authorization header.
 */

import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';
import { AppError } from '../utils/response';

export function requireCron(req: Request, _res: Response, next: NextFunction): void {
  // Vercel sends the CRON_SECRET as a Bearer token in the Authorization header.
  const authHeader = req.headers.authorization;
  
  if (!env.CRON_SECRET) {
    // If no cron secret is configured, allow for local dev, but warn
    console.warn('CRON_SECRET is not configured. Allowing cron execution freely.');
    return next();
  }

  if (authHeader !== `Bearer ${env.CRON_SECRET}`) {
    throw new AppError('Unauthorized Cron Request', 401, 'UNAUTHORIZED');
  }

  next();
}
