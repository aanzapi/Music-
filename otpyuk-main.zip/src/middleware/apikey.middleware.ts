/**
 * apikey.middleware.ts — API Key Authentication Middleware
 * Validates x-apikey header for developer API access.
 * Verifies the key hash, checks IP whitelist, and checks permissions.
 */

import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { hashApiKey } from '../utils/crypto';
import { AppError } from '../utils/response';

/**
 * Middleware: Authenticate via x-apikey header.
 * Verifies the API key, checks IP whitelist, and attaches user to request.
 */
export async function requireApiKey(req: Request, _res: Response, next: NextFunction): Promise<void> {
  try {
    const apiKeyRaw = req.headers['x-apikey'] as string | undefined;

    if (!apiKeyRaw) {
      throw new AppError('Missing x-apikey header', 401, 'APIKEY_MISSING');
    }

    // Hash the provided key and look it up
    const keyHash = hashApiKey(apiKeyRaw);
    const apiKey = await prisma.apiKey.findUnique({
      where: { key: keyHash },
      include: {
        user: {
          select: {
            id: true,
            userId: true,
            email: true,
            username: true,
            firstName: true,
            lastName: true,
            role: true,
            balance: true,
            isActive: true,
            isVerified: true,
            avatar: true,
          },
        },
      },
    });

    if (!apiKey) {
      throw new AppError('Invalid API key', 401, 'APIKEY_INVALID');
    }

    if (!apiKey.isActive) {
      throw new AppError('API key is disabled', 403, 'APIKEY_DISABLED');
    }

    if (!apiKey.user.isActive) {
      throw new AppError('Account suspended', 403, 'ACCOUNT_SUSPENDED');
    }

    // Check IP whitelist (if configured)
    if (apiKey.whitelist.length > 0) {
      const clientIp = req.ip || req.socket.remoteAddress || '';
      const isWhitelisted = apiKey.whitelist.some(
        (ip: string) => ip === clientIp || ip === '*'
      );
      if (!isWhitelisted) {
        throw new AppError('IP not whitelisted for this API key', 403, 'APIKEY_IP_BLOCKED');
      }
    }

    // Update last used timestamp (fire-and-forget)
    prisma.apiKey.update({
      where: { id: apiKey.id },
      data: { lastUsed: new Date() },
    }).catch(() => { /* non-critical */ });

    // Attach user and apiKey permissions to request
    req.user = apiKey.user;
    req.apiKeyPermissions = {
      canNumber: apiKey.canNumber,
      canDeposit: apiKey.canDeposit,
      canH2h: apiKey.canH2h,
    };

    next();
  } catch (error) {
    next(error);
  }
}

/**
 * Middleware factory: Check specific API key permission.
 * @param permission - Permission to check ('canNumber' | 'canDeposit' | 'canH2h')
 */
export function requireApiPermission(permission: 'canNumber' | 'canDeposit' | 'canH2h') {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.apiKeyPermissions?.[permission]) {
      return next(
        new AppError(`API key does not have '${permission}' permission`, 403, 'APIKEY_NO_PERMISSION')
      );
    }
    next();
  };
}
