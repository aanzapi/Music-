/**
 * rateLimit.middleware.ts — Rate Limiting Configuration
 * Per-route rate limiters to prevent abuse and spam.
 */

import rateLimit from 'express-rate-limit';
import { sendError } from '../utils/response';

/**
 * General API rate limiter: 200 requests per minute.
 */
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak request. Coba lagi nanti.', 429, 'RATE_LIMIT_EXCEEDED');
  },
});

/**
 * Auth route rate limiter: 15 requests per 15 minutes.
 * Stricter to prevent brute-force login attempts.
 */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak percobaan login. Coba lagi dalam 15 menit.', 429, 'AUTH_RATE_LIMIT');
  },
});

/**
 * Registration rate limiter: 5 registrations per 15 minutes per IP.
 * Prevents mass account creation / spam signups.
 */
export const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak pendaftaran. Coba lagi dalam 15 menit.', 429, 'REGISTER_RATE_LIMIT');
  },
});

/**
 * OTP verification rate limiter: 8 attempts per 15 minutes per IP.
 * Prevents brute-force OTP guessing.
 */
export const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak percobaan verifikasi OTP. Coba lagi dalam 15 menit.', 429, 'OTP_RATE_LIMIT');
  },
});

/**
 * Password reset rate limiter: 3 requests per 15 minutes per IP.
 * Prevents email spam via forgot password.
 */
export const passwordResetLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 3,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak permintaan reset password. Coba lagi dalam 15 menit.', 429, 'RESET_RATE_LIMIT');
  },
});

/**
 * WhatsApp linking rate limiter: 5 requests per 30 minutes.
 * Prevents abuse of WhatsApp OTP sending.
 */
export const whatsappLimiter = rateLimit({
  windowMs: 30 * 60 * 1000, // 30 minutes
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak permintaan verifikasi WhatsApp. Coba lagi dalam 30 menit.', 429, 'WA_RATE_LIMIT');
  },
});

/**
 * Deposit rate limiter: 10 requests per minute.
 */
export const depositLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak request deposit. Coba lagi nanti.', 429, 'DEPOSIT_RATE_LIMIT');
  },
});

/**
 * Order creation rate limiter: 20 requests per minute.
 */
export const orderLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Terlalu banyak pesanan. Coba lagi nanti.', 429, 'ORDER_RATE_LIMIT');
  },
});
