/**
 * app.ts — Express Application Setup
 * Configures all middleware, security headers, routes, and error handlers.
 */

import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import hpp from 'hpp';
import cookieParser from 'cookie-parser';
import swaggerUi from 'swagger-ui-express';
import { env } from './config/env';
import { swaggerSpec } from './config/swagger';
import { requestLogger } from './middleware/logger.middleware';
import { apiLimiter } from './middleware/rateLimit.middleware';
import { notFoundHandler, globalErrorHandler } from './middleware/error.middleware';
import { router } from './routes';

const app = express();

// Trust proxy is required when running behind Vercel/Cloudflare 
// so express-rate-limit can get the real IP address from X-Forwarded-For
app.set('trust proxy', 1);

// ── Security Middleware ───────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: env.NODE_ENV === 'production' ? undefined : false,
}));

app.use(cors({
  origin: env.CORS_ORIGIN.split(',').map((o) => o.trim()),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-apikey', 'x-requested-with'],
}));

app.use(hpp());

// ── Body Parsing ──────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// ── Request Logging ───────────────────────────────
app.use(requestLogger);

// ── Rate Limiting ─────────────────────────────────
app.use('/api/', apiLimiter);

// ── Root Route ────────────────────────────────────
app.get('/', (_req, res) => {
  res.json({
    success: true,
    message: 'otpyuk API',
  });
});

// ── Health Check ──────────────────────────────────
app.get('/api/v1/health', (_req, res) => {
  res.json({
    success: true,
    data: {
      status: 'healthy',
      timestamp: new Date().toISOString(),
    },
  });
});

// ── API Documentation (dev only) ──────────────────
if (env.NODE_ENV !== 'production') {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
    customCss: '.swagger-ui .topbar { display: none }',
    customSiteTitle: 'otpyuk API Docs',
  }));
}

// ── API Routes ────────────────────────────────────
app.use(router);

// ── Error Handling ────────────────────────────────
app.use(notFoundHandler);
app.use(globalErrorHandler);

export { app };
