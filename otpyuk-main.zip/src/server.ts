/**
 * server.ts — Entry Point
 * Starts the Express server, connects to database and Redis,
 * initializes cron scheduler, and handles graceful shutdown.
 */

import { app } from './app';
import { env } from './config/env';
import { prisma } from './config/database';
import { getRedisClient } from './config/redis';

import { logger } from './utils/logger';

async function bootstrap(): Promise<void> {
  try {
    // Connect to PostgreSQL via Prisma
    await prisma.$connect();
    logger.info('✅ PostgreSQL connected');

    // Initialize Upstash Redis client
    getRedisClient();
    logger.info('✅ Upstash Redis initialized');



    // Start HTTP server
    const server = app.listen(env.PORT, () => {
      logger.info(`🐤 otpyuk API running on port ${env.PORT}`);
      logger.info(`📚 API Docs: http://localhost:${env.PORT}/api-docs`);
      logger.info(`🌍 Environment: ${env.NODE_ENV}`);
    });

    // ── Graceful Shutdown ─────────────────────────
    const shutdown = async (signal: string) => {
      logger.info(`\n${signal} received. Shutting down gracefully...`);

      server.close(async () => {
        logger.info('HTTP server closed');

        // Disconnect database
        await prisma.$disconnect();
        logger.info('PostgreSQL disconnected');

        // Redis cleanup not needed for Upstash REST
        logger.info('Upstash Redis — no cleanup needed');

        logger.info('👋 otpyuk shutdown complete');
        process.exit(0);
      });

      // Force exit after 10 seconds
      setTimeout(() => {
        logger.error('Could not close connections in time, forcefully shutting down');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

    // Handle unhandled rejections
    process.on('unhandledRejection', (reason: Error) => {
      logger.error('Unhandled Rejection:', reason);
    });

    // Handle uncaught exceptions
    process.on('uncaughtException', (error: Error) => {
      logger.error('Uncaught Exception:', error);
      process.exit(1);
    });
  } catch (error) {
    logger.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

bootstrap();
