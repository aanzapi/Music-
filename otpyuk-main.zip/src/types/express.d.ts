/**
 * express.d.ts — Extended Express Request Types
 * Augments the Express Request interface with custom properties.
 */

/* eslint-disable @typescript-eslint/no-unused-vars */
import { Request } from 'express';

declare global {
  namespace Express {
    interface Request {
      /** Authenticated user data (attached by auth middleware) */
      user?: {
        id: string;
        userId: string;
        email: string;
        username: string | null;
        firstName: string | null;
        lastName: string | null;
        role: string;
        balance: number;
        isActive: boolean;
        isVerified: boolean;
        avatar: string | null;
      };

      /** API key permissions (attached by apikey middleware) */
      apiKeyPermissions?: {
        canNumber: boolean;
        canDeposit: boolean;
        canH2h: boolean;
      };
    }
  }
}
