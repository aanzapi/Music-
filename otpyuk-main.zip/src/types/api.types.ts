/**
 * api.types.ts — Shared API Type Definitions
 * Common interfaces used across routes, controllers, and services.
 */

/** Standard success response */
export interface ApiSuccessResponse<T> {
  success: true;
  data: T;
  message: string;
}

/** Standard error response */
export interface ApiErrorResponse {
  success: false;
  error: {
    message: string;
    code: string;
    stack?: string;
  };
}

/** Paginated response */
export interface ApiPaginatedResponse<T> {
  success: true;
  data: T[];
  meta: PaginationMeta;
  message: string;
}

/** Pagination metadata */
export interface PaginationMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

/** Pagination query params */
export interface PaginationQuery {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/** Date range filter */
export interface DateRangeFilter {
  startDate?: string;
  endDate?: string;
}

/** RumahOTP provider API response wrapper */
export interface ProviderResponse<T> {
  success?: boolean;
  status?: boolean;
  message?: string;
  data: T;
}

/** RumahOTP v2 service item */
export interface ProviderService {
  service_code: number;
  service_name: string;
  service_img: string;
}

/** RumahOTP v2 pricelist item */
export interface ProviderPricelist {
  provider_id: string;
  server_id: number;
  stock: number;
  rate: number;
  price: number;
  price_format: string;
  available: boolean;
}

/** RumahOTP v2 country item */
export interface ProviderCountry {
  number_id: number;
  name: string;
  img: string;
  prefix: string;
  iso_code: string;
  rate: number;
  stock_total: number;
  pricelist: ProviderPricelist[];
}

/** RumahOTP v2 operator item */
export interface ProviderOperator {
  id: number;
  name: string;
  image: string;
}

/** RumahOTP order response */
export interface ProviderOrderResponse {
  order_id: string;
  phone_number: string;
  service: string;
  country: string;
  operator: string;
  price: number;
}

/** RumahOTP order status */
export interface ProviderOrderStatus {
  status: string;
  otp_msg?: string | null;
  otp_code?: string | null;
}

/** RumahOTP deposit currency breakdown */
export interface ProviderDepositCurrency {
  type: string;
  total: number;
  fee: number;
  diterima: number;
}

/** RumahOTP deposit create response (v2 compatible) */
export interface ProviderDepositResponse {
  id: string;
  method: string;
  amount: number;
  currency: ProviderDepositCurrency;
  qr_string: string;
  qr_image: string;
  created: number;
  expired: number;
}

/** RumahOTP deposit brand info */
export interface ProviderDepositBrand {
  name: string;
  icon: string;
  nns?: number;
  type?: string;
  app?: string;
  org?: string;
}

/** RumahOTP deposit status response (v2) */
export interface ProviderDepositStatus {
  id: string;
  status: string;
  created_at?: string;
  created_at_ts?: number;
  expired_at?: string;
  expired_at_ts?: number;
  total?: number;
  fee?: number;
  diterima?: number;
  brand?: ProviderDepositBrand;
  reference?: {
    id?: number;
    name?: string;
    rrn?: string;
  };
}
