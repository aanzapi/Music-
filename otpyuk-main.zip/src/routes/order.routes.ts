/**
 * order.routes.ts — Order API Routes
 */

import { Router } from 'express';
import * as orderController from '../controllers/order.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';
import { orderLimiter } from '../middleware/rateLimit.middleware';

const router = Router();

// Public (cached) routes
router.get('/services', asyncHandler(orderController.getServices));
router.get('/countries', asyncHandler(orderController.getCountries));
router.get('/operators', asyncHandler(orderController.getOperators));

// Authenticated routes
router.post('/create', requireAuth, orderLimiter, asyncHandler(orderController.createOrder));
router.get('/', requireAuth, asyncHandler(orderController.getOrders));
router.get('/:orderId', requireAuth, asyncHandler(orderController.getOrderDetail));
router.get('/:orderId/status', requireAuth, asyncHandler(orderController.checkStatus));
router.patch('/:orderId/cancel', requireAuth, asyncHandler(orderController.cancelOrder));
router.patch('/:orderId/resend', requireAuth, asyncHandler(orderController.resendOrder));
router.patch('/:orderId/done', requireAuth, asyncHandler(orderController.completeOrder));
router.post('/:orderId/buy-again', requireAuth, orderLimiter, asyncHandler(orderController.buyAgain));

export default router;
