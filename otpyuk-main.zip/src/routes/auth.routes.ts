/**
 * auth.routes.ts — Authentication Route Definitions (Buyers Edition)
 * No WhatsApp linking, no OTP service, no set-password routes.
 */

import { Router } from 'express';
import * as authController from '../controllers/auth.controller';
import { validate } from '../middleware/validate.middleware';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';
import { registerLimiter, otpLimiter, passwordResetLimiter } from '../middleware/rateLimit.middleware';
import {
  registerSchema, loginSchema, forgotPasswordSchema, resetPasswordSchema,
  verifyOtpSchema, enable2faSchema,
} from '../validators/auth.validator';

const router = Router();

// ── Registration (Direct) ─────────────────────────
router.post('/register', registerLimiter, validate(registerSchema), asyncHandler(authController.register));

// ── Login ─────────────────────────────────────────
router.post('/login', validate(loginSchema), asyncHandler(authController.login));
router.post('/login/verify-2fa', otpLimiter, validate(verifyOtpSchema), asyncHandler(authController.loginVerify2fa));

// ── Logout & Refresh ──────────────────────────────
router.post('/logout', asyncHandler(authController.logout));
router.post('/refresh', asyncHandler(authController.refresh));

// ── Password Reset ────────────────────────────────
router.post('/forgot-password', passwordResetLimiter, validate(forgotPasswordSchema), asyncHandler(authController.forgotPassword));
router.post('/reset-password', passwordResetLimiter, validate(resetPasswordSchema), asyncHandler(authController.resetPassword));

// ── 2FA Management (requires auth) ────────────────
router.post('/2fa/enable', requireAuth, validate(enable2faSchema), asyncHandler(authController.enable2fa));
router.post('/2fa/enable/confirm', requireAuth, validate(verifyOtpSchema), asyncHandler(authController.enable2faConfirm));
router.post('/2fa/disable', requireAuth, validate(enable2faSchema), asyncHandler(authController.disable2fa));
router.post('/2fa/disable/confirm', requireAuth, validate(verifyOtpSchema), asyncHandler(authController.disable2faConfirm));

// ── OAuth — Google ────────────────────────────────
router.get('/google', asyncHandler(authController.googleRedirect));
router.get('/google/callback', asyncHandler(authController.googleCallback));

// ── OAuth — GitHub ────────────────────────────────
router.get('/github', asyncHandler(authController.githubRedirect));
router.get('/github/callback', asyncHandler(authController.githubCallback));

export default router;
