/**
 * webhook.routes.ts — Webhook Management Routes
 */

import { Router } from 'express';
import * as webhookController from '../controllers/webhook.controller';
import * as depositController from '../controllers/deposit.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

// User webhook management
router.get('/', requireAuth, asyncHandler(webhookController.listWebhooks));
router.post('/create', requireAuth, asyncHandler(webhookController.createWebhook));
router.delete('/:id', requireAuth, asyncHandler(webhookController.deleteWebhook));
router.post('/:id/test', requireAuth, asyncHandler(webhookController.testWebhook));

export default router;

// Payment callback webhook (mounted separately in routes/index.ts)
export const paymentCallbackRouter = Router();
paymentCallbackRouter.post('/payment/callback', asyncHandler(depositController.paymentCallback));
