/**
 * user.routes.ts — User Profile API Routes
 */

import { Router } from 'express';
import * as userController from '../controllers/user.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

router.get('/profile', requireAuth, asyncHandler(userController.getProfile));
router.patch('/profile', requireAuth, asyncHandler(userController.updateProfile));
router.post('/avatar', requireAuth, asyncHandler(userController.uploadAvatar));
router.get('/balance', requireAuth, asyncHandler(userController.getBalance));
router.patch('/password', requireAuth, asyncHandler(userController.changePassword));
router.get('/sessions', requireAuth, asyncHandler(userController.getSessions));
router.delete('/sessions/:id', requireAuth, asyncHandler(userController.deleteSession));
router.get('/activities', requireAuth, asyncHandler(userController.getActivities));
router.delete('/sessions', requireAuth, asyncHandler(userController.revokeAllSessions));

export default router;
