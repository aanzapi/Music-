/**
 * routes/index.ts — Central Route Registry
 * Mounts all API route modules under their respective prefixes.
 */

import { Router } from 'express';
import { authLimiter } from '../middleware/rateLimit.middleware';

// Route modules (will be imported as they are created)
import authRoutes from './auth.routes';
import userRoutes from './user.routes';
import orderRoutes from './order.routes';
import depositRoutes from './deposit.routes';
import serviceRoutes from './service.routes';
import apikeyRoutes from './apikey.routes';
import webhookRoutes from './webhook.routes';
import adminRoutes from './admin.routes';

export const router = Router();

// ── Public API Routes (/api/v1) ───────────────────
router.use('/api/v1/auth', authLimiter, authRoutes);
router.use('/api/v1/user', userRoutes);
router.use('/api/v1/orders', orderRoutes);
router.use('/api/v1/deposit', depositRoutes);
router.use('/api/v1/activity', orderRoutes); // Activity reuses order routes with different handlers
router.use('/api/v1/apikey', apikeyRoutes);
router.use('/api/v1/webhook', webhookRoutes);
router.use('/api/v1/services', serviceRoutes);

// ── Admin Routes ──────────────────────────────────
router.use('/api/v1/admin', adminRoutes);

// ── Cron Routes (Vercel) ──────────────────────────
import cronRoutes from './cron.routes';
router.use('/api/v1/cron', cronRoutes);

// ── Developer API Routes (via x-apikey) ───────────
// These share handlers with the main routes but use API key auth
// Mounted at /api/v1 and /api/v2 (handled within individual route files)
