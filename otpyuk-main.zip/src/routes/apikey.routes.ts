/**
 * apikey.routes.ts — API Key Management Routes
 */

import { Router } from 'express';
import * as apikeyController from '../controllers/apikey.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

router.get('/', requireAuth, asyncHandler(apikeyController.listApiKeys));
router.post('/create', requireAuth, asyncHandler(apikeyController.createApiKey));
router.patch('/:id', requireAuth, asyncHandler(apikeyController.updateApiKey));
router.delete('/:id', requireAuth, asyncHandler(apikeyController.deleteApiKey));
router.post('/:id/toggle', requireAuth, asyncHandler(apikeyController.toggleApiKey));

export default router;
