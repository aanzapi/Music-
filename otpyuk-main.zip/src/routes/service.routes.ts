/**
 * service.routes.ts — Service Listing Routes
 */

import { Router } from 'express';
import * as serviceController from '../controllers/service.controller';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

router.get('/', asyncHandler(serviceController.getServices));
router.get('/public', asyncHandler(serviceController.getServicesPublic));
router.get('/trending', asyncHandler(serviceController.getTrending));

export default router;
