/**
 * admin.routes.ts — Admin Panel Routes
 * All routes require authentication + ADMIN role.
 */

import { Router } from 'express';
import * as adminController from '../controllers/admin.controller';
import * as serviceController from '../controllers/service.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { requireAdmin } from '../middleware/admin.middleware';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

// All admin routes require auth + admin role
router.use(requireAuth, requireAdmin);

// Dashboard
router.get('/dashboard/stats', asyncHandler(adminController.getDashboardStats));

// Users Management
router.get('/users', asyncHandler(adminController.getUsers));
router.get('/users/:id', asyncHandler(adminController.getUserDetail));
router.patch('/users/:id/balance', asyncHandler(adminController.adjustBalance));
router.patch('/users/:id/status', asyncHandler(adminController.toggleUserStatus));
router.patch('/users/:id/role', asyncHandler(adminController.updateUserRole)); // ✅ Tambahkan ini

// Orders & Deposits
router.get('/orders', asyncHandler(adminController.getAllOrders));
router.get('/deposits', asyncHandler(adminController.getAllDeposits));

// Services
router.get('/services', asyncHandler(serviceController.getServices));
router.post('/services/sync', asyncHandler(serviceController.syncServices));

export default router;
