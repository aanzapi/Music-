/**
 * deposit.routes.ts — Deposit API Routes
 */

import { Router } from 'express';
import * as depositController from '../controllers/deposit.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { asyncHandler } from '../middleware/error.middleware';
import { depositLimiter } from '../middleware/rateLimit.middleware';

const router = Router();

router.post('/create', requireAuth, depositLimiter, asyncHandler(depositController.createDeposit));
router.get('/', requireAuth, asyncHandler(depositController.getDeposits));
router.get('/:depositId', requireAuth, asyncHandler(depositController.getDepositDetail));
router.get('/:depositId/status', requireAuth, asyncHandler(depositController.checkDepositStatus));
router.post('/:depositId/cancel', requireAuth, asyncHandler(depositController.cancelDeposit));

export default router;
