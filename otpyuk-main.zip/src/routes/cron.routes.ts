/**
 * cron.routes.ts — Vercel Cron Routes
 */

import { Router } from 'express';
import * as cronController from '../controllers/cron.controller';
import { requireCron } from '../middleware/cron.middleware';
import { asyncHandler } from '../middleware/error.middleware';

const router = Router();

// Protect all cron routes
router.use(requireCron);

router.get('/every-minute', asyncHandler(cronController.everyMinuteCron));
router.get('/daily', asyncHandler(cronController.dailyCron));

export default router;
